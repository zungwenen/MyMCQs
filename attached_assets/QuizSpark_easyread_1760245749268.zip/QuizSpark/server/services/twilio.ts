import twilio from "twilio";

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const phoneNumber = process.env.TWILIO_PHONE_NUMBER;
const whatsappNumber = process.env.TWILIO_WHATSAPP_NUMBER || "whatsapp:+14155238886"; // Twilio sandbox number

let client: ReturnType<typeof twilio> | null = null;

if (accountSid && authToken) {
  client = twilio(accountSid, authToken);
}

export async function sendOTP(phone: string, code: string): Promise<{ success: boolean; method: "whatsapp" | "sms" | "none" }> {
  if (!client) {
    console.error("Twilio client not initialized - missing credentials");
    return { success: false, method: "none" };
  }

  try {
    // Try WhatsApp first
    await client.messages.create({
      from: whatsappNumber,
      to: `whatsapp:${phone}`,
      body: `Your QuizMaster verification code is: ${code}. Valid for 10 minutes.`,
    });
    console.log(`OTP sent via WhatsApp to ${phone}`);
    return { success: true, method: "whatsapp" };
  } catch (whatsappError) {
    console.log(`WhatsApp failed for ${phone}, falling back to SMS`);
    
    // Fallback to SMS
    try {
      await client.messages.create({
        from: phoneNumber,
        to: phone,
        body: `Your QuizMaster verification code is: ${code}. Valid for 10 minutes.`,
      });
      console.log(`OTP sent via SMS to ${phone}`);
      return { success: true, method: "sms" };
    } catch (smsError) {
      console.error("SMS also failed:", smsError);
      return { success: false, method: "none" };
    }
  }
}

export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}
