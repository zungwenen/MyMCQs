import { drizzle } from "drizzle-orm/neon-serverless";
import { Pool, neonConfig } from "@neondatabase/serverless";
import * as schema from "@shared/schema";
import { eq, desc, and, sql } from "drizzle-orm";
import type {
  User,
  InsertUser,
  Otp,
  InsertOtp,
  Quiz,
  InsertQuiz,
  Question,
  InsertQuestion,
  Payment,
  InsertPayment,
  QuizAttempt,
  InsertQuizAttempt,
} from "@shared/schema";
import ws from "ws";

neonConfig.webSocketConstructor = ws;

const pool = new Pool({ connectionString: process.env.DATABASE_URL });
export const db = drizzle(pool, { schema });

export interface IStorage {
  // User methods
  getUserById(id: string): Promise<User | undefined>;
  getUserByPhone(phone: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;

  // OTP methods
  createOtp(otp: InsertOtp): Promise<Otp>;
  getLatestOtp(phone: string): Promise<Otp | undefined>;
  markOtpAsVerified(id: string): Promise<void>;

  // Quiz methods
  getAllQuizzes(): Promise<Quiz[]>;
  getQuizById(id: string): Promise<Quiz | undefined>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  updateQuiz(id: string, quiz: Partial<InsertQuiz>): Promise<Quiz | undefined>;
  deleteQuiz(id: string): Promise<void>;

  // Question methods
  getQuestionsByQuizId(quizId: string): Promise<Question[]>;
  createQuestion(question: InsertQuestion): Promise<Question>;
  updateQuestion(id: string, question: Partial<InsertQuestion>): Promise<Question | undefined>;
  deleteQuestion(id: string): Promise<void>;

  // Payment methods
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPaymentsByUserId(userId: string): Promise<Payment[]>;
  getUserPaymentForQuiz(userId: string, quizId: string): Promise<Payment | undefined>;
  updatePaymentStatus(id: string, status: string, reference?: string): Promise<void>;

  // Quiz attempt methods
  createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;
  getQuizAttemptsByUserId(userId: string): Promise<QuizAttempt[]>;
  getQuizAttemptsByQuizId(quizId: string): Promise<QuizAttempt[]>;
  getAllQuizAttempts(): Promise<QuizAttempt[]>;

  // Leaderboard & stats
  getLeaderboard(limit?: number): Promise<Array<{ userId: string; userName: string; avgScore: number; totalAttempts: number }>>;
  getQuizStats(quizId: string): Promise<{ totalAttempts: number; avgScore: number }>;
}

export class DbStorage implements IStorage {
  // User methods
  async getUserById(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.id, id));
    return user;
  }

  async getUserByPhone(phone: string): Promise<User | undefined> {
    const [user] = await db.select().from(schema.users).where(eq(schema.users.phone, phone));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(schema.users).values(insertUser).returning();
    return user;
  }

  async updateUser(id: string, updateData: Partial<InsertUser>): Promise<User | undefined> {
    const [user] = await db.update(schema.users).set(updateData).where(eq(schema.users.id, id)).returning();
    return user;
  }

  // OTP methods
  async createOtp(insertOtp: InsertOtp): Promise<Otp> {
    const [otp] = await db.insert(schema.otps).values(insertOtp).returning();
    return otp;
  }

  async getLatestOtp(phone: string): Promise<Otp | undefined> {
    const [otp] = await db
      .select()
      .from(schema.otps)
      .where(eq(schema.otps.phone, phone))
      .orderBy(desc(schema.otps.createdAt))
      .limit(1);
    return otp;
  }

  async markOtpAsVerified(id: string): Promise<void> {
    await db.update(schema.otps).set({ verified: true }).where(eq(schema.otps.id, id));
  }

  // Quiz methods
  async getAllQuizzes(): Promise<Quiz[]> {
    return db.select().from(schema.quizzes).where(eq(schema.quizzes.isActive, true));
  }

  async getQuizById(id: string): Promise<Quiz | undefined> {
    const [quiz] = await db.select().from(schema.quizzes).where(eq(schema.quizzes.id, id));
    return quiz;
  }

  async createQuiz(insertQuiz: InsertQuiz): Promise<Quiz> {
    const [quiz] = await db.insert(schema.quizzes).values(insertQuiz).returning();
    return quiz;
  }

  async updateQuiz(id: string, updateData: Partial<InsertQuiz>): Promise<Quiz | undefined> {
    const [quiz] = await db.update(schema.quizzes).set(updateData).where(eq(schema.quizzes.id, id)).returning();
    return quiz;
  }

  async deleteQuiz(id: string): Promise<void> {
    await db.delete(schema.quizzes).where(eq(schema.quizzes.id, id));
  }

  // Question methods
  async getQuestionsByQuizId(quizId: string): Promise<Question[]> {
    return db.select().from(schema.questions).where(eq(schema.questions.quizId, quizId));
  }

  async createQuestion(insertQuestion: InsertQuestion): Promise<Question> {
    const [question] = await db.insert(schema.questions).values(insertQuestion).returning();
    return question;
  }

  async updateQuestion(id: string, updateData: Partial<InsertQuestion>): Promise<Question | undefined> {
    const [question] = await db.update(schema.questions).set(updateData).where(eq(schema.questions.id, id)).returning();
    return question;
  }

  async deleteQuestion(id: string): Promise<void> {
    await db.delete(schema.questions).where(eq(schema.questions.id, id));
  }

  // Payment methods
  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const [payment] = await db.insert(schema.payments).values(insertPayment).returning();
    return payment;
  }

  async getPaymentsByUserId(userId: string): Promise<Payment[]> {
    return db.select().from(schema.payments).where(eq(schema.payments.userId, userId)).orderBy(desc(schema.payments.createdAt));
  }

  async getUserPaymentForQuiz(userId: string, quizId: string): Promise<Payment | undefined> {
    const [payment] = await db
      .select()
      .from(schema.payments)
      .where(and(eq(schema.payments.userId, userId), eq(schema.payments.quizId, quizId), eq(schema.payments.status, "completed")))
      .limit(1);
    return payment;
  }

  async updatePaymentStatus(id: string, status: string, reference?: string): Promise<void> {
    await db.update(schema.payments).set({ status, paymentReference: reference }).where(eq(schema.payments.id, id));
  }

  // Quiz attempt methods
  async createQuizAttempt(insertAttempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const [attempt] = await db.insert(schema.quizAttempts).values(insertAttempt).returning();
    return attempt;
  }

  async getQuizAttemptsByUserId(userId: string): Promise<QuizAttempt[]> {
    return db.select().from(schema.quizAttempts).where(eq(schema.quizAttempts.userId, userId)).orderBy(desc(schema.quizAttempts.createdAt));
  }

  async getQuizAttemptsByQuizId(quizId: string): Promise<QuizAttempt[]> {
    return db.select().from(schema.quizAttempts).where(eq(schema.quizAttempts.quizId, quizId)).orderBy(desc(schema.quizAttempts.createdAt));
  }

  async getAllQuizAttempts(): Promise<QuizAttempt[]> {
    return db.select().from(schema.quizAttempts).orderBy(desc(schema.quizAttempts.createdAt));
  }

  // Leaderboard & stats
  async getLeaderboard(limit: number = 10): Promise<Array<{ userId: string; userName: string; avgScore: number; totalAttempts: number }>> {
    const results = await db
      .select({
        userId: schema.quizAttempts.userId,
        userName: schema.users.name,
        avgScore: sql<number>`CAST(AVG(${schema.quizAttempts.score}) AS INTEGER)`,
        totalAttempts: sql<number>`COUNT(${schema.quizAttempts.id})`,
      })
      .from(schema.quizAttempts)
      .innerJoin(schema.users, eq(schema.quizAttempts.userId, schema.users.id))
      .groupBy(schema.quizAttempts.userId, schema.users.name)
      .orderBy(desc(sql`AVG(${schema.quizAttempts.score})`))
      .limit(limit);

    return results.map(r => ({
      userId: r.userId,
      userName: r.userName || "Anonymous",
      avgScore: r.avgScore,
      totalAttempts: r.totalAttempts,
    }));
  }

  async getQuizStats(quizId: string): Promise<{ totalAttempts: number; avgScore: number }> {
    const [result] = await db
      .select({
        totalAttempts: sql<number>`COUNT(${schema.quizAttempts.id})`,
        avgScore: sql<number>`CAST(AVG(${schema.quizAttempts.score}) AS INTEGER)`,
      })
      .from(schema.quizAttempts)
      .where(eq(schema.quizAttempts.quizId, quizId));

    return {
      totalAttempts: result?.totalAttempts || 0,
      avgScore: result?.avgScore || 0,
    };
  }
}

export const storage = new DbStorage();
