import { ScoreCard } from "@/components/ScoreCard";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Home, RotateCcw } from "lucide-react";

//todo: remove mock functionality
const mockResults = {
  score: 21,
  totalQuestions: 25,
  correctAnswers: 21,
  wrongAnswers: 4,
  timeSpent: 1320,
  passed: true,
  passPercentage: 70,
};

export default function Results() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-3xl mx-auto px-4 py-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2">Quiz Complete!</h1>
          <p className="text-muted-foreground">
            Here's how you performed on Business Law Fundamentals
          </p>
        </div>

        <ScoreCard {...mockResults} />

        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Performance Analysis</CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Accuracy Rate</span>
              <span className="font-semibold" data-testid="text-accuracy">84%</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Average Time per Question</span>
              <span className="font-semibold" data-testid="text-avg-time">53 seconds</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-muted-foreground">Questions Marked for Review</span>
              <span className="font-semibold" data-testid="text-marked">3</span>
            </div>
          </CardContent>
        </Card>

        <div className="flex gap-4 mt-8">
          <Button variant="outline" className="flex-1 gap-2" data-testid="button-dashboard">
            <Home className="h-4 w-4" />
            Back to Dashboard
          </Button>
          <Button className="flex-1 gap-2" data-testid="button-retry">
            <RotateCcw className="h-4 w-4" />
            Retry Quiz
          </Button>
        </div>
      </div>
    </div>
  );
}
