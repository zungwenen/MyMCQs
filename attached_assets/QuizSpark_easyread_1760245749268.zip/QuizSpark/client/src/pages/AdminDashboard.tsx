import { StatCard } from "@/components/StatCard";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Users, BookOpen, DollarSign, TrendingUp, Plus } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

//todo: remove mock functionality
const mockRecentAttempts = [
  { id: "1", user: "Sarah Johnson", quiz: "Business Law", score: 92, date: "2024-01-15" },
  { id: "2", user: "Michael Chen", quiz: "Corporate Governance", score: 88, date: "2024-01-15" },
  { id: "3", user: "Emily Davis", quiz: "Taxation", score: 76, date: "2024-01-14" },
  { id: "4", user: "James Wilson", quiz: "Contract Law", score: 85, date: "2024-01-14" },
];

export default function AdminDashboard() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl md:text-4xl font-bold mb-2" data-testid="text-admin-title">
              Admin Dashboard
            </h1>
            <p className="text-muted-foreground">
              Manage quizzes, users, and track performance
            </p>
          </div>
          <Button className="gap-2" data-testid="button-create-quiz">
            <Plus className="h-4 w-4" />
            Create Quiz
          </Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <StatCard
            title="Total Users"
            value={1234}
            icon={Users}
            description="+12% from last month"
          />
          <StatCard
            title="Active Quizzes"
            value={42}
            icon={BookOpen}
            description="6 premium"
          />
          <StatCard
            title="Revenue"
            value="$2,450"
            icon={DollarSign}
            description="+8% from last month"
          />
          <StatCard
            title="Avg Score"
            value="81%"
            icon={TrendingUp}
            description="+3% from last month"
          />
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Recent Quiz Attempts</CardTitle>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Quiz</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {mockRecentAttempts.map((attempt) => (
                    <TableRow key={attempt.id} data-testid={`attempt-${attempt.id}`}>
                      <TableCell className="font-medium">{attempt.user}</TableCell>
                      <TableCell>{attempt.quiz}</TableCell>
                      <TableCell>
                        <Badge variant={attempt.score >= 70 ? "default" : "secondary"}>
                          {attempt.score}%
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{attempt.date}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Most Popular Quizzes</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { name: "Business Law", attempts: 324, avgScore: 84 },
                { name: "Corporate Governance", attempts: 298, avgScore: 78 },
                { name: "Taxation", attempts: 267, avgScore: 81 },
                { name: "Contract Law", attempts: 245, avgScore: 86 },
              ].map((quiz, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex-1">
                    <p className="font-medium">{quiz.name}</p>
                    <p className="text-sm text-muted-foreground">{quiz.attempts} attempts</p>
                  </div>
                  <Badge variant="outline">Avg: {quiz.avgScore}%</Badge>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
