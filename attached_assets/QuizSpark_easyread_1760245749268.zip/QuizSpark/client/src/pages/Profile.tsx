import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Phone, Edit, Trophy, BookOpen, Clock, CheckCircle } from "lucide-react";

//todo: remove mock functionality
const mockUser = {
  name: "John Doe",
  phone: "+1 (555) 123-4567",
  avatar: "",
};

const mockQuizHistory = [
  { id: "1", title: "Business Law Fundamentals", score: 84, date: "2024-01-15", passed: true },
  { id: "2", title: "Corporate Governance", score: 92, date: "2024-01-10", passed: true },
  { id: "3", title: "Taxation Principles", score: 68, date: "2024-01-05", passed: false },
];

const mockPayments = [
  { id: "1", quiz: "Corporate Governance", amount: 9.99, date: "2024-01-09" },
  { id: "2", quiz: "Taxation Principles", amount: 9.99, date: "2024-01-04" },
];

export default function Profile() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-5xl mx-auto px-4 py-8">
        <h1 className="text-3xl md:text-4xl font-bold mb-8" data-testid="text-profile-title">
          My Profile
        </h1>

        <div className="grid gap-6 md:grid-cols-3 mb-8">
          <Card className="md:col-span-1">
            <CardHeader>
              <CardTitle>Profile Information</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col items-center">
                <Avatar className="h-24 w-24 mb-4">
                  <AvatarImage src={mockUser.avatar} />
                  <AvatarFallback className="text-2xl">JD</AvatarFallback>
                </Avatar>
                <h3 className="text-xl font-semibold" data-testid="text-user-name">
                  {mockUser.name}
                </h3>
              </div>
              <div className="space-y-3">
                <div className="flex items-center gap-2 text-muted-foreground">
                  <Phone className="h-4 w-4" />
                  <span data-testid="text-user-phone">{mockUser.phone}</span>
                </div>
                <Button variant="outline" className="w-full gap-2" data-testid="button-edit-profile">
                  <Edit className="h-4 w-4" />
                  Update Phone Number
                </Button>
              </div>
            </CardContent>
          </Card>

          <div className="md:col-span-2 grid gap-4 grid-cols-2">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Quizzes Completed
                </CardTitle>
                <BookOpen className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-quizzes-completed">12</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Average Score
                </CardTitle>
                <Trophy className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-avg-score">81%</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Total Time
                </CardTitle>
                <Clock className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-total-time">6h 30m</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
                <CardTitle className="text-sm font-medium text-muted-foreground">
                  Pass Rate
                </CardTitle>
                <CheckCircle className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold" data-testid="text-pass-rate">75%</div>
              </CardContent>
            </Card>
          </div>
        </div>

        <div className="grid gap-6 md:grid-cols-2">
          <Card>
            <CardHeader>
              <CardTitle>Quiz History</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {mockQuizHistory.map((quiz) => (
                <div
                  key={quiz.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted"
                  data-testid={`quiz-history-${quiz.id}`}
                >
                  <div className="flex-1">
                    <p className="font-medium">{quiz.title}</p>
                    <p className="text-sm text-muted-foreground">{quiz.date}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={quiz.passed ? "default" : "secondary"}>
                      {quiz.score}%
                    </Badge>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Payment History</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {mockPayments.map((payment) => (
                <div
                  key={payment.id}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted"
                  data-testid={`payment-${payment.id}`}
                >
                  <div className="flex-1">
                    <p className="font-medium">{payment.quiz}</p>
                    <p className="text-sm text-muted-foreground">{payment.date}</p>
                  </div>
                  <span className="font-semibold">${payment.amount}</span>
                </div>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
