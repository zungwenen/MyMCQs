import { useState } from "react";
import { QuestionCard } from "@/components/QuestionCard";
import { QuizProgress } from "@/components/QuizProgress";
import { QuizTimer } from "@/components/QuizTimer";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";

//todo: remove mock functionality
const mockQuestions = [
  {
    id: "1",
    question: "What is the primary purpose of a corporation's articles of incorporation?",
    options: [
      "To establish the day-to-day operational procedures",
      "To define the fundamental structure and purpose of the corporation",
      "To outline employee benefits and compensation",
      "To detail tax filing requirements",
    ],
    correctAnswer: "To define the fundamental structure and purpose of the corporation",
  },
  {
    id: "2",
    question: "Which of the following best describes 'fiduciary duty' in corporate governance?",
    options: [
      "The obligation to maximize short-term profits",
      "The legal requirement to hold annual meetings",
      "The duty to act in the best interests of shareholders and the company",
      "The responsibility to maintain financial records",
    ],
    correctAnswer: "The duty to act in the best interests of shareholders and the company",
  },
  {
    id: "3",
    question: "What is the main difference between common stock and preferred stock?",
    options: [
      "Common stock has voting rights while preferred stock typically doesn't",
      "Preferred stock cannot be traded publicly",
      "Common stock pays fixed dividends",
      "Preferred stock represents debt rather than equity",
    ],
    correctAnswer: "Common stock has voting rights while preferred stock typically doesn't",
  },
];

export default function Quiz() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [markedForReview, setMarkedForReview] = useState<Set<string>>(new Set());
  const [timeRemaining, setTimeRemaining] = useState(1800);

  const handleSelectAnswer = (answer: string) => {
    setAnswers({ ...answers, [mockQuestions[currentQuestion].id]: answer });
  };

  const handleToggleReview = () => {
    const newMarked = new Set(markedForReview);
    const questionId = mockQuestions[currentQuestion].id;
    if (newMarked.has(questionId)) {
      newMarked.delete(questionId);
    } else {
      newMarked.add(questionId);
    }
    setMarkedForReview(newMarked);
  };

  const handleNext = () => {
    if (currentQuestion < mockQuestions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(currentQuestion - 1);
    }
  };

  const handleSubmit = () => {
    console.log("Submitting quiz with answers:", answers);
  };

  return (
    <div className="min-h-screen bg-background">
      <div className="sticky top-0 z-10 bg-background border-b">
        <div className="max-w-4xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4 mb-4">
            <h2 className="text-xl font-semibold" data-testid="text-quiz-title">
              Business Law Quiz
            </h2>
            <QuizTimer timeRemaining={timeRemaining} />
          </div>
          <QuizProgress current={currentQuestion + 1} total={mockQuestions.length} />
        </div>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <QuestionCard
          questionNumber={currentQuestion + 1}
          question={mockQuestions[currentQuestion].question}
          options={mockQuestions[currentQuestion].options}
          selectedAnswer={answers[mockQuestions[currentQuestion].id]}
          isMarkedForReview={markedForReview.has(mockQuestions[currentQuestion].id)}
          onSelectAnswer={handleSelectAnswer}
          onToggleReview={handleToggleReview}
          onPlayAudio={() => console.log("Playing audio for question", currentQuestion + 1)}
        />

        <div className="flex items-center justify-between gap-4 mt-6">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentQuestion === 0}
            data-testid="button-previous"
          >
            <ChevronLeft className="h-4 w-4 mr-2" />
            Previous
          </Button>

          {currentQuestion === mockQuestions.length - 1 ? (
            <Button onClick={handleSubmit} data-testid="button-submit">
              Submit Quiz
            </Button>
          ) : (
            <Button onClick={handleNext} data-testid="button-next">
              Next
              <ChevronRight className="h-4 w-4 ml-2" />
            </Button>
          )}
        </div>
      </div>
    </div>
  );
}
