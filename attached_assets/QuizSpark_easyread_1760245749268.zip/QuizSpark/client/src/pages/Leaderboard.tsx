import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { LeaderboardItem } from "@/components/LeaderboardItem";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

//todo: remove mock functionality
const mockLeaderboard = [
  { rank: 1, name: "Sarah Johnson", score: 98 },
  { rank: 2, name: "Michael Chen", score: 95 },
  { rank: 3, name: "Emily Davis", score: 92 },
  { rank: 4, name: "James Wilson", score: 89 },
  { rank: 5, name: "Maria Garcia", score: 87 },
  { rank: 6, name: "David Brown", score: 85 },
  { rank: 7, name: "Lisa Anderson", score: 83 },
  { rank: 8, name: "Robert Taylor", score: 81 },
];

export default function Leaderboard() {
  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2" data-testid="text-leaderboard-title">
            Leaderboard
          </h1>
          <p className="text-muted-foreground">
            See how you rank against other quiz takers
          </p>
        </div>

        <Tabs defaultValue="overall" className="w-full">
          <TabsList className="grid w-full max-w-md grid-cols-3">
            <TabsTrigger value="overall" data-testid="tab-overall">Overall</TabsTrigger>
            <TabsTrigger value="week" data-testid="tab-week">This Week</TabsTrigger>
            <TabsTrigger value="month" data-testid="tab-month">This Month</TabsTrigger>
          </TabsList>

          <TabsContent value="overall" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Performers</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {mockLeaderboard.map((item) => (
                  <LeaderboardItem key={item.rank} {...item} />
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="week" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Performers This Week</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {mockLeaderboard.slice(0, 5).map((item) => (
                  <LeaderboardItem key={item.rank} {...item} />
                ))}
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="month" className="mt-6">
            <Card>
              <CardHeader>
                <CardTitle>Top Performers This Month</CardTitle>
              </CardHeader>
              <CardContent className="space-y-2">
                {mockLeaderboard.map((item) => (
                  <LeaderboardItem key={item.rank} {...item} />
                ))}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
