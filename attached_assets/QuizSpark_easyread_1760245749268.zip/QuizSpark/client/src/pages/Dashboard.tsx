import { useState } from "react";
import { SubjectCard } from "@/components/SubjectCard";
import { PaymentModal } from "@/components/PaymentModal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search } from "lucide-react";

//todo: remove mock functionality
const mockSubjects = [
  {
    id: "1",
    title: "Business Law Fundamentals",
    description: "Master the essential concepts of business law, including contracts, torts, and corporate structures.",
    isPremium: false,
    questionsCount: 25,
    duration: 30,
  },
  {
    id: "2",
    title: "Corporate Governance",
    description: "Learn about board responsibilities, stakeholder management, and corporate compliance frameworks.",
    isPremium: true,
    questionsCount: 30,
    duration: 45,
    isPaid: false,
  },
  {
    id: "3",
    title: "Taxation Principles",
    description: "Understand tax laws, filing requirements, and strategic tax planning for individuals and businesses.",
    isPremium: true,
    questionsCount: 35,
    duration: 40,
    isPaid: true,
  },
  {
    id: "4",
    title: "Contract Law Advanced",
    description: "Deep dive into contract formation, interpretation, breach remedies, and negotiation strategies.",
    isPremium: false,
    questionsCount: 28,
    duration: 35,
  },
  {
    id: "5",
    title: "Employment Law",
    description: "Explore employee rights, workplace regulations, discrimination laws, and labor relations.",
    isPremium: true,
    questionsCount: 32,
    duration: 38,
    isPaid: false,
  },
  {
    id: "6",
    title: "Intellectual Property",
    description: "Study patents, trademarks, copyrights, and trade secrets in the digital age.",
    isPremium: false,
    questionsCount: 20,
    duration: 25,
  },
];

export default function Dashboard() {
  const [searchQuery, setSearchQuery] = useState("");
  const [paymentModal, setPaymentModal] = useState<{ open: boolean; quizId: string; title: string }>({
    open: false,
    quizId: "",
    title: "",
  });

  const handleStartQuiz = (id: string) => {
    const subject = mockSubjects.find((s) => s.id === id);
    if (!subject) return;

    if (subject.isPremium && !subject.isPaid) {
      setPaymentModal({ open: true, quizId: id, title: subject.title });
    } else {
      console.log("Starting quiz:", id);
    }
  };

  const handlePaymentSuccess = () => {
    setPaymentModal({ open: false, quizId: "", title: "" });
    console.log("Payment successful, starting quiz:", paymentModal.quizId);
  };

  const filteredSubjects = mockSubjects.filter((subject) =>
    subject.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="min-h-screen bg-background">
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold mb-2" data-testid="text-dashboard-title">
            Choose Your Quiz
          </h1>
          <p className="text-muted-foreground">
            Select a subject to test your knowledge and track your progress
          </p>
        </div>

        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search quizzes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9"
              data-testid="input-search-quiz"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredSubjects.map((subject) => (
            <SubjectCard
              key={subject.id}
              {...subject}
              onStartQuiz={handleStartQuiz}
            />
          ))}
        </div>
      </div>

      <PaymentModal
        open={paymentModal.open}
        onClose={() => setPaymentModal({ open: false, quizId: "", title: "" })}
        quizTitle={paymentModal.title}
        price={9.99}
        onPaymentSuccess={handlePaymentSuccess}
      />
    </div>
  );
}
