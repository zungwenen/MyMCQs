import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Volume2, Flag } from "lucide-react";

interface QuestionCardProps {
  questionNumber: number;
  question: string;
  options: string[];
  selectedAnswer?: string;
  isMarkedForReview: boolean;
  showFeedback?: boolean;
  correctAnswer?: string;
  onSelectAnswer: (answer: string) => void;
  onToggleReview: () => void;
  onPlayAudio?: () => void;
}

export function QuestionCard({
  questionNumber,
  question,
  options,
  selectedAnswer,
  isMarkedForReview,
  showFeedback = false,
  correctAnswer,
  onSelectAnswer,
  onToggleReview,
  onPlayAudio,
}: QuestionCardProps) {
  return (
    <Card className="w-full" data-testid={`card-question-${questionNumber}`}>
      <CardHeader className="gap-3">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-3">
              <Badge variant="outline" data-testid="badge-question-number">
                Question {questionNumber}
              </Badge>
              {isMarkedForReview && (
                <Badge variant="secondary" className="gap-1" data-testid="badge-marked-review">
                  <Flag className="h-3 w-3" />
                  Marked
                </Badge>
              )}
            </div>
            <h3 className="text-lg font-medium leading-relaxed">{question}</h3>
          </div>
          {onPlayAudio && (
            <Button
              variant="ghost"
              size="icon"
              onClick={onPlayAudio}
              data-testid="button-play-audio"
            >
              <Volume2 className="h-5 w-5" />
            </Button>
          )}
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <RadioGroup value={selectedAnswer} onValueChange={onSelectAnswer}>
          {options.map((option, index) => {
            const optionId = `option-${questionNumber}-${index}`;
            const isSelected = selectedAnswer === option;
            const isCorrect = showFeedback && option === correctAnswer;
            const isWrong = showFeedback && isSelected && option !== correctAnswer;

            return (
              <div
                key={index}
                className={`flex items-start gap-3 p-4 rounded-lg border hover-elevate transition-all ${
                  isSelected ? "border-primary bg-primary/5" : ""
                } ${isCorrect ? "border-green-500 bg-green-500/5" : ""} ${
                  isWrong ? "border-red-500 bg-red-500/5" : ""
                }`}
                data-testid={`option-${index}`}
              >
                <RadioGroupItem value={option} id={optionId} />
                <Label htmlFor={optionId} className="flex-1 cursor-pointer leading-relaxed">
                  {option}
                </Label>
              </div>
            );
          })}
        </RadioGroup>

        <Button
          variant="outline"
          className="w-full gap-2"
          onClick={onToggleReview}
          data-testid="button-mark-review"
        >
          <Flag className="h-4 w-4" />
          {isMarkedForReview ? "Unmark for Review" : "Mark for Review"}
        </Button>
      </CardContent>
    </Card>
  );
}
