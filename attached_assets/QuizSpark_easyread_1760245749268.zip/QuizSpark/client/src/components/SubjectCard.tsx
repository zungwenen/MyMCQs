import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Clock, BookOpen, Lock } from "lucide-react";

interface SubjectCardProps {
  id: string;
  title: string;
  description: string;
  isPremium: boolean;
  questionsCount: number;
  duration: number;
  isPaid?: boolean;
  onStartQuiz: (id: string) => void;
}

export function SubjectCard({
  id,
  title,
  description,
  isPremium,
  questionsCount,
  duration,
  isPaid = false,
  onStartQuiz,
}: SubjectCardProps) {
  const canStart = !isPremium || isPaid;

  return (
    <Card className="flex flex-col h-full hover-elevate transition-all duration-200" data-testid={`card-subject-${id}`}>
      <CardHeader className="gap-2 pb-3">
        <div className="flex items-start justify-between gap-2">
          <CardTitle className="text-xl leading-tight">{title}</CardTitle>
          <Badge 
            variant={isPremium ? "default" : "secondary"}
            className="shrink-0"
            data-testid={`badge-${isPremium ? 'premium' : 'free'}-${id}`}
          >
            {isPremium ? (
              <>
                <Lock className="h-3 w-3 mr-1" />
                Premium
              </>
            ) : (
              "Free"
            )}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="flex-1">
        <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
        <div className="flex items-center gap-4 mt-4 text-sm text-muted-foreground">
          <div className="flex items-center gap-1.5">
            <BookOpen className="h-4 w-4" />
            <span>{questionsCount} questions</span>
          </div>
          <div className="flex items-center gap-1.5">
            <Clock className="h-4 w-4" />
            <span>{duration} min</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-0">
        <Button
          className="w-full"
          onClick={() => onStartQuiz(id)}
          variant={canStart ? "default" : "outline"}
          data-testid={`button-start-quiz-${id}`}
        >
          {canStart ? "Start Quiz" : "Unlock Quiz"}
        </Button>
      </CardFooter>
    </Card>
  );
}
