import { QuizTimer } from "../QuizTimer";

export default function QuizTimerExample() {
  return (
    <div className="p-6 flex gap-4">
      <QuizTimer timeRemaining={600} />
      <QuizTimer timeRemaining={45} />
    </div>
  );
}
