import { useState } from "react";
import { OTPInput } from "../OTPInput";

export default function OTPInputExample() {
  const [otp, setOtp] = useState("");

  return (
    <div className="p-6 flex justify-center">
      <OTPInput value={otp} onChange={setOtp} />
    </div>
  );
}
