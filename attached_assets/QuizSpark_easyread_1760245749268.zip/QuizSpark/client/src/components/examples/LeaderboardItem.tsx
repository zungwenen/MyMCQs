import { LeaderboardItem } from "../LeaderboardItem";

export default function LeaderboardItemExample() {
  return (
    <div className="p-6 max-w-md space-y-2">
      <LeaderboardItem rank={1} name="Sarah Johnson" score={98} />
      <LeaderboardItem rank={2} name="Michael Chen" score={95} />
      <LeaderboardItem rank={3} name="Emily Davis" score={92} />
    </div>
  );
}
