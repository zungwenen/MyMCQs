import { QuizProgress } from "../QuizProgress";

export default function QuizProgressExample() {
  return (
    <div className="p-6 max-w-md">
      <QuizProgress current={7} total={25} />
    </div>
  );
}
