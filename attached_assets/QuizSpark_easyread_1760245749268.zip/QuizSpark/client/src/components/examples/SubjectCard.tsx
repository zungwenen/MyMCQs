import { SubjectCard } from "../SubjectCard";

export default function SubjectCardExample() {
  return (
    <div className="p-6 max-w-sm">
      <SubjectCard
        id="1"
        title="Business Law Fundamentals"
        description="Master the essential concepts of business law, including contracts, torts, and corporate structures."
        isPremium={false}
        questionsCount={25}
        duration={30}
        onStartQuiz={(id) => console.log("Start quiz:", id)}
      />
    </div>
  );
}
