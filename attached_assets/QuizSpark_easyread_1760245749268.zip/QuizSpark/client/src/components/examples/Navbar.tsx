import { Navbar } from "../Navbar";
import { ThemeProvider } from "../ThemeProvider";

export default function NavbarExample() {
  return (
    <ThemeProvider>
      <Navbar />
      <div className="p-6">
        <p className="text-muted-foreground">Content below navbar...</p>
      </div>
    </ThemeProvider>
  );
}
