import { useState } from "react";
import { PhoneInput } from "../PhoneInput";

export default function PhoneInputExample() {
  const [phone, setPhone] = useState("");

  return (
    <div className="p-6 max-w-sm">
      <PhoneInput value={phone} onChange={setPhone} />
    </div>
  );
}
