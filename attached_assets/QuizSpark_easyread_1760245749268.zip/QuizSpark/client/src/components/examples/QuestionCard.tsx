import { useState } from "react";
import { QuestionCard } from "../QuestionCard";

export default function QuestionCardExample() {
  const [selected, setSelected] = useState<string | undefined>();
  const [marked, setMarked] = useState(false);

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <QuestionCard
        questionNumber={5}
        question="What is the primary purpose of a corporation's articles of incorporation?"
        options={[
          "To establish the day-to-day operational procedures",
          "To define the fundamental structure and purpose of the corporation",
          "To outline employee benefits and compensation",
          "To detail tax filing requirements",
        ]}
        selectedAnswer={selected}
        isMarkedForReview={marked}
        onSelectAnswer={setSelected}
        onToggleReview={() => setMarked(!marked)}
        onPlayAudio={() => console.log("Playing audio")}
      />
    </div>
  );
}
