import { useState } from "react";
import { PaymentModal } from "../PaymentModal";
import { Button } from "@/components/ui/button";

export default function PaymentModalExample() {
  const [open, setOpen] = useState(true);

  return (
    <div className="p-6">
      <Button onClick={() => setOpen(true)}>Open Payment Modal</Button>
      <PaymentModal
        open={open}
        onClose={() => setOpen(false)}
        quizTitle="Corporate Governance"
        price={9.99}
        onPaymentSuccess={() => {
          setOpen(false);
          console.log("Payment successful");
        }}
      />
    </div>
  );
}
