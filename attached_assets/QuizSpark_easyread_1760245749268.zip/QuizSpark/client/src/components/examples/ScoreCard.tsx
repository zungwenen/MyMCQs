import { ScoreCard } from "../ScoreCard";

export default function ScoreCardExample() {
  return (
    <div className="p-6 max-w-md mx-auto">
      <ScoreCard
        score={21}
        totalQuestions={25}
        correctAnswers={21}
        wrongAnswers={4}
        timeSpent={1320}
        passed={true}
        passPercentage={70}
      />
    </div>
  );
}
