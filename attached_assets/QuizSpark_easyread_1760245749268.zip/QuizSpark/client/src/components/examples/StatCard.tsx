import { StatCard } from "../StatCard";
import { Users, BookOpen, Trophy, DollarSign } from "lucide-react";

export default function StatCardExample() {
  return (
    <div className="p-6 grid grid-cols-2 lg:grid-cols-4 gap-4">
      <StatCard title="Total Users" value={1234} icon={Users} description="+12% from last month" />
      <StatCard title="Quizzes" value={42} icon={BookOpen} />
      <StatCard title="Avg Score" value="85%" icon={Trophy} />
      <StatCard title="Revenue" value="$2,450" icon={DollarSign} description="+8% from last month" />
    </div>
  );
}
