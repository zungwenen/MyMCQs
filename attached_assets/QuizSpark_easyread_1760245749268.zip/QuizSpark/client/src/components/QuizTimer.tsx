import { Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface QuizTimerProps {
  timeRemaining: number;
}

export function QuizTimer({ timeRemaining }: QuizTimerProps) {
  const minutes = Math.floor(timeRemaining / 60);
  const seconds = timeRemaining % 60;
  const isLowTime = timeRemaining < 60;

  return (
    <Badge
      variant={isLowTime ? "destructive" : "secondary"}
      className="gap-1.5"
      data-testid="badge-timer"
    >
      <Clock className="h-3.5 w-3.5" />
      <span>
        {minutes}:{seconds.toString().padStart(2, "0")}
      </span>
    </Badge>
  );
}
