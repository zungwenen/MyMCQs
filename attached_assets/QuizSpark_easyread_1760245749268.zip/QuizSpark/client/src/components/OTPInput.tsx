import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp";
import { Label } from "@/components/ui/label";

interface OTPInputProps {
  value: string;
  onChange: (value: string) => void;
  error?: string;
}

export function OTPInput({ value, onChange, error }: OTPInputProps) {
  return (
    <div className="space-y-3">
      <Label>Verification Code</Label>
      <InputOTP
        maxLength={6}
        value={value}
        onChange={onChange}
        data-testid="input-otp"
      >
        <InputOTPGroup className="gap-2">
          <InputOTPSlot index={0} />
          <InputOTPSlot index={1} />
          <InputOTPSlot index={2} />
          <InputOTPSlot index={3} />
          <InputOTPSlot index={4} />
          <InputOTPSlot index={5} />
        </InputOTPGroup>
      </InputOTP>
      {error && (
        <p className="text-sm text-destructive" data-testid="text-error-otp">
          {error}
        </p>
      )}
    </div>
  );
}
