import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

interface PhoneInputProps {
  value: string;
  onChange: (value: string) => void;
  error?: string;
}

export function PhoneInput({ value, onChange, error }: PhoneInputProps) {
  return (
    <div className="space-y-2">
      <Label htmlFor="phone">Phone Number</Label>
      <Input
        id="phone"
        type="tel"
        placeholder="+1 (555) 000-0000"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        data-testid="input-phone"
      />
      {error && (
        <p className="text-sm text-destructive" data-testid="text-error-phone">
          {error}
        </p>
      )}
    </div>
  );
}
