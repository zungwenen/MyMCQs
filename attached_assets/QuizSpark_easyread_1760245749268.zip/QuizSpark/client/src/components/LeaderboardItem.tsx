import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Trophy } from "lucide-react";

interface LeaderboardItemProps {
  rank: number;
  name: string;
  score: number;
  avatar?: string;
}

export function LeaderboardItem({ rank, name, score, avatar }: LeaderboardItemProps) {
  const isTopThree = rank <= 3;
  const getRankColor = () => {
    if (rank === 1) return "text-yellow-600";
    if (rank === 2) return "text-gray-400";
    if (rank === 3) return "text-amber-700";
    return "text-muted-foreground";
  };

  const initials = name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase();

  return (
    <div
      className="flex items-center gap-4 p-4 rounded-lg hover-elevate transition-all"
      data-testid={`leaderboard-item-${rank}`}
    >
      <div className={`text-2xl font-bold w-8 text-center ${getRankColor()}`}>
        {isTopThree ? <Trophy className="h-6 w-6 mx-auto" /> : rank}
      </div>
      <Avatar>
        <AvatarImage src={avatar} alt={name} />
        <AvatarFallback>{initials}</AvatarFallback>
      </Avatar>
      <div className="flex-1">
        <p className="font-medium" data-testid={`text-name-${rank}`}>
          {name}
        </p>
      </div>
      <Badge variant="secondary" data-testid={`badge-score-${rank}`}>
        {score}%
      </Badge>
    </div>
  );
}
