import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Lock, CreditCard } from "lucide-react";

interface PaymentModalProps {
  open: boolean;
  onClose: () => void;
  quizTitle: string;
  price: number;
  onPaymentSuccess: () => void;
}

export function PaymentModal({
  open,
  onClose,
  quizTitle,
  price,
  onPaymentSuccess,
}: PaymentModalProps) {
  const handlePayment = () => {
    console.log("Processing payment...");
    onPaymentSuccess();
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent data-testid="dialog-payment">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5" />
            Unlock Premium Quiz
          </DialogTitle>
          <DialogDescription>
            Get access to "{quizTitle}" and start learning
          </DialogDescription>
        </DialogHeader>

        <div className="py-6">
          <div className="bg-muted rounded-lg p-6 text-center">
            <p className="text-sm text-muted-foreground mb-2">Price</p>
            <p className="text-4xl font-bold">${price}</p>
            <p className="text-sm text-muted-foreground mt-2">One-time payment</p>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} data-testid="button-cancel-payment">
            Cancel
          </Button>
          <Button onClick={handlePayment} data-testid="button-pay">
            <CreditCard className="h-4 w-4 mr-2" />
            Pay Now
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
