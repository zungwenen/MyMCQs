import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, XCircle, Clock, Trophy } from "lucide-react";

interface ScoreCardProps {
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  wrongAnswers: number;
  timeSpent: number;
  passed: boolean;
  passPercentage: number;
}

export function ScoreCard({
  score,
  totalQuestions,
  correctAnswers,
  wrongAnswers,
  timeSpent,
  passed,
  passPercentage,
}: ScoreCardProps) {
  const percentage = Math.round((score / totalQuestions) * 100);

  return (
    <Card className="w-full" data-testid="card-score">
      <CardHeader className="text-center pb-6">
        <div className="mx-auto mb-4">
          <Badge
            variant={passed ? "default" : "destructive"}
            className="text-base px-4 py-2"
            data-testid="badge-result"
          >
            {passed ? (
              <>
                <Trophy className="h-4 w-4 mr-2" />
                Passed
              </>
            ) : (
              "Not Passed"
            )}
          </Badge>
        </div>
        <CardTitle className="text-4xl font-bold" data-testid="text-score">
          {percentage}%
        </CardTitle>
        <p className="text-muted-foreground mt-2">
          You scored {score} out of {totalQuestions}
        </p>
        <p className="text-sm text-muted-foreground">
          Pass mark: {passPercentage}%
        </p>
      </CardHeader>
      <CardContent className="grid grid-cols-3 gap-4">
        <div className="text-center p-4 rounded-lg bg-muted">
          <CheckCircle2 className="h-5 w-5 mx-auto mb-2 text-green-600" />
          <p className="text-2xl font-semibold" data-testid="text-correct">
            {correctAnswers}
          </p>
          <p className="text-xs text-muted-foreground">Correct</p>
        </div>
        <div className="text-center p-4 rounded-lg bg-muted">
          <XCircle className="h-5 w-5 mx-auto mb-2 text-red-600" />
          <p className="text-2xl font-semibold" data-testid="text-wrong">
            {wrongAnswers}
          </p>
          <p className="text-xs text-muted-foreground">Wrong</p>
        </div>
        <div className="text-center p-4 rounded-lg bg-muted">
          <Clock className="h-5 w-5 mx-auto mb-2" />
          <p className="text-2xl font-semibold" data-testid="text-time">
            {Math.floor(timeSpent / 60)}m
          </p>
          <p className="text-xs text-muted-foreground">Time Spent</p>
        </div>
      </CardContent>
    </Card>
  );
}
