import { create } from "zustand";
import type { Question } from "@shared/schema";

interface QuizState {
  currentQuizId: string | null;
  questions: Question[];
  currentQuestionIndex: number;
  answers: Record<string, string>;
  markedForReview: Set<string>;
  timeRemaining: number;
  startTime: number | null;
  
  setQuiz: (quizId: string, questions: Question[], duration: number) => void;
  setCurrentQuestionIndex: (index: number) => void;
  setAnswer: (questionId: string, answer: string) => void;
  toggleMarkForReview: (questionId: string) => void;
  setTimeRemaining: (time: number) => void;
  resetQuiz: () => void;
}

export const useQuizStore = create<QuizState>((set, get) => ({
  currentQuizId: null,
  questions: [],
  currentQuestionIndex: 0,
  answers: {},
  markedForReview: new Set(),
  timeRemaining: 0,
  startTime: null,

  setQuiz: (quizId, questions, duration) =>
    set({
      currentQuizId: quizId,
      questions,
      currentQuestionIndex: 0,
      answers: {},
      markedForReview: new Set(),
      timeRemaining: duration * 60,
      startTime: Date.now(),
    }),

  setCurrentQuestionIndex: (index) =>
    set({ currentQuestionIndex: index }),

  setAnswer: (questionId, answer) =>
    set((state) => ({
      answers: { ...state.answers, [questionId]: answer },
    })),

  toggleMarkForReview: (questionId) =>
    set((state) => {
      const newMarked = new Set(state.markedForReview);
      if (newMarked.has(questionId)) {
        newMarked.delete(questionId);
      } else {
        newMarked.add(questionId);
      }
      return { markedForReview: newMarked };
    }),

  setTimeRemaining: (time) =>
    set({ timeRemaining: time }),

  resetQuiz: () =>
    set({
      currentQuizId: null,
      questions: [],
      currentQuestionIndex: 0,
      answers: {},
      markedForReview: new Set(),
      timeRemaining: 0,
      startTime: null,
    }),
}));
