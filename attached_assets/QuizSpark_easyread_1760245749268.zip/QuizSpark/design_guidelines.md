# MCQ Quiz Web App - Design Guidelines

## Design Approach
**System-Based Approach**: Utilizing Material Design principles adapted for educational technology, optimized for information density and user engagement. The design prioritizes clarity, accessibility, and seamless task completion across quiz-taking and administrative workflows.

## Core Design Elements

### A. Color Palette

**Light Mode:**
- Primary: 245 70% 55% (Vibrant blue for CTAs and active states)
- Primary Hover: 245 70% 48%
- Background: 0 0% 98%
- Surface: 0 0% 100%
- Surface Secondary: 220 15% 96%
- Text Primary: 220 15% 20%
- Text Secondary: 220 10% 45%
- Success: 145 65% 45% (correct answers)
- Error: 0 70% 55% (incorrect answers)
- Warning: 35 90% 55% (premium badges)
- Border: 220 15% 88%

**Dark Mode:**
- Primary: 245 65% 60%
- Primary Hover: 245 65% 68%
- Background: 220 20% 12%
- Surface: 220 18% 16%
- Surface Secondary: 220 16% 20%
- Text Primary: 220 15% 92%
- Text Secondary: 220 10% 65%
- Success: 145 55% 50%
- Error: 0 60% 58%
- Warning: 35 85% 58%
- Border: 220 15% 24%

### B. Typography
- **Primary Font**: Inter (Google Fonts)
- **Fallback**: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif
- **Headings**: font-semibold to font-bold
  - H1: text-3xl md:text-4xl
  - H2: text-2xl md:text-3xl
  - H3: text-xl md:text-2xl
- **Body**: text-base, font-normal, leading-relaxed
- **Small Text**: text-sm (metadata, timestamps)
- **Micro Text**: text-xs (badges, labels)

### C. Layout System
**Spacing Scale**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24
- Component padding: p-4 to p-6
- Section spacing: py-12 to py-20
- Card gaps: gap-4 to gap-6
- Container max-width: max-w-7xl for dashboards, max-w-4xl for quiz interface

### D. Component Library

**Navigation:**
- Top navbar: Sticky header with logo, navigation links, user avatar
- Mobile: Hamburger menu with slide-in drawer
- Admin sidebar: Fixed left sidebar (desktop), collapsible (tablet)

**Cards:**
- Subject cards: Rounded-xl with soft shadow, hover:shadow-lg transition
- Quiz result cards: Border with colored accent based on pass/fail
- Elevated cards for premium content with gradient borders

**Forms:**
- Rounded-lg inputs with focus ring in primary color
- OTP input: Individual digit boxes (6 boxes, centered, text-2xl)
- Clear error states below inputs in error color

**Buttons:**
- Primary: bg-primary with rounded-lg, px-6 py-3
- Secondary: variant="outline" with primary border
- Ghost: For tertiary actions
- Icon buttons: Circular, p-2 for controls

**Quiz Interface:**
- Question card: Large, centered card with max-w-3xl
- Progress bar: Full-width gradient from primary to success
- Timer: Fixed top-right badge with warning color when < 1 min
- Answer options: Radio buttons with custom styling, full-width cards
- Navigation: Previous/Next buttons, "Mark for Review" toggle

**Data Display:**
- Tables: Striped rows for admin analytics
- Stats cards: Grid of 3-4 cards showing key metrics
- Score display: Large circular progress with percentage
- Leaderboard: Numbered list with avatar, name, score columns

**Modals & Overlays:**
- Payment modal: Centered, max-w-md with blur backdrop
- Confirmation dialogs: Small (max-w-sm) with clear actions
- OTP verification: Two-step flow with progress indicator

**Badges & Tags:**
- "Free" badge: Success color with rounded-full
- "Premium" badge: Warning gradient with shimmer effect
- Achievement badges: Colorful icons with text below
- Status indicators: Small dot + text (Active, Completed)

### E. Interactions & Animations
- **Transitions**: Use transition-all duration-200 for hover states
- **Loading states**: Skeleton screens matching content layout
- **Toast notifications**: Slide-in from top-right for confirmations
- **Quiz feedback**: Subtle shake animation for wrong answers, bounce for correct
- **Page transitions**: Fade-in content on route change

## Special Considerations

**Accessibility:**
- All interactive elements min 44px touch target
- High contrast ratios (4.5:1 minimum)
- Voice reading controls clearly visible
- Keyboard navigation throughout
- ARIA labels on all quiz controls

**Mobile Optimization:**
- Single-column layout on mobile
- Sticky quiz controls at bottom
- Larger touch targets for answer options
- Swipe gestures for next/previous questions

**Admin Dashboard:**
- Data-dense tables with pagination
- Charts using muted colors for readability
- Inline editing for quick updates
- Bulk actions with checkboxes

**Performance:**
- Lazy load quiz images
- Prefetch next question during active quiz
- Optimistic UI updates for answer selection
- Cached question sets for offline access

## Images
**Hero Section**: No large hero image. Dashboard-first approach with quiz cards immediately visible.
**Subject Cards**: Use subtle, abstract geometric patterns as card backgrounds (low opacity overlays).
**Admin Dashboard**: Data visualization charts and graphs only, no decorative imagery.