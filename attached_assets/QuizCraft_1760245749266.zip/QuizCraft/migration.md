# QuizMaster Migration Guide

## Migrating to Supabase Database

This guide covers how to migrate your QuizMaster application from Replit PostgreSQL (Neon) to Supabase, and how to configure production settings.

### Prerequisites

Before starting the migration, ensure you have:
- A Supabase account (sign up at [supabase.com](https://supabase.com))
- Your Supabase project created
- Access to your Replit project secrets/environment variables

---

## Step 1: Get Your Supabase Connection String

1. Log in to your Supabase dashboard
2. Select your project
3. Go to **Project Settings** → **Database**
4. Under **Connection string**, select **URI** format
5. Copy the connection string (it looks like this):
   ```
   postgresql://postgres:[YOUR-PASSWORD]@db.[PROJECT-REF].supabase.co:6543/postgres
   ```
6. Replace `[YOUR-PASSWORD]` with your actual database password

---

## Step 2: Update Database Connection in Replit

### Current Storage System

**Important**: Your application currently uses **in-memory storage** (`MemStorage` in `server/storage.ts`). This means data is stored temporarily in server memory and will be lost when the server restarts.

### Where the Database Connection is Configured

The database connection is configured in these files:

- **`drizzle.config.ts`** - Drizzle migration configuration that uses `DATABASE_URL`
- **`shared/schema.ts`** - Database schema definitions (tables, columns, relationships)
- **Environment Variable**: `DATABASE_URL` in Replit Secrets

**Note**: To actually use a database (Supabase or otherwise), you'll need to:
1. Update `DATABASE_URL` with your connection string
2. Run migrations to create tables
3. Modify `server/storage.ts` to use Drizzle queries instead of in-memory storage

### Update the Connection

1. In your Replit project, go to **Tools** → **Secrets**
2. Find the `DATABASE_URL` secret
3. Update its value with your Supabase connection string:
   ```
   postgresql://postgres:[YOUR-PASSWORD]@db.[PROJECT-REF].supabase.co:6543/postgres
   ```
4. Click **Save**

---

## Step 3: Run Database Migrations

Your application uses Drizzle ORM for database management. The schema is defined in:

- **`shared/schema.ts`** - All database table definitions

To set up the tables in your Supabase database:

1. Open the Replit Shell
2. Run the migration command:
   ```bash
   npx drizzle-kit push
   ```

This will create all tables (users, quizzes, questions, payments, etc.) in your Supabase database.

---

## Step 4: Migrate from In-Memory Storage to Database

**Critical Step**: Your application currently uses in-memory storage. To persist data to Supabase, you need to update the storage implementation.

### Current Implementation
- File: **`server/storage.ts`**
- Class: `MemStorage` (stores data in JavaScript Maps)
- Issue: Data is lost on server restart

### Migration Options

**Option A: Use Drizzle ORM (Recommended)**
Replace `MemStorage` methods with Drizzle database queries. For example:
```typescript
// Current (in-memory):
async getUserByPhone(phoneNumber: string) {
  return Array.from(this.users.values()).find(u => u.phoneNumber === phoneNumber);
}

// With Drizzle:
import { db } from './db'; // You'll need to create this file
import { users } from '@shared/schema';
import { eq } from 'drizzle-orm';

async getUserByPhone(phoneNumber: string) {
  const [user] = await db.select().from(users).where(eq(users.phoneNumber, phoneNumber));
  return user;
}
```

**Option B: Create Database Storage Class**
1. Create a new `DbStorage` class that implements `IStorage`
2. Use Drizzle ORM for all operations
3. Update `server/routes.ts` to use `DbStorage` instead of `MemStorage`

**Files to Update**:
1. Create `server/db/index.ts` - Initialize Drizzle client with DATABASE_URL
2. Update `server/storage.ts` - Replace MemStorage methods with database queries
3. Remove seed data from constructor (data will be in the database)

---

## Step 5: Verify the Migration

1. Restart your application workflow
2. Log in to Supabase dashboard
3. Go to **Table Editor** to verify all tables were created:
   - `users`
   - `otp_verifications`
   - `admins`
   - `membership_plans`
   - `user_memberships`
   - `quizzes`
   - `questions`
   - `payments`
   - `quiz_attempts`
   - `split_payment_settings`

**Note**: Table names use snake_case as defined in `shared/schema.ts`

---

## Step 6: Switching to Production OTP (Twilio)

### Current Development Mode

Your app currently uses **development mode OTP** with a bypass code for testing:
- Universal bypass code: `123456` works for any phone number
- Configured in: **`server/routes.ts`** (lines 99-100 in the verify OTP endpoint)
- Enabled when: `NODE_ENV=development`
- When enabled: Real OTP is still logged to console, but `123456` also works

### Enable Production OTP

To use real Twilio OTP (WhatsApp/SMS) in production:

1. **Update Environment Variable**
   - Go to Replit **Tools** → **Secrets**
   - Find `NODE_ENV` (or create it if it doesn't exist)
   - Set value to: `production`
   - Click **Save**

2. **Verify Twilio Credentials**
   
   Ensure these secrets are configured:
   - `TWILIO_ACCOUNT_SID` - Your Twilio Account SID
   - `TWILIO_AUTH_TOKEN` - Your Twilio Auth Token
   - `TWILIO_PHONE_NUMBER` - Your Twilio SMS phone number
   - `TWILIO_WHATSAPP_NUMBER` - Your Twilio WhatsApp number (format: `whatsapp:+1234567890`)

3. **How Production OTP Works**
   - User enters phone number
   - System generates 6-digit OTP (10-minute expiration)
   - Attempts WhatsApp delivery first
   - Automatically falls back to SMS if WhatsApp fails
   - User verifies with received OTP code

### OTP Configuration Files

The OTP system consists of:

- **`server/lib/twilio.ts`**: Handles actual OTP sending via Twilio with WhatsApp → SMS fallback
- **`server/routes.ts`**: Contains development bypass logic
  - In development: Accepts `123456` as valid OTP for any phone number (line 100)
  - In production: Only accepts the actual OTP sent via Twilio

---

## Rollback to Replit PostgreSQL

If you need to revert to Replit's built-in PostgreSQL:

1. Go to Replit **Tools** → **Secrets**
2. Update `DATABASE_URL` back to your original Neon connection string
3. The connection string format is:
   ```
   postgresql://[user]:[password]@[host]/[database]?sslmode=require
   ```

---

## Important Notes

### Database Compatibility
- Your Drizzle ORM schema (`shared/schema.ts`) works with any PostgreSQL provider
- Supabase uses PostgreSQL 16 (compatible with your schema)
- Schema update needed: Migrate from in-memory storage to database queries (see Step 4)

### Data Migration
**Important**: Your app currently uses in-memory storage with seed data. When migrating to Supabase:
1. Tables will be empty initially after running migrations
2. You'll need to recreate seed data (admin account, sample quizzes) in the database
3. Or update the app to create default data on first run

### Storage Limits
- **Replit PostgreSQL (Neon)**: 10 GB total
- **Supabase Free Tier**: 500 MB (check your plan for limits)
- **Supabase Paid Tiers**: 8 GB+ depending on plan

### Additional Supabase Features
Once migrated to Supabase, you can optionally use:
- Built-in Authentication (alternative to phone/OTP)
- Real-time subscriptions
- File storage
- Edge functions

However, your current implementation will work without these features.

---

## Support

For issues with:
- **Supabase**: Check [Supabase documentation](https://supabase.com/docs)
- **Drizzle ORM**: Check [Drizzle documentation](https://orm.drizzle.team)
- **Twilio**: Check [Twilio documentation](https://www.twilio.com/docs)
