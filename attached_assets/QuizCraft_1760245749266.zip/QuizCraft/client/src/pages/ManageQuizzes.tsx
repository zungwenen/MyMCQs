import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import AdminSidebar from "@/components/AdminSidebar";
import AdminMobileHeader from "@/components/AdminMobileHeader";
import { Plus, Pencil, Trash2, Loader2, FileQuestion, ListChecks } from "lucide-react";
import type { Quiz } from "@shared/schema";

export default function ManageQuizzes() {
  const [, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [createDialogOpen, setCreateDialogOpen] = useState(false);
  const [editingQuiz, setEditingQuiz] = useState<Quiz | null>(null);
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    isPremium: false,
    isFree: false,
    duration: 30,
    passingScore: 70,
  });
  const { toast } = useToast();

  const { data: quizzesData, isLoading } = useQuery<{ quizzes: Array<Quiz & { questionsCount: number }> }>({
    queryKey: ["/api/quizzes"],
  });

  const createQuizMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const res = await apiRequest("POST", "/api/admin/quizzes", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes"] });
      setCreateDialogOpen(false);
      resetForm();
      toast({ title: "Success", description: "Quiz created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateQuizMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: Partial<typeof formData> }) => {
      const res = await apiRequest("PATCH", `/api/admin/quizzes/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes"] });
      setEditingQuiz(null);
      resetForm();
      toast({ title: "Success", description: "Quiz updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteQuizMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("DELETE", `/api/admin/quizzes/${id}`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes"] });
      toast({ title: "Success", description: "Quiz deleted successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      isPremium: false,
      isFree: false,
      duration: 30,
      passingScore: 70,
    });
  };

  const handleOpenCreate = () => {
    resetForm();
    setCreateDialogOpen(true);
  };

  const handleOpenEdit = (quiz: Quiz) => {
    setFormData({
      title: quiz.title,
      description: quiz.description,
      isPremium: quiz.isPremium,
      isFree: quiz.isFree,
      duration: quiz.duration,
      passingScore: quiz.passingScore,
    });
    setEditingQuiz(quiz);
  };

  const handleSubmit = () => {
    if (editingQuiz) {
      updateQuizMutation.mutate({ id: editingQuiz.id, data: formData });
    } else {
      createQuizMutation.mutate(formData);
    }
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this quiz? This action cannot be undone.")) {
      deleteQuizMutation.mutate(id);
    }
  };

  const isPending = createQuizMutation.isPending || updateQuizMutation.isPending || deleteQuizMutation.isPending;

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar 
        mobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />
      
      <main className="flex-1 overflow-auto">
        <AdminMobileHeader onMenuClick={() => setMobileMenuOpen(true)} />
        <div className="p-4 md:p-8">
          <div className="mb-6 md:mb-8 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2" data-testid="text-page-title">Manage Quizzes</h1>
              <p className="text-muted-foreground">Create, edit, and manage quiz content</p>
            </div>
            <Button onClick={handleOpenCreate} className="w-full md:w-auto" data-testid="button-create-quiz">
              <Plus className="w-4 h-4 mr-2" />
              Create Quiz
            </Button>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="grid gap-4">
              {quizzesData?.quizzes.map((quiz) => (
                <Card key={quiz.id} data-testid={`quiz-card-${quiz.id}`}>
                  <CardHeader>
                    <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <CardTitle className="text-xl">{quiz.title}</CardTitle>
                          {quiz.isFree ? (
                            <Badge className="bg-green-500/10 text-green-700 dark:text-green-400">Free for Testing</Badge>
                          ) : quiz.isPremium ? (
                            <Badge className="bg-primary">Premium</Badge>
                          ) : (
                            <Badge variant="outline">Free</Badge>
                          )}
                        </div>
                        <CardDescription>{quiz.description}</CardDescription>
                      </div>
                      <div className="flex flex-col md:flex-row gap-2 mt-4 md:mt-0">
                        <Button
                          variant="outline"
                          onClick={() => setLocation(`/admin/quizzes/${quiz.id}/questions`)}
                          className="w-full md:w-auto"
                          data-testid={`button-manage-questions-${quiz.id}`}
                        >
                          <ListChecks className="w-4 h-4 mr-2" />
                          Manage Questions
                        </Button>
                        <div className="flex gap-2">
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleOpenEdit(quiz)}
                            data-testid={`button-edit-${quiz.id}`}
                          >
                            <Pencil className="w-4 h-4" />
                          </Button>
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => handleDelete(quiz.id)}
                            disabled={isPending}
                            data-testid={`button-delete-${quiz.id}`}
                          >
                            <Trash2 className="w-4 h-4 text-destructive" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="flex items-center gap-6 text-sm text-muted-foreground">
                      <div className="flex items-center gap-2">
                        <FileQuestion className="w-4 h-4" />
                        <span>{quiz.questionsCount} questions</span>
                      </div>
                      <span>Duration: {quiz.duration} min</span>
                      <span>Passing Score: {quiz.passingScore}%</span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </div>
      </main>

      <Dialog open={createDialogOpen || !!editingQuiz} onOpenChange={(open) => {
        if (!open) {
          setCreateDialogOpen(false);
          setEditingQuiz(null);
          resetForm();
        }
      }}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{editingQuiz ? "Edit Quiz" : "Create New Quiz"}</DialogTitle>
            <DialogDescription>
              {editingQuiz ? "Update quiz details" : "Add a new quiz to the platform"}
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="e.g., Business Law Fundamentals"
                data-testid="input-quiz-title"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe what this quiz covers..."
                rows={3}
                data-testid="input-quiz-description"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="duration">Duration (minutes)</Label>
                <Input
                  id="duration"
                  type="number"
                  value={formData.duration}
                  onChange={(e) => setFormData({ ...formData, duration: parseInt(e.target.value) || 0 })}
                  data-testid="input-quiz-duration"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="passingScore">Passing Score (%)</Label>
                <Input
                  id="passingScore"
                  type="number"
                  value={formData.passingScore}
                  onChange={(e) => setFormData({ ...formData, passingScore: parseInt(e.target.value) || 0 })}
                  data-testid="input-quiz-passing-score"
                />
              </div>
            </div>

            <div className="flex items-center justify-between p-4 border rounded-lg">
              <div className="space-y-0.5">
                <Label htmlFor="isPremium">Premium Quiz</Label>
                <p className="text-sm text-muted-foreground">Requires active membership to access</p>
              </div>
              <Switch
                id="isPremium"
                checked={formData.isPremium}
                onCheckedChange={(checked) => setFormData({ ...formData, isPremium: checked })}
                data-testid="switch-premium"
              />
            </div>

            {formData.isPremium && (
              <div className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-0.5">
                  <Label htmlFor="isFree">Free for Testing</Label>
                  <p className="text-sm text-muted-foreground">Make this premium quiz free for all users (testing purposes)</p>
                </div>
                <Switch
                  id="isFree"
                  checked={formData.isFree}
                  onCheckedChange={(checked) => setFormData({ ...formData, isFree: checked })}
                  data-testid="switch-free"
                />
              </div>
            )}

            <div className="flex gap-3 pt-4">
              <Button
                variant="outline"
                onClick={() => {
                  setCreateDialogOpen(false);
                  setEditingQuiz(null);
                  resetForm();
                }}
                disabled={isPending}
                className="flex-1"
                data-testid="button-cancel"
              >
                Cancel
              </Button>
              <Button
                onClick={handleSubmit}
                disabled={isPending || !formData.title || !formData.description}
                className="flex-1"
                data-testid="button-submit"
              >
                {isPending ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    {editingQuiz ? "Updating..." : "Creating..."}
                  </>
                ) : (
                  editingQuiz ? "Update Quiz" : "Create Quiz"
                )}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
