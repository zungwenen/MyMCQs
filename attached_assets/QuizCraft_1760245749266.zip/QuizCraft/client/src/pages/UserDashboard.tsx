import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Search, GraduationCap, Loader2, Clock, CheckCircle2, XCircle, TrendingUp, Crown, Calendar } from "lucide-react";
import QuizSubjectCard from "@/components/QuizSubjectCard";
import MembershipModal from "@/components/MembershipModal";
import UserNav from "@/components/UserNav";
import { useQuery } from "@tanstack/react-query";
import { useAuthStore } from "@/stores/authStore";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import type { Quiz } from "@shared/schema";

export default function UserDashboard() {
  const [searchQuery, setSearchQuery] = useState("");
  const [membershipModalOpen, setMembershipModalOpen] = useState(false);
  const { user, logout } = useAuthStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: quizzesData, isLoading } = useQuery<{ quizzes: Array<Quiz & { questionsCount: number }> }>({
    queryKey: ["/api/quizzes"],
  });

  const { data: attemptsData, isLoading: attemptsLoading } = useQuery<{
    attempts: Array<{
      id: string;
      quizId: string;
      quizTitle: string;
      score: number;
      totalQuestions: number;
      correctAnswers: number;
      incorrectAnswers: number;
      unattempted: number;
      completedAt: string;
      timeSpent: number;
    }>;
  }>({
    queryKey: ["/api/attempts"],
  });

  const { data: membershipData } = useQuery<{
    membership: {
      id: string;
      planId: string;
      purchaseDate: string;
      expiryDate: string | null;
      status: string;
    } | null;
    hasAccess: boolean;
  }>({
    queryKey: ["/api/membership/user"],
  });

  const filteredQuizzes = (quizzesData?.quizzes || []).filter((quiz) =>
    quiz.title.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleStartQuiz = async (quiz: Quiz & { questionsCount: number }) => {
    try {
      // Check if user has access
      const res = await apiRequest("GET", `/api/quizzes/${quiz.id}/access`);
      const accessData = await res.json();

      if (!accessData.hasAccess && quiz.isPremium && !quiz.isFree) {
        // Show membership modal for premium content
        setMembershipModalOpen(true);
      } else {
        setLocation(`/quiz/${quiz.id}`);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to check quiz access",
        variant: "destructive",
      });
    }
  };

  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout");
      logout();
      setLocation("/");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const handleMembershipPurchase = () => {
    toast({
      title: "Welcome to Premium!",
      description: "You now have access to all premium quizzes",
    });
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b sticky top-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary rounded-lg">
              <GraduationCap className="w-6 h-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold" data-testid="text-app-title">Easyread IQ</h1>
          </div>
          <UserNav
            userName={user?.name || "User"}
            userPhone={user?.phoneNumber || ""}
            onProfileClick={() => setLocation("/profile")}
            onAchievementsClick={() => setLocation("/achievements")}
            onSettingsClick={() => setLocation("/settings")}
            onLogout={handleLogout}
          />
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 pb-20 md:pb-8">
        <div className="mb-8">
          <h2 className="text-2xl md:text-3xl font-bold mb-2" data-testid="text-welcome">
            Welcome back{user?.name ? `, ${user.name}` : ""}!
          </h2>
          <p className="text-muted-foreground">
            Ready to test your knowledge? Choose a quiz to get started.
          </p>
        </div>

        {/* Membership Status Card */}
        {membershipData?.hasAccess ? (
          <Card className="mb-8 border-primary/20 bg-primary/5" data-testid="card-membership-active">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-primary/10 rounded-lg">
                    <Crown className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Premium Member</CardTitle>
                    <CardDescription className="flex items-center gap-2">
                      <Calendar className="w-3 h-3" />
                      {membershipData.membership?.expiryDate
                        ? `Expires ${formatDistanceToNow(new Date(membershipData.membership.expiryDate), { addSuffix: true })}`
                        : "Lifetime Access"
                      }
                    </CardDescription>
                  </div>
                </div>
                <Badge className="bg-chart-2 text-white">Active</Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground">
                You have unlimited access to all premium quizzes
              </p>
            </CardContent>
          </Card>
        ) : (
          <Card className="mb-8 border-primary/20" data-testid="card-membership-inactive">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-muted rounded-lg">
                    <Crown className="w-5 h-5 text-muted-foreground" />
                  </div>
                  <div>
                    <CardTitle className="text-lg">Unlock Premium Content</CardTitle>
                    <CardDescription>
                      Get unlimited access to all premium quizzes
                    </CardDescription>
                  </div>
                </div>
                <Button onClick={() => setMembershipModalOpen(true)} data-testid="button-get-premium">
                  <Crown className="w-4 h-4 mr-2" />
                  Get Premium
                </Button>
              </div>
            </CardHeader>
          </Card>
        )}

        {/* Recent Attempts Section */}
        {!attemptsLoading && attemptsData?.attempts && attemptsData.attempts.length > 0 && (
          <div className="mb-12">
            <h3 className="text-xl md:text-2xl font-bold mb-6">Recent Quiz Attempts</h3>
            <div className="space-y-4" data-testid="attempts-list">
              {attemptsData.attempts.slice(0, 5).map((attempt) => (
                <Card
                  key={attempt.id}
                  className="hover-elevate cursor-pointer"
                  onClick={() => setLocation(`/results/${attempt.id}`)}
                  data-testid={`attempt-item-${attempt.id}`}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-lg mb-1" data-testid={`attempt-quiz-title-${attempt.id}`}>
                          {attempt.quizTitle}
                        </CardTitle>
                        <CardDescription className="flex items-center gap-2">
                          <Clock className="w-3 h-3" />
                          {formatDistanceToNow(new Date(attempt.completedAt), { addSuffix: true })}
                        </CardDescription>
                      </div>
                      <Badge
                        variant={attempt.score >= 70 ? "default" : "secondary"}
                        className={attempt.score >= 70 ? "bg-chart-2 text-white" : ""}
                      >
                        {attempt.score}%
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <div className="flex items-center gap-6 text-sm">
                      <div className="flex items-center gap-1 text-chart-2">
                        <CheckCircle2 className="w-4 h-4" />
                        <span>{attempt.correctAnswers} correct</span>
                      </div>
                      {attempt.incorrectAnswers > 0 && (
                        <div className="flex items-center gap-1 text-destructive">
                          <XCircle className="w-4 h-4" />
                          <span>{attempt.incorrectAnswers} incorrect</span>
                        </div>
                      )}
                      {attempt.unattempted > 0 && (
                        <div className="flex items-center gap-1 text-muted-foreground">
                          <span>{attempt.unattempted} skipped</span>
                        </div>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}

        {/* Available Quizzes Section */}
        <div className="mb-6">
          <h3 className="text-xl md:text-2xl font-bold mb-6">Available Quizzes</h3>
        </div>

        <div className="mb-8">
          <div className="relative max-w-md">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input
              type="search"
              placeholder="Search quizzes..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-10"
              data-testid="input-search"
            />
          </div>
        </div>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredQuizzes.map((quiz) => (
              <QuizSubjectCard
                key={quiz.id}
                title={quiz.title}
                description={quiz.description}
                isPremium={quiz.isPremium}
                questionsCount={quiz.questionsCount}
                duration={quiz.duration}
                onStartQuiz={() => handleStartQuiz(quiz)}
              />
            ))}
          </div>
        )}

        {!isLoading && filteredQuizzes.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground" data-testid="text-no-quizzes">
              {searchQuery ? "No quizzes found matching your search" : "No quizzes available"}
            </p>
          </div>
        )}
      </main>

      <MembershipModal
        open={membershipModalOpen}
        onClose={() => setMembershipModalOpen(false)}
        onPurchaseSuccess={handleMembershipPurchase}
      />
    </div>
  );
}
