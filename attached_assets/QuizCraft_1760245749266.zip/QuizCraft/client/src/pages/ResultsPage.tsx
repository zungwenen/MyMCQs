import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Home, Loader2, Volume2, VolumeX, CheckCircle2, XCircle, Flag } from "lucide-react";
import ResultsCard from "@/components/ResultsCard";
import { useQuery } from "@tanstack/react-query";
import { useSpeech } from "@/hooks/useSpeech";
import type { QuizAttempt, Question } from "@shared/schema";

export default function ResultsPage() {
  const [, setLocation] = useLocation();
  const params = useParams();
  const attemptId = params.attemptId;
  const [showReview, setShowReview] = useState(false);
  const { toggle, currentText, isSpeaking } = useSpeech();

  const { data: attempts, isLoading } = useQuery<{ attempts: QuizAttempt[] }>({
    queryKey: ["/api/attempts"],
  });

  const attempt = attempts?.attempts.find((a) => a.id === attemptId);

  const { data: questionsData, isLoading: questionsLoading } = useQuery<{
    questions: Question[];
  }>({
    queryKey: ["/api/quizzes", attempt?.quizId, "review"],
    enabled: !!attempt?.quizId && showReview,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!attempt) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Results not found</h2>
          <Button onClick={() => setLocation("/dashboard")}>Back to Dashboard</Button>
        </div>
      </div>
    );
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-background sticky top-0 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <h1 className="text-xl font-bold" data-testid="text-header">Quiz Results</h1>
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            data-testid="button-home"
          >
            <Home className="w-4 h-4 mr-2" />
            Dashboard
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12 pb-20 md:pb-12">
        <ResultsCard
          score={attempt.score}
          totalQuestions={attempt.totalQuestions}
          correctAnswers={attempt.correctAnswers}
          incorrectAnswers={attempt.incorrectAnswers}
          unattempted={attempt.unattempted}
          timeSpent={formatTime(attempt.timeSpent)}
          passingScore={attempt.totalQuestions * 0.7} // 70% passing score
          onRetake={() => setLocation(`/quiz/${attempt.quizId}`)}
          onReview={() => setShowReview(!showReview)}
        />

        {showReview && (
          <div className="max-w-4xl mx-auto mt-8">
            {questionsLoading ? (
              <div className="flex items-center justify-center py-12">
                <Loader2 className="w-8 h-8 animate-spin text-primary" />
              </div>
            ) : (
              <div className="space-y-6">
                <h2 className="text-2xl font-bold mb-6" data-testid="text-review-title">Answer Review</h2>
                {questionsData?.questions.map((question, index) => {
                  const userAnswer = attempt.answers[question.id];
                  const correctAnswer = question.correctAnswer;
                  const isCorrect = userAnswer === correctAnswer;
                  const wasMarked = attempt.markedForReview?.includes(question.id);

                  return (
                    <Card key={question.id} className="p-6" data-testid={`review-question-${index}`}>
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-start gap-2 flex-1">
                          <span className="font-semibold text-muted-foreground">Q{index + 1}.</span>
                          <div className="flex-1">
                            <p className="font-medium mb-1">{question.questionText}</p>
                            {wasMarked && (
                              <div className="flex items-center gap-1 text-sm text-muted-foreground mt-2">
                                <Flag className="w-4 h-4" />
                                <span>Marked for review</span>
                              </div>
                            )}
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => toggle(question.questionText)}
                          aria-label="Read question aloud"
                          data-testid={`button-speak-question-${index}`}
                        >
                          {isSpeaking && currentText === question.questionText ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                        </Button>
                      </div>

                      <div className="space-y-2">
                        {question.options.map((option) => {
                          const isUserAnswer = userAnswer === option.id;
                          const isCorrectOption = correctAnswer === option.id;
                          
                          return (
                            <div
                              key={option.id}
                              className={`p-3 rounded-lg border-2 ${
                                isCorrectOption
                                  ? "border-chart-2 bg-chart-2/10"
                                  : isUserAnswer && !isCorrect
                                  ? "border-destructive bg-destructive/10"
                                  : "border-border"
                              }`}
                              data-testid={`option-${option.id}`}
                            >
                              <div className="flex items-center gap-2">
                                {isCorrectOption && (
                                  <CheckCircle2 className="w-5 h-5 text-chart-2" />
                                )}
                                {isUserAnswer && !isCorrect && (
                                  <XCircle className="w-5 h-5 text-destructive" />
                                )}
                                <span className="flex-1">{option.text}</span>
                                {isUserAnswer && (
                                  <span className="text-sm text-muted-foreground">(Your answer)</span>
                                )}
                                {isCorrectOption && (
                                  <span className="text-sm text-chart-2 font-medium">(Correct)</span>
                                )}
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </Card>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </main>
    </div>
  );
}
