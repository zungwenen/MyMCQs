import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import AdminSidebar from "@/components/AdminSidebar";
import AdminMobileHeader from "@/components/AdminMobileHeader";
import { DollarSign, Save, Info, Loader2 } from "lucide-react";
import type { SplitPaymentSettings } from "@shared/schema";

export default function SplitPaymentSettingsPage() {
  const { toast } = useToast();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [formData, setFormData] = useState({
    subaccountCode: "",
    splitType: "percentage" as "percentage" | "flat",
    splitValue: "",
    bearer: "account" as "account" | "subaccount",
    isActive: true,
  });

  const { data: settingsData, isLoading } = useQuery({
    queryKey: ["/api/admin/split-payment-settings"],
  });

  const settings = (settingsData as { settings: SplitPaymentSettings | null })?.settings;

  useEffect(() => {
    if (settings) {
      setFormData({
        subaccountCode: settings.subaccountCode,
        splitType: settings.splitType as "percentage" | "flat",
        splitValue: settings.splitValue,
        bearer: settings.bearer as "account" | "subaccount",
        isActive: settings.isActive,
      });
    }
  }, [settings]);

  const saveSettingsMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      if (settings) {
        return apiRequest("PATCH", `/api/admin/split-payment-settings/${settings.id}`, data);
      } else {
        return apiRequest("POST", "/api/admin/split-payment-settings", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/split-payment-settings"] });
      toast({
        title: "Settings saved",
        description: "Split payment settings have been updated successfully",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to save split payment settings",
      });
    },
  });

  const handleSave = () => {
    if (!formData.subaccountCode.trim()) {
      toast({
        variant: "destructive",
        title: "Validation Error",
        description: "Subaccount code is required",
      });
      return;
    }

    if (!formData.splitValue || parseFloat(formData.splitValue) <= 0) {
      toast({
        variant: "destructive",
        title: "Validation Error",
        description: "Split value must be greater than 0",
      });
      return;
    }

    saveSettingsMutation.mutate(formData);
  };

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar 
        mobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />
      
      <main className="flex-1 overflow-auto">
        <AdminMobileHeader onMenuClick={() => setMobileMenuOpen(true)} />
        <div className="p-4 md:p-8">
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl md:text-3xl font-bold mb-2" data-testid="text-page-title">Split Payment Settings</h1>
            <p className="text-muted-foreground">Configure Paystack split payment with your subaccount</p>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <div className="max-w-3xl space-y-6">
              <Card className="border-primary/20">
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Info className="w-5 h-5 text-primary" />
                    About Split Payments
                  </CardTitle>
                  <CardDescription>
                    Split payments allow you to automatically divide transaction settlements between your main Paystack account and a subaccount.
                    This is useful for revenue sharing, marketplace commissions, or affiliate programs.
                  </CardDescription>
                </CardHeader>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <DollarSign className="w-5 h-5" />
                    Subaccount Configuration
                  </CardTitle>
                  <CardDescription>
                    Configure your Paystack subaccount for split payments
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="subaccountCode">
                      Paystack Subaccount Code <span className="text-destructive">*</span>
                    </Label>
                    <Input
                      id="subaccountCode"
                      placeholder="ACCT_xxxxxxxxxx"
                      value={formData.subaccountCode}
                      onChange={(e) => setFormData({ ...formData, subaccountCode: e.target.value })}
                      data-testid="input-subaccount-code"
                    />
                    <p className="text-xs text-muted-foreground">
                      Get this from your Paystack dashboard under Subaccounts
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                      <Label htmlFor="splitType">Split Type</Label>
                      <Select
                        value={formData.splitType}
                        onValueChange={(value) => setFormData({ ...formData, splitType: value as "percentage" | "flat" })}
                      >
                        <SelectTrigger id="splitType" data-testid="select-split-type">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="percentage">Percentage</SelectItem>
                          <SelectItem value="flat">Flat Amount</SelectItem>
                        </SelectContent>
                      </Select>
                      <p className="text-xs text-muted-foreground">
                        How to calculate the split
                      </p>
                    </div>

                    <div className="space-y-2">
                      <Label htmlFor="splitValue">
                        {formData.splitType === "percentage" ? "Percentage (%)" : "Flat Amount (₦)"}
                        <span className="text-destructive"> *</span>
                      </Label>
                      <Input
                        id="splitValue"
                        type="number"
                        step={formData.splitType === "percentage" ? "1" : "0.01"}
                        min="0"
                        max={formData.splitType === "percentage" ? "100" : undefined}
                        placeholder={formData.splitType === "percentage" ? "e.g., 20" : "e.g., 500"}
                        value={formData.splitValue}
                        onChange={(e) => setFormData({ ...formData, splitValue: e.target.value })}
                        data-testid="input-split-value"
                      />
                      <p className="text-xs text-muted-foreground">
                        {formData.splitType === "percentage" 
                          ? "Percentage that goes to your main account (subaccount gets the rest)"
                          : "Fixed amount in Naira that goes to your main account"
                        }
                      </p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="bearer">Fee Bearer</Label>
                    <Select
                      value={formData.bearer}
                      onValueChange={(value) => setFormData({ ...formData, bearer: value as "account" | "subaccount" })}
                    >
                      <SelectTrigger id="bearer" data-testid="select-bearer">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="account">Main Account</SelectItem>
                        <SelectItem value="subaccount">Subaccount</SelectItem>
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      Who pays the Paystack transaction fees
                    </p>
                  </div>

                  <div className="flex items-center justify-between p-4 rounded-lg bg-muted">
                    <div className="space-y-0.5">
                      <Label htmlFor="isActive">Enable Split Payments</Label>
                      <p className="text-xs text-muted-foreground">
                        Activate split payment for all transactions
                      </p>
                    </div>
                    <Switch
                      id="isActive"
                      checked={formData.isActive}
                      onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
                      data-testid="switch-is-active"
                    />
                  </div>

                  <Button
                    onClick={handleSave}
                    disabled={saveSettingsMutation.isPending}
                    className="w-full md:w-auto"
                    data-testid="button-save-settings"
                  >
                    {saveSettingsMutation.isPending ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Saving...
                      </>
                    ) : (
                      <>
                        <Save className="w-4 h-4 mr-2" />
                        Save Settings
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {settings && (
                <Card className="bg-muted/50">
                  <CardHeader>
                    <CardTitle className="text-base">Current Configuration</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2 text-sm">
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Subaccount:</span>
                      <span className="font-mono">{settings.subaccountCode}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Split Type:</span>
                      <span className="capitalize">{settings.splitType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Split Value:</span>
                      <span>
                        {settings.splitType === "percentage" 
                          ? `${settings.splitValue}%` 
                          : `₦${parseFloat(settings.splitValue).toLocaleString()}`
                        }
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Fee Bearer:</span>
                      <span className="capitalize">{settings.bearer}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-muted-foreground">Status:</span>
                      <span className={settings.isActive ? "text-chart-2" : "text-muted-foreground"}>
                        {settings.isActive ? "Active" : "Inactive"}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}
        </div>
      </main>
    </div>
  );
}
