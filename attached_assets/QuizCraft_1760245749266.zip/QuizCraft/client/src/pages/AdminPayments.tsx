import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import AdminSidebar from "@/components/AdminSidebar";
import AdminMobileHeader from "@/components/AdminMobileHeader";
import { Search, Loader2, DollarSign, CheckCircle2, XCircle } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface Payment {
  id: string;
  userId: string;
  quizId: string;
  amount: string;
  status: string;
  reference: string;
  createdAt: string;
  userName?: string;
  quizTitle?: string;
}

export default function AdminPayments() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");

  const { data: paymentsData, isLoading } = useQuery<{ payments: Payment[] }>({
    queryKey: ["/api/payments"],
  });

  const filteredPayments = (paymentsData?.payments || []).filter((payment) => {
    const search = searchQuery.toLowerCase();
    return (
      payment.reference.toLowerCase().includes(search) ||
      payment.userName?.toLowerCase().includes(search) ||
      payment.quizTitle?.toLowerCase().includes(search)
    );
  });

  const totalRevenue = (paymentsData?.payments || [])
    .filter(p => p.status === "success")
    .reduce((sum, p) => sum + parseFloat(p.amount), 0);

  const successfulPayments = (paymentsData?.payments || []).filter(p => p.status === "success").length;
  const pendingPayments = (paymentsData?.payments || []).filter(p => p.status === "pending").length;

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar 
        mobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />
      
      <main className="flex-1 overflow-auto">
        <AdminMobileHeader onMenuClick={() => setMobileMenuOpen(true)} />
        <div className="p-4 md:p-8">
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl md:text-3xl font-bold mb-2" data-testid="text-page-title">Payments</h1>
            <p className="text-muted-foreground">View and manage payment transactions</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 md:gap-6 mb-6 md:mb-8">
            <Card>
              <CardHeader className="pb-3">
                <CardDescription>Total Revenue</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-chart-3" />
                  <p className="text-3xl font-bold">₦{totalRevenue.toLocaleString()}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>Successful Payments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="w-5 h-5 text-chart-2" />
                  <p className="text-3xl font-bold">{successfulPayments}</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="pb-3">
                <CardDescription>Pending Payments</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex items-center gap-2">
                  <XCircle className="w-5 h-5 text-chart-4" />
                  <p className="text-3xl font-bold">{pendingPayments}</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Transaction History</CardTitle>
                  <CardDescription>All payment transactions</CardDescription>
                </div>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder="Search payments..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9"
                    data-testid="input-search"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : filteredPayments.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Reference</TableHead>
                      <TableHead>User</TableHead>
                      <TableHead>Quiz</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Date</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPayments.map((payment) => (
                      <TableRow key={payment.id} data-testid={`payment-row-${payment.id}`}>
                        <TableCell className="font-mono text-sm">{payment.reference}</TableCell>
                        <TableCell>{payment.userName || payment.userId.slice(0, 8)}</TableCell>
                        <TableCell>{payment.quizTitle || payment.quizId.slice(0, 8)}</TableCell>
                        <TableCell className="font-semibold">₦{parseFloat(payment.amount).toLocaleString()}</TableCell>
                        <TableCell>
                          <Badge
                            variant={payment.status === "success" ? "default" : "secondary"}
                            className={payment.status === "success" ? "bg-chart-2" : ""}
                          >
                            {payment.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-muted-foreground">
                          {formatDistanceToNow(new Date(payment.createdAt), { addSuffix: true })}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <p className="text-center text-muted-foreground py-8" data-testid="text-no-payments">
                  {searchQuery ? "No payments found matching your search" : "No payment transactions yet"}
                </p>
              )}
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
