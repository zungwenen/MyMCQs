import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, BookOpen, Clock, Lock, TrendingUp } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useAuthStore } from "@/stores/authStore";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import ThemeToggle from "@/components/ThemeToggle";
import AuthModal from "@/components/AuthModal";
import MembershipModal from "@/components/MembershipModal";
import type { Quiz } from "@shared/schema";

export default function LandingPage() {
  const [searchQuery, setSearchQuery] = useState("");
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [membershipModalOpen, setMembershipModalOpen] = useState(false);
  const [pendingQuizId, setPendingQuizId] = useState<string | null>(null);
  const { isAuthenticated, user } = useAuthStore();
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: quizzesData, isLoading } = useQuery<{ quizzes: Array<Quiz & { questionsCount: number }> }>({
    queryKey: ["/api/quizzes"],
  });

  const filteredQuizzes = (quizzesData?.quizzes || []).filter((quiz) =>
    quiz.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
    quiz.description.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleStartQuiz = async (quiz: Quiz & { questionsCount: number }) => {
    if (!isAuthenticated) {
      setAuthModalOpen(true);
      return;
    }

    try {
      const res = await apiRequest("GET", `/api/quizzes/${quiz.id}/access`);
      const accessData = await res.json();

      if (!accessData.hasAccess && quiz.isPremium) {
        setPendingQuizId(quiz.id);
        setMembershipModalOpen(true);
      } else {
        setLocation(`/quiz/${quiz.id}`);
      }
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to check quiz access",
        variant: "destructive",
      });
    }
  };

  const handleAuthSuccess = () => {
    setAuthModalOpen(false);
    toast({
      title: "Welcome!",
      description: "You can now start taking quizzes",
    });
  };

  const handleMembershipSuccess = () => {
    setMembershipModalOpen(false);
    if (pendingQuizId) {
      setLocation(`/quiz/${pendingQuizId}`);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b sticky top-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-6 h-6 text-primary" />
            <h1 className="text-xl font-bold" data-testid="text-brand">Easyread IQ</h1>
          </div>
          <div className="flex items-center gap-3">
            <ThemeToggle />
            {isAuthenticated ? (
              <Button onClick={() => setLocation("/dashboard")} data-testid="button-dashboard">
                Dashboard
              </Button>
            ) : (
              <Button onClick={() => setAuthModalOpen(true)} data-testid="button-sign-in">
                Sign In
              </Button>
            )}
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          {!isAuthenticated && (
            <div className="mb-16">
              <div className="text-center mb-12">
                <h2 className="text-5xl md:text-6xl font-bold mb-6 bg-gradient-to-r from-primary to-chart-2 bg-clip-text text-transparent" data-testid="text-hero-title">
                  Master Every Subject with Confidence
                </h2>
                <p className="text-xl md:text-2xl text-muted-foreground mb-8 max-w-3xl mx-auto">
                  Test your knowledge, track your progress, and achieve your learning goals with our interactive MCQ platform
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
                  <Button 
                    size="lg"
                    onClick={() => setAuthModalOpen(true)}
                    data-testid="button-hero-get-started"
                  >
                    Get Started Free
                  </Button>
                  <Button 
                    size="lg" 
                    variant="outline"
                    onClick={() => document.getElementById('quizzes-section')?.scrollIntoView({ behavior: 'smooth' })}
                    data-testid="button-hero-browse"
                  >
                    Browse Quizzes
                  </Button>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
                <Card className="text-center p-6">
                  <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <BookOpen className="w-6 h-6 text-primary" />
                  </div>
                  <h3 className="font-semibold mb-2">Comprehensive Content</h3>
                  <p className="text-sm text-muted-foreground">Access a wide range of subjects and topics to master</p>
                </Card>
                <Card className="text-center p-6">
                  <div className="w-12 h-12 bg-chart-2/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Clock className="w-6 h-6 text-chart-2" />
                  </div>
                  <h3 className="font-semibold mb-2">Timed Practice</h3>
                  <p className="text-sm text-muted-foreground">Improve your speed and accuracy with timed quizzes</p>
                </Card>
                <Card className="text-center p-6">
                  <div className="w-12 h-12 bg-chart-4/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="w-6 h-6 text-chart-4" />
                  </div>
                  <h3 className="font-semibold mb-2">Track Progress</h3>
                  <p className="text-sm text-muted-foreground">Monitor your performance and identify areas to improve</p>
                </Card>
              </div>
            </div>
          )}

          <div id="quizzes-section" className="mb-8">
            <h2 className="text-4xl font-bold mb-3" data-testid="text-main-title">
              {isAuthenticated ? "Your Quizzes" : "Available Quizzes"}
            </h2>
            <p className="text-lg text-muted-foreground">
              {isAuthenticated 
                ? "Select a subject to test your knowledge and track your progress"
                : "Sign in to start your learning journey"
              }
            </p>
          </div>

          <div className="mb-8">
            <div className="relative max-w-lg">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <Input
                type="search"
                placeholder="Search quizzes..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 h-12"
                data-testid="input-search"
              />
            </div>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <Card key={i} className="animate-pulse">
                  <CardHeader className="space-y-3">
                    <div className="h-6 bg-muted rounded w-3/4"></div>
                    <div className="h-4 bg-muted rounded w-full"></div>
                  </CardHeader>
                  <CardContent>
                    <div className="h-10 bg-muted rounded"></div>
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {filteredQuizzes.map((quiz) => (
                <Card key={quiz.id} className="hover-elevate transition-all" data-testid={`card-quiz-${quiz.id}`}>
                  <CardHeader>
                    <div className="flex items-start justify-between mb-2">
                      <CardTitle className="text-xl" data-testid={`text-quiz-title-${quiz.id}`}>
                        {quiz.title}
                      </CardTitle>
                      {quiz.isPremium ? (
                        <Badge className="bg-primary text-primary-foreground" data-testid={`badge-premium-${quiz.id}`}>
                          <Lock className="w-3 h-3 mr-1" />
                          Premium
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="text-chart-2 border-chart-2" data-testid={`badge-free-${quiz.id}`}>
                          Free
                        </Badge>
                      )}
                    </div>
                    <CardDescription className="text-sm" data-testid={`text-quiz-desc-${quiz.id}`}>
                      {quiz.description}
                    </CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <BookOpen className="w-4 h-4" />
                        <span>{quiz.questionsCount} questions</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        <span>{quiz.duration} min</span>
                      </div>
                    </div>
                    <Button
                      onClick={() => handleStartQuiz(quiz)}
                      className="w-full"
                      variant={quiz.isPremium ? "outline" : "default"}
                      data-testid={`button-start-${quiz.id}`}
                    >
                      {quiz.isPremium ? "Unlock Quiz" : "Start Quiz"}
                    </Button>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {!isLoading && filteredQuizzes.length === 0 && (
            <div className="text-center py-12">
              <p className="text-muted-foreground" data-testid="text-no-quizzes">
                {searchQuery ? "No quizzes found matching your search" : "No quizzes available"}
              </p>
            </div>
          )}
        </div>
      </main>

      <AuthModal
        open={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        onSuccess={handleAuthSuccess}
      />
      
      <MembershipModal
        open={membershipModalOpen}
        onClose={() => setMembershipModalOpen(false)}
        onPurchaseSuccess={handleMembershipSuccess}
      />
    </div>
  );
}
