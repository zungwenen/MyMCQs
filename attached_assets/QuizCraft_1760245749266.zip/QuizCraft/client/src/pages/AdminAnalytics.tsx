import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import AdminSidebar from "@/components/AdminSidebar";
import AdminMobileHeader from "@/components/AdminMobileHeader";
import { Users, FileQuestion, DollarSign, TrendingUp, Award, Clock, Loader2 } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

interface AnalyticsData {
  totalUsers: number;
  totalRevenue: number;
  averageScore: number;
  activeQuizzes: number;
  recentAttempts: Array<{
    id: string;
    userId: string;
    quizId: string;
    score: number;
    completedAt: Date;
  }>;
}

export default function AdminAnalytics() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { data: analytics, isLoading } = useQuery<AnalyticsData>({
    queryKey: ["/api/admin/analytics"],
  });

  const stats = [
    { 
      label: "Total Users", 
      value: analytics?.totalUsers?.toLocaleString() || "0", 
      icon: Users, 
      color: "text-chart-1",
      description: "Registered users"
    },
    { 
      label: "Active Quizzes", 
      value: analytics?.activeQuizzes?.toString() || "0", 
      icon: FileQuestion, 
      color: "text-chart-2",
      description: "Published quizzes"
    },
    { 
      label: "Total Revenue", 
      value: `₦${analytics?.totalRevenue?.toLocaleString() || "0"}`, 
      icon: DollarSign, 
      color: "text-chart-3",
      description: "From premium quizzes"
    },
    { 
      label: "Average Score", 
      value: `${Math.round(analytics?.averageScore || 0)}%`, 
      icon: TrendingUp, 
      color: "text-chart-4",
      description: "Across all attempts"
    },
  ];

  const formatTimeAgo = (date: Date) => {
    return formatDistanceToNow(new Date(date), { addSuffix: true });
  };

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar 
        mobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />
      
      <main className="flex-1 overflow-auto">
        <AdminMobileHeader onMenuClick={() => setMobileMenuOpen(true)} />
        <div className="p-4 md:p-8">
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl md:text-3xl font-bold mb-2" data-testid="text-page-title">Analytics</h1>
            <p className="text-muted-foreground">Detailed insights and performance metrics</p>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
                {stats.map((stat) => {
                  const Icon = stat.icon;
                  return (
                    <Card key={stat.label} data-testid={`card-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}>
                      <CardHeader className="pb-3">
                        <div className="flex items-center justify-between">
                          <CardDescription>{stat.label}</CardDescription>
                          <Icon className={`w-5 h-5 ${stat.color}`} />
                        </div>
                      </CardHeader>
                      <CardContent>
                        <p className="text-3xl font-bold mb-1">{stat.value}</p>
                        <p className="text-xs text-muted-foreground">{stat.description}</p>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center gap-2">
                      <Award className="w-5 h-5" />
                      Performance Overview
                    </CardTitle>
                    <CardDescription>Quiz completion statistics</CardDescription>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="text-sm text-muted-foreground">Total Attempts</p>
                        <p className="text-2xl font-bold">{analytics?.recentAttempts?.length || 0}</p>
                      </div>
                      <Clock className="w-8 h-8 text-muted-foreground" />
                    </div>
                    <div className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <p className="text-sm text-muted-foreground">Pass Rate</p>
                        <p className="text-2xl font-bold">
                          {analytics?.recentAttempts?.length 
                            ? Math.round((analytics.recentAttempts.filter(a => a.score >= 70).length / analytics.recentAttempts.length) * 100)
                            : 0}%
                        </p>
                      </div>
                      <TrendingUp className="w-8 h-8 text-chart-2" />
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Recent Activity</CardTitle>
                    <CardDescription>Latest quiz completions</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-3">
                      {analytics?.recentAttempts && analytics.recentAttempts.length > 0 ? (
                        analytics.recentAttempts.slice(0, 5).map((attempt, index) => (
                          <div
                            key={attempt.id}
                            className="flex items-center justify-between p-3 rounded-lg border"
                            data-testid={`activity-${index}`}
                          >
                            <div className="flex-1">
                              <p className="font-medium text-sm">User {attempt.userId.slice(0, 8)}</p>
                              <p className="text-xs text-muted-foreground">{formatTimeAgo(attempt.completedAt)}</p>
                            </div>
                            <div className="text-right">
                              <p className={`font-semibold ${attempt.score >= 70 ? 'text-chart-2' : 'text-muted-foreground'}`}>
                                {Math.round((attempt.score / 100) * 100)}%
                              </p>
                            </div>
                          </div>
                        ))
                      ) : (
                        <p className="text-center text-muted-foreground py-4">No recent activity</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              <Card>
                <CardHeader>
                  <CardTitle>Quiz Performance Breakdown</CardTitle>
                  <CardDescription>Performance metrics by quiz</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-muted-foreground py-8">
                    Detailed quiz performance analytics coming soon
                  </p>
                </CardContent>
              </Card>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
