import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuthStore } from "@/stores/authStore";
import { User, Phone, Calendar, Award, Clock, Trophy, Crown, ArrowLeft } from "lucide-react";
import { formatDistanceToNow } from "date-fns";

export default function Profile() {
  const { user } = useAuthStore();
  const setUser = useAuthStore(state => state.setUser);
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [isEditingName, setIsEditingName] = useState(false);
  const [newName, setNewName] = useState(user?.name || "");

  // Sync newName with user data when it changes
  useEffect(() => {
    setNewName(user?.name || "");
  }, [user?.name]);

  const { data: statsData, isLoading: statsLoading } = useQuery<{
    totalAttempts: number;
    averageScore: number;
    bestScore: number;
    totalTimeSpent: number;
    uniqueQuizzes: number;
  }>({
    queryKey: ["/api/user/stats"],
  });

  const { data: membershipData } = useQuery<{
    membership: {
      id: string;
      planId: string;
      purchaseDate: string;
      expiryDate: string | null;
      status: string;
    } | null;
    hasAccess: boolean;
  }>({
    queryKey: ["/api/membership/user"],
  });

  const updateNameMutation = useMutation({
    mutationFn: async (name: string) => {
      const res = await apiRequest("PATCH", "/api/auth/me", { name });
      return res.json();
    },
    onSuccess: (data) => {
      setUser(data.user);
      queryClient.invalidateQueries({ queryKey: ["/api/auth/me"] });
      toast({
        title: "Profile updated",
        description: "Your name has been updated successfully",
      });
      setIsEditingName(false);
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update profile",
      });
    },
  });

  const handleUpdateName = () => {
    if (newName.trim()) {
      updateNameMutation.mutate(newName.trim());
    }
  };

  const formatTime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b sticky top-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 md:py-12 pb-20 md:pb-12">
        <div className="max-w-4xl mx-auto space-y-6">
          <div>
            <h1 className="text-2xl md:text-4xl font-bold mb-2" data-testid="text-page-title">Profile</h1>
            <p className="text-muted-foreground">Manage your account information and view your statistics</p>
          </div>

          {/* User Information Card */}
          <Card data-testid="card-user-info">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <User className="w-5 h-5" />
                Personal Information
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                {isEditingName ? (
                  <div className="flex gap-2">
                    <Input
                      id="name"
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      data-testid="input-name"
                    />
                    <Button
                      onClick={handleUpdateName}
                      disabled={updateNameMutation.isPending}
                      data-testid="button-save-name"
                    >
                      Save
                    </Button>
                    <Button
                      variant="outline"
                      onClick={() => {
                        setNewName(user?.name || "");
                        setIsEditingName(false);
                      }}
                      data-testid="button-cancel-name"
                    >
                      Cancel
                    </Button>
                  </div>
                ) : (
                  <div className="flex items-center justify-between">
                    <p className="text-lg" data-testid="text-name">{user?.name || "Not set"}</p>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setIsEditingName(true)}
                      data-testid="button-edit-name"
                    >
                      Edit
                    </Button>
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label className="flex items-center gap-2">
                  <Phone className="w-4 h-4" />
                  Phone Number
                </Label>
                <p className="text-lg" data-testid="text-phone">{user?.phoneNumber}</p>
              </div>

              {user?.createdAt && (
                <div className="space-y-2">
                  <Label className="flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Member Since
                  </Label>
                  <p className="text-lg" data-testid="text-member-since">
                    {formatDistanceToNow(new Date(user.createdAt), { addSuffix: true })}
                  </p>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Membership Status */}
          {membershipData?.hasAccess && (
            <Card className="border-primary/20 bg-primary/5" data-testid="card-membership">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <Crown className="w-5 h-5 text-primary" />
                    Premium Member
                  </CardTitle>
                  <Badge className="bg-chart-2 text-white">Active</Badge>
                </div>
                <CardDescription>
                  {membershipData.membership?.expiryDate
                    ? `Expires ${formatDistanceToNow(new Date(membershipData.membership.expiryDate), { addSuffix: true })}`
                    : "Lifetime Access"
                  }
                </CardDescription>
              </CardHeader>
            </Card>
          )}

          {/* Quiz Statistics */}
          <div>
            <h2 className="text-xl md:text-2xl font-bold mb-4">Quiz Statistics</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              <Card data-testid="card-stat-attempts">
                <CardHeader className="pb-3">
                  <CardDescription>Total Attempts</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-chart-1" />
                    <p className="text-3xl font-bold">
                      {statsLoading ? "..." : statsData?.totalAttempts || 0}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card data-testid="card-stat-average">
                <CardHeader className="pb-3">
                  <CardDescription>Average Score</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-chart-2" />
                    <p className="text-3xl font-bold">
                      {statsLoading ? "..." : `${statsData?.averageScore || 0}%`}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card data-testid="card-stat-best">
                <CardHeader className="pb-3">
                  <CardDescription>Best Score</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-chart-3" />
                    <p className="text-3xl font-bold">
                      {statsLoading ? "..." : `${statsData?.bestScore || 0}%`}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card data-testid="card-stat-time">
                <CardHeader className="pb-3">
                  <CardDescription>Total Time Spent</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Clock className="w-5 h-5 text-chart-4" />
                    <p className="text-3xl font-bold">
                      {statsLoading ? "..." : formatTime(statsData?.totalTimeSpent || 0)}
                    </p>
                  </div>
                </CardContent>
              </Card>

              <Card data-testid="card-stat-quizzes">
                <CardHeader className="pb-3">
                  <CardDescription>Unique Quizzes</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-2">
                    <Award className="w-5 h-5 text-chart-1" />
                    <p className="text-3xl font-bold">
                      {statsLoading ? "..." : statsData?.uniqueQuizzes || 0}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
