import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import AdminSidebar from "@/components/AdminSidebar";
import AdminMobileHeader from "@/components/AdminMobileHeader";
import { Plus, Pencil, Trash2, Loader2, ArrowLeft, CheckCircle } from "lucide-react";
import type { Question, Quiz } from "@shared/schema";

export default function ManageQuestions() {
  const { quizId } = useParams();
  const [, setLocation] = useLocation();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const [formData, setFormData] = useState({
    questionText: "",
    optionA: "",
    optionB: "",
    optionC: "",
    optionD: "",
    correctAnswer: "A",
    explanation: "",
  });
  const { toast } = useToast();

  const { data: quizData } = useQuery<{ quiz: Quiz; questions: Question[] }>({
    queryKey: ["/api/quizzes", quizId],
  });

  const { data: questionsData, isLoading } = useQuery<{ questions: Question[] }>({
    queryKey: ["/api/admin/quizzes", quizId, "questions"],
    queryFn: async () => {
      const res = await fetch(`/api/quizzes/${quizId}`, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch questions");
      return await res.json();
    },
  });

  const createQuestionMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      const options = [
        { id: "A", text: data.optionA },
        { id: "B", text: data.optionB },
        { id: "C", text: data.optionC },
        { id: "D", text: data.optionD },
      ];
      
      const questionData = {
        quizId,
        questionText: data.questionText,
        options,
        correctAnswer: data.correctAnswer,
        explanation: data.explanation || undefined,
        order: (questionsData?.questions?.length || 0) + 1,
      };

      const res = await apiRequest("POST", "/api/admin/questions", questionData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/quizzes", quizId, "questions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes", quizId] });
      setDialogOpen(false);
      resetForm();
      toast({ title: "Success", description: "Question created successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const updateQuestionMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: typeof formData }) => {
      const options = [
        { id: "A", text: data.optionA },
        { id: "B", text: data.optionB },
        { id: "C", text: data.optionC },
        { id: "D", text: data.optionD },
      ];

      const questionData = {
        questionText: data.questionText,
        options,
        correctAnswer: data.correctAnswer,
        explanation: data.explanation || undefined,
      };

      const res = await apiRequest("PATCH", `/api/admin/questions/${id}`, questionData);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/quizzes", quizId, "questions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes", quizId] });
      setEditingQuestion(null);
      setDialogOpen(false);
      resetForm();
      toast({ title: "Success", description: "Question updated successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const deleteQuestionMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("DELETE", `/api/admin/questions/${id}`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/quizzes", quizId, "questions"] });
      queryClient.invalidateQueries({ queryKey: ["/api/quizzes", quizId] });
      toast({ title: "Success", description: "Question deleted successfully" });
    },
    onError: (error: Error) => {
      toast({ title: "Error", description: error.message, variant: "destructive" });
    },
  });

  const resetForm = () => {
    setFormData({
      questionText: "",
      optionA: "",
      optionB: "",
      optionC: "",
      optionD: "",
      correctAnswer: "A",
      explanation: "",
    });
  };

  const handleOpenCreate = () => {
    resetForm();
    setEditingQuestion(null);
    setDialogOpen(true);
  };

  const handleOpenEdit = (question: Question) => {
    const options = question.options as Array<{ id: string; text: string }>;
    setFormData({
      questionText: question.questionText,
      optionA: options.find(o => o.id === "A")?.text || "",
      optionB: options.find(o => o.id === "B")?.text || "",
      optionC: options.find(o => o.id === "C")?.text || "",
      optionD: options.find(o => o.id === "D")?.text || "",
      correctAnswer: question.correctAnswer,
      explanation: question.explanation || "",
    });
    setEditingQuestion(question);
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (!formData.questionText.trim()) {
      toast({ title: "Error", description: "Question text is required", variant: "destructive" });
      return;
    }
    
    if (!formData.optionA.trim() || !formData.optionB.trim() || !formData.optionC.trim() || !formData.optionD.trim()) {
      toast({ title: "Error", description: "All options are required", variant: "destructive" });
      return;
    }

    if (editingQuestion) {
      updateQuestionMutation.mutate({ id: editingQuestion.id, data: formData });
    } else {
      createQuestionMutation.mutate(formData);
    }
  };

  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this question? This action cannot be undone.")) {
      deleteQuestionMutation.mutate(id);
    }
  };

  const isPending = createQuestionMutation.isPending || updateQuestionMutation.isPending || deleteQuestionMutation.isPending;

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar 
        mobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />
      
      <main className="flex-1 overflow-y-auto">
        <AdminMobileHeader onMenuClick={() => setMobileMenuOpen(true)} />
        <div className="container mx-auto p-4 md:p-8">
          <div className="mb-6 flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              onClick={() => setLocation("/admin/quizzes")}
              data-testid="button-back"
            >
              <ArrowLeft className="w-5 h-5" />
            </Button>
            <div>
              <h1 className="text-2xl md:text-3xl font-bold" data-testid="text-page-title">
                Manage Questions
              </h1>
              {quizData?.quiz && (
                <p className="text-muted-foreground mt-1">
                  {quizData.quiz.title}
                </p>
              )}
            </div>
          </div>

          <Card className="mb-6">
            <CardHeader className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
              <div>
                <CardTitle>Questions</CardTitle>
                <CardDescription>
                  Add and manage questions for this quiz
                </CardDescription>
              </div>
              <Button onClick={handleOpenCreate} className="w-full md:w-auto" data-testid="button-add-question">
                <Plus className="w-4 h-4 mr-2" />
                Add Question
              </Button>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-primary" />
                </div>
              ) : questionsData?.questions && questionsData.questions.length > 0 ? (
                <div className="space-y-4">
                  {questionsData.questions.map((question, index) => {
                    const options = question.options as Array<{ id: string; text: string }>;
                    return (
                      <Card key={question.id} data-testid={`card-question-${question.id}`}>
                        <CardHeader className="pb-3">
                          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-4">
                            <div className="flex-1">
                              <div className="flex items-center gap-3 mb-2">
                                <span className="font-semibold text-sm text-muted-foreground">
                                  Q{index + 1}
                                </span>
                                <CardTitle className="text-base">{question.questionText}</CardTitle>
                              </div>
                              <div className="space-y-2 mt-4">
                                {options.map((option) => (
                                  <div
                                    key={option.id}
                                    className={`flex items-center gap-2 text-sm ${
                                      option.id === question.correctAnswer
                                        ? "text-chart-2 font-medium"
                                        : "text-muted-foreground"
                                    }`}
                                  >
                                    {option.id === question.correctAnswer && (
                                      <CheckCircle className="w-4 h-4" />
                                    )}
                                    <span className="font-semibold">{option.id}.</span>
                                    <span>{option.text}</span>
                                  </div>
                                ))}
                              </div>
                              {question.explanation && (
                                <div className="mt-3 text-sm text-muted-foreground bg-muted p-3 rounded-md">
                                  <span className="font-semibold">Explanation: </span>
                                  {question.explanation}
                                </div>
                              )}
                            </div>
                            <div className="flex gap-2">
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => handleOpenEdit(question)}
                                data-testid={`button-edit-${question.id}`}
                              >
                                <Pencil className="w-4 h-4" />
                              </Button>
                              <Button
                                size="icon"
                                variant="ghost"
                                onClick={() => handleDelete(question.id)}
                                disabled={isPending}
                                data-testid={`button-delete-${question.id}`}
                              >
                                <Trash2 className="w-4 h-4 text-destructive" />
                              </Button>
                            </div>
                          </div>
                        </CardHeader>
                      </Card>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12">
                  <p className="text-muted-foreground" data-testid="text-no-questions">
                    No questions added yet. Click "Add Question" to create one.
                  </p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </main>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto p-4 md:p-6">
          <DialogHeader>
            <DialogTitle data-testid="text-dialog-title">
              {editingQuestion ? "Edit Question" : "Add New Question"}
            </DialogTitle>
            <DialogDescription>
              {editingQuestion ? "Update the question details below" : "Enter the question details below"}
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6 py-4">
            <div>
              <Label htmlFor="questionText">Question Text *</Label>
              <Textarea
                id="questionText"
                value={formData.questionText}
                onChange={(e) => setFormData({ ...formData, questionText: e.target.value })}
                placeholder="Enter the question..."
                className="mt-1.5"
                rows={3}
                data-testid="input-question-text"
              />
            </div>

            <div className="space-y-3">
              <Label>Options *</Label>
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-sm w-6">A.</span>
                  <Input
                    value={formData.optionA}
                    onChange={(e) => setFormData({ ...formData, optionA: e.target.value })}
                    placeholder="Option A"
                    data-testid="input-option-a"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-sm w-6">B.</span>
                  <Input
                    value={formData.optionB}
                    onChange={(e) => setFormData({ ...formData, optionB: e.target.value })}
                    placeholder="Option B"
                    data-testid="input-option-b"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-sm w-6">C.</span>
                  <Input
                    value={formData.optionC}
                    onChange={(e) => setFormData({ ...formData, optionC: e.target.value })}
                    placeholder="Option C"
                    data-testid="input-option-c"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-sm w-6">D.</span>
                  <Input
                    value={formData.optionD}
                    onChange={(e) => setFormData({ ...formData, optionD: e.target.value })}
                    placeholder="Option D"
                    data-testid="input-option-d"
                  />
                </div>
              </div>
            </div>

            <div>
              <Label>Correct Answer *</Label>
              <RadioGroup
                value={formData.correctAnswer}
                onValueChange={(value) => setFormData({ ...formData, correctAnswer: value })}
                className="mt-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="A" id="answer-a" data-testid="radio-answer-a" />
                  <Label htmlFor="answer-a" className="font-normal">Option A</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="B" id="answer-b" data-testid="radio-answer-b" />
                  <Label htmlFor="answer-b" className="font-normal">Option B</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="C" id="answer-c" data-testid="radio-answer-c" />
                  <Label htmlFor="answer-c" className="font-normal">Option C</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="D" id="answer-d" data-testid="radio-answer-d" />
                  <Label htmlFor="answer-d" className="font-normal">Option D</Label>
                </div>
              </RadioGroup>
            </div>

            <div>
              <Label htmlFor="explanation">Explanation (Optional)</Label>
              <Textarea
                id="explanation"
                value={formData.explanation}
                onChange={(e) => setFormData({ ...formData, explanation: e.target.value })}
                placeholder="Provide an explanation for the correct answer..."
                className="mt-1.5"
                rows={3}
                data-testid="input-explanation"
              />
            </div>
          </div>

          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setDialogOpen(false)}
              disabled={isPending}
              data-testid="button-cancel"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={isPending}
              data-testid="button-save"
            >
              {isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Saving...
                </>
              ) : (
                editingQuestion ? "Update Question" : "Create Question"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
