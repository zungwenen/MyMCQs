import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import AdminSidebar from "@/components/AdminSidebar";
import AdminMobileHeader from "@/components/AdminMobileHeader";
import { Settings, Save } from "lucide-react";

export default function QuizSettings() {
  const { toast } = useToast();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [settings, setSettings] = useState({
    defaultDuration: 30,
    defaultPassingScore: 70,
    allowReview: true,
    showCorrectAnswers: true,
    randomizeQuestions: false,
    randomizeOptions: false,
    maxAttempts: 0, // 0 = unlimited
    certificateEnabled: false,
  });

  const handleSave = () => {
    // In a real app, this would save to backend
    toast({
      title: "Settings saved",
      description: "Quiz settings have been updated successfully",
    });
  };

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar 
        mobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />
      
      <main className="flex-1 overflow-auto">
        <AdminMobileHeader onMenuClick={() => setMobileMenuOpen(true)} />
        <div className="p-4 md:p-8">
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl md:text-3xl font-bold mb-2" data-testid="text-page-title">Quiz Settings</h1>
            <p className="text-muted-foreground">Configure default quiz behavior and options</p>
          </div>

          <div className="max-w-3xl space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Settings className="w-5 h-5" />
                  Default Quiz Configuration
                </CardTitle>
                <CardDescription>
                  Set default values for new quizzes
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="defaultDuration">Default Duration (minutes)</Label>
                    <Input
                      id="defaultDuration"
                      type="number"
                      value={settings.defaultDuration}
                      onChange={(e) => setSettings({ ...settings, defaultDuration: parseInt(e.target.value) || 0 })}
                      data-testid="input-default-duration"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="defaultPassingScore">Default Passing Score (%)</Label>
                    <Input
                      id="defaultPassingScore"
                      type="number"
                      value={settings.defaultPassingScore}
                      onChange={(e) => setSettings({ ...settings, defaultPassingScore: parseInt(e.target.value) || 0 })}
                      data-testid="input-default-passing-score"
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="maxAttempts">Maximum Attempts (0 = unlimited)</Label>
                  <Input
                    id="maxAttempts"
                    type="number"
                    value={settings.maxAttempts}
                    onChange={(e) => setSettings({ ...settings, maxAttempts: parseInt(e.target.value) || 0 })}
                    data-testid="input-max-attempts"
                  />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Quiz Behavior</CardTitle>
                <CardDescription>Control how quizzes are presented to users</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="space-y-0.5">
                    <Label htmlFor="allowReview">Allow Answer Review</Label>
                    <p className="text-sm text-muted-foreground">Users can review their answers after submission</p>
                  </div>
                  <Switch
                    id="allowReview"
                    checked={settings.allowReview}
                    onCheckedChange={(checked) => setSettings({ ...settings, allowReview: checked })}
                    data-testid="switch-allow-review"
                  />
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="space-y-0.5">
                    <Label htmlFor="showCorrectAnswers">Show Correct Answers</Label>
                    <p className="text-sm text-muted-foreground">Display correct answers in results</p>
                  </div>
                  <Switch
                    id="showCorrectAnswers"
                    checked={settings.showCorrectAnswers}
                    onCheckedChange={(checked) => setSettings({ ...settings, showCorrectAnswers: checked })}
                    data-testid="switch-show-answers"
                  />
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="space-y-0.5">
                    <Label htmlFor="randomizeQuestions">Randomize Questions</Label>
                    <p className="text-sm text-muted-foreground">Show questions in random order</p>
                  </div>
                  <Switch
                    id="randomizeQuestions"
                    checked={settings.randomizeQuestions}
                    onCheckedChange={(checked) => setSettings({ ...settings, randomizeQuestions: checked })}
                    data-testid="switch-randomize-questions"
                  />
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="space-y-0.5">
                    <Label htmlFor="randomizeOptions">Randomize Answer Options</Label>
                    <p className="text-sm text-muted-foreground">Shuffle answer choices for each question</p>
                  </div>
                  <Switch
                    id="randomizeOptions"
                    checked={settings.randomizeOptions}
                    onCheckedChange={(checked) => setSettings({ ...settings, randomizeOptions: checked })}
                    data-testid="switch-randomize-options"
                  />
                </div>

                <div className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="space-y-0.5">
                    <Label htmlFor="certificateEnabled">Enable Certificates</Label>
                    <p className="text-sm text-muted-foreground">Award certificates for passing scores</p>
                  </div>
                  <Switch
                    id="certificateEnabled"
                    checked={settings.certificateEnabled}
                    onCheckedChange={(checked) => setSettings({ ...settings, certificateEnabled: checked })}
                    data-testid="switch-certificates"
                  />
                </div>
              </CardContent>
            </Card>

            <div className="flex justify-end">
              <Button onClick={handleSave} data-testid="button-save-settings">
                <Save className="w-4 h-4 mr-2" />
                Save Settings
              </Button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
