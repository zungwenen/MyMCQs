import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, BookOpen, Star, Award, Zap, Calendar, TrendingUp, Lock } from "lucide-react";

interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  progress: number;
  total: number;
}

const iconMap: Record<string, React.ElementType> = {
  BookOpen,
  Star,
  Award,
  Zap,
  Calendar,
  TrendingUp,
};

export default function Achievements() {
  const [, setLocation] = useLocation();

  const { data: achievementsData, isLoading } = useQuery<{ achievements: Achievement[] }>({
    queryKey: ["/api/user/achievements"],
  });

  const achievements = achievementsData?.achievements || [];
  const unlockedCount = achievements.filter(a => a.unlocked).length;

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b sticky top-0 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 z-10">
        <div className="container mx-auto px-4 h-16 flex items-center">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            data-testid="button-back"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 md:py-12 pb-20 md:pb-12">
        <div className="max-w-4xl mx-auto space-y-6">
          <div>
            <h1 className="text-2xl md:text-4xl font-bold mb-2" data-testid="text-page-title">Achievements</h1>
            <p className="text-muted-foreground">
              Track your progress and unlock badges by completing challenges
            </p>
          </div>

          {/* Summary Card */}
          <Card className="bg-gradient-to-br from-primary/10 to-primary/5">
            <CardHeader>
              <CardTitle>Your Progress</CardTitle>
              <CardDescription>
                {unlockedCount} of {achievements.length} achievements unlocked
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Progress 
                value={(unlockedCount / achievements.length) * 100} 
                className="h-3"
                data-testid="progress-achievements"
              />
            </CardContent>
          </Card>

          {/* Achievements Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {isLoading ? (
              <p className="col-span-2 text-center text-muted-foreground py-8">Loading achievements...</p>
            ) : (
              achievements.map((achievement) => {
                const Icon = iconMap[achievement.icon] || Award;
                const progressPercentage = (achievement.progress / achievement.total) * 100;

                return (
                  <Card
                    key={achievement.id}
                    className={achievement.unlocked ? "border-primary/50 bg-primary/5" : "opacity-75"}
                    data-testid={`card-achievement-${achievement.id}`}
                  >
                    <CardHeader>
                      <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                          <div className={`p-3 rounded-lg ${achievement.unlocked ? "bg-primary/20" : "bg-muted"}`}>
                            {achievement.unlocked ? (
                              <Icon className="w-6 h-6 text-primary" />
                            ) : (
                              <Lock className="w-6 h-6 text-muted-foreground" />
                            )}
                          </div>
                          <div>
                            <CardTitle className="text-lg">{achievement.name}</CardTitle>
                            <CardDescription>{achievement.description}</CardDescription>
                          </div>
                        </div>
                        {achievement.unlocked && (
                          <Badge className="bg-chart-2 text-white">Unlocked</Badge>
                        )}
                      </div>
                    </CardHeader>
                    <CardContent>
                      {!achievement.unlocked && achievement.total > 1 && (
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="text-muted-foreground">Progress</span>
                            <span className="font-medium">
                              {achievement.progress} / {achievement.total}
                            </span>
                          </div>
                          <Progress value={progressPercentage} className="h-2" />
                        </div>
                      )}
                    </CardContent>
                  </Card>
                );
              })
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
