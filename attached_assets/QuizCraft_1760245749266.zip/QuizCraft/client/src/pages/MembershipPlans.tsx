import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import AdminSidebar from "@/components/AdminSidebar";
import AdminMobileHeader from "@/components/AdminMobileHeader";
import { Crown, Plus, Edit, Trash2, DollarSign, Calendar } from "lucide-react";
import type { MembershipPlan } from "@shared/schema";

export default function MembershipPlans() {
  const { toast } = useToast();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [editingPlan, setEditingPlan] = useState<MembershipPlan | null>(null);

  const { data: plansData, isLoading } = useQuery({
    queryKey: ["/api/admin/membership/plans"],
  });

  const plans = (plansData as { plans: MembershipPlan[] })?.plans || [];

  const createPlanMutation = useMutation({
    mutationFn: async (data: { name: string; description: string; price: number; duration: number; isActive: boolean }) => {
      return apiRequest("POST", "/api/admin/membership/plans", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership/plans"] });
      toast({
        title: "Plan created",
        description: "Membership plan has been created successfully",
      });
      setIsCreateOpen(false);
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to create membership plan",
      });
    },
  });

  const updatePlanMutation = useMutation({
    mutationFn: async ({ id, ...data }: { id: string; name?: string; description?: string; price?: number; duration?: number; isActive?: boolean }) => {
      return apiRequest("PATCH", `/api/admin/membership/plans/${id}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership/plans"] });
      toast({
        title: "Plan updated",
        description: "Membership plan has been updated successfully",
      });
      setEditingPlan(null);
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update membership plan",
      });
    },
  });

  const deletePlanMutation = useMutation({
    mutationFn: async (id: string) => {
      return apiRequest("DELETE", `/api/admin/membership/plans/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/membership/plans"] });
      toast({
        title: "Plan deleted",
        description: "Membership plan has been deleted successfully",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete membership plan",
      });
    },
  });

  const togglePlanStatus = (plan: MembershipPlan) => {
    updatePlanMutation.mutate({
      id: plan.id,
      isActive: !plan.isActive,
    });
  };

  if (isLoading) {
    return (
      <div className="flex h-screen bg-background">
        <AdminSidebar 
          mobileOpen={mobileMenuOpen}
          onMobileClose={() => setMobileMenuOpen(false)}
        />
        <main className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <p className="text-muted-foreground">Loading membership plans...</p>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar 
        mobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />
      
      <main className="flex-1 overflow-auto">
        <AdminMobileHeader onMenuClick={() => setMobileMenuOpen(true)} />
        <div className="p-4 md:p-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-6 md:mb-8">
            <div>
              <h1 className="text-2xl md:text-3xl font-bold mb-2" data-testid="text-page-title">Membership Plans</h1>
              <p className="text-muted-foreground">Manage pricing and access for all-access memberships</p>
            </div>
            <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
              <DialogTrigger asChild>
                <Button className="w-full md:w-auto" data-testid="button-create-plan">
                  <Plus className="w-4 h-4 mr-2" />
                  Create Plan
                </Button>
              </DialogTrigger>
              <CreatePlanDialog 
                onSubmit={(data) => createPlanMutation.mutate(data)} 
                isPending={createPlanMutation.isPending}
              />
            </Dialog>
          </div>

          <div className="grid gap-6">
            {plans.map((plan) => (
              <Card key={plan.id} data-testid={`card-plan-${plan.id}`}>
                <CardHeader>
                  <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-lg bg-primary/10">
                        <Crown className="w-5 h-5 text-primary" />
                      </div>
                      <div>
                        <CardTitle>{plan.name}</CardTitle>
                        <CardDescription>{plan.description}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch
                        checked={plan.isActive}
                        onCheckedChange={() => togglePlanStatus(plan)}
                        data-testid={`switch-plan-active-${plan.id}`}
                      />
                      <Dialog open={editingPlan?.id === plan.id} onOpenChange={(open) => !open && setEditingPlan(null)}>
                        <DialogTrigger asChild>
                          <Button 
                            variant="outline" 
                            size="icon"
                            onClick={() => setEditingPlan(plan)}
                            data-testid={`button-edit-plan-${plan.id}`}
                          >
                            <Edit className="w-4 h-4" />
                          </Button>
                        </DialogTrigger>
                        <EditPlanDialog 
                          plan={plan}
                          onSubmit={(data) => updatePlanMutation.mutate({ id: plan.id, ...data })}
                          isPending={updatePlanMutation.isPending}
                        />
                      </Dialog>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => {
                          if (confirm("Are you sure you want to delete this membership plan?")) {
                            deletePlanMutation.mutate(plan.id);
                          }
                        }}
                        data-testid={`button-delete-plan-${plan.id}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center gap-6 text-sm">
                    <div className="flex items-center gap-2">
                      <DollarSign className="w-4 h-4 text-muted-foreground" />
                      <span className="font-semibold">₦{parseFloat(plan.price).toLocaleString()}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-muted-foreground" />
                      <span>{plan.duration === 0 ? "Lifetime" : `${plan.duration} days`}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className={`px-2 py-1 rounded text-xs ${plan.isActive ? 'bg-green-500/10 text-green-700 dark:text-green-400' : 'bg-gray-500/10 text-gray-700 dark:text-gray-400'}`}>
                        {plan.isActive ? "Active" : "Inactive"}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {plans.length === 0 && (
              <Card>
                <CardContent className="flex flex-col items-center justify-center py-12">
                  <Crown className="w-12 h-12 text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold mb-2">No membership plans yet</h3>
                  <p className="text-muted-foreground mb-4">Create your first membership plan to get started</p>
                  <Button onClick={() => setIsCreateOpen(true)} data-testid="button-create-first-plan">
                    <Plus className="w-4 h-4 mr-2" />
                    Create Plan
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>
    </div>
  );
}

function CreatePlanDialog({ onSubmit, isPending }: { onSubmit: (data: any) => void; isPending: boolean }) {
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    duration: "0",
    isActive: true,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      price: parseFloat(formData.price),
      duration: parseInt(formData.duration),
    });
  };

  return (
    <DialogContent data-testid="dialog-create-plan">
      <form onSubmit={handleSubmit}>
        <DialogHeader>
          <DialogTitle>Create Membership Plan</DialogTitle>
          <DialogDescription>
            Create a new all-access membership plan for users
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="name">Plan Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Premium All Access"
              required
              data-testid="input-plan-name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="One-time payment for lifetime access to all premium quizzes"
              required
              data-testid="input-plan-description"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="price">Price (₦)</Label>
              <Input
                id="price"
                type="number"
                step="0.01"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                placeholder="5000.00"
                required
                data-testid="input-plan-price"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="duration">Duration (days, 0 = lifetime)</Label>
              <Input
                id="duration"
                type="number"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                placeholder="0"
                required
                data-testid="input-plan-duration"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Switch
              id="isActive"
              checked={formData.isActive}
              onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
              data-testid="switch-plan-active"
            />
            <Label htmlFor="isActive">Active (visible to users)</Label>
          </div>
        </div>

        <DialogFooter>
          <Button type="submit" disabled={isPending} data-testid="button-submit-create-plan">
            {isPending ? "Creating..." : "Create Plan"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}

function EditPlanDialog({ plan, onSubmit, isPending }: { plan: MembershipPlan; onSubmit: (data: any) => void; isPending: boolean }) {
  const [formData, setFormData] = useState({
    name: plan.name,
    description: plan.description,
    price: plan.price,
    duration: plan.duration.toString(),
    isActive: plan.isActive,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      ...formData,
      price: parseFloat(formData.price),
      duration: parseInt(formData.duration),
    });
  };

  return (
    <DialogContent data-testid="dialog-edit-plan">
      <form onSubmit={handleSubmit}>
        <DialogHeader>
          <DialogTitle>Edit Membership Plan</DialogTitle>
          <DialogDescription>
            Update the membership plan details
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="edit-name">Plan Name</Label>
            <Input
              id="edit-name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              required
              data-testid="input-edit-plan-name"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="edit-description">Description</Label>
            <Textarea
              id="edit-description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              required
              data-testid="input-edit-plan-description"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="edit-price">Price (₦)</Label>
              <Input
                id="edit-price"
                type="number"
                step="0.01"
                value={formData.price}
                onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                required
                data-testid="input-edit-plan-price"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="edit-duration">Duration (days, 0 = lifetime)</Label>
              <Input
                id="edit-duration"
                type="number"
                value={formData.duration}
                onChange={(e) => setFormData({ ...formData, duration: e.target.value })}
                required
                data-testid="input-edit-plan-duration"
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            <Switch
              id="edit-isActive"
              checked={formData.isActive}
              onCheckedChange={(checked) => setFormData({ ...formData, isActive: checked })}
              data-testid="switch-edit-plan-active"
            />
            <Label htmlFor="edit-isActive">Active (visible to users)</Label>
          </div>
        </div>

        <DialogFooter>
          <Button type="submit" disabled={isPending} data-testid="button-submit-edit-plan">
            {isPending ? "Updating..." : "Update Plan"}
          </Button>
        </DialogFooter>
      </form>
    </DialogContent>
  );
}
