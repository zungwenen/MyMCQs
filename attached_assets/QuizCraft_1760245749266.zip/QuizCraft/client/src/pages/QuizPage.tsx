import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import QuizProgress from "@/components/QuizProgress";
import QuizTimer from "@/components/QuizTimer";
import QuestionCard from "@/components/QuestionCard";
import { useLocation, useParams } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useQuizStore } from "@/stores/quizStore";
import { useToast } from "@/hooks/use-toast";
import type { Question, Quiz } from "@shared/schema";

export default function QuizPage() {
  const [, setLocation] = useLocation();
  const params = useParams();
  const quizId = params.id;
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const { toast } = useToast();
  
  const {
    answers,
    markedForReview,
    timeRemaining,
    isTimerRunning,
    setAnswer,
    toggleMarkForReview,
    decrementTime,
    pauseTimer,
    startQuiz,
    resetQuiz,
  } = useQuizStore();

  const { data: quizData, isLoading } = useQuery<{ 
    questions: Question[]; 
    quiz: Quiz 
  }>({
    queryKey: ["/api/quizzes", quizId, "questions"],
    enabled: !!quizId,
  });

  const submitQuizMutation = useMutation({
    mutationFn: async (submissionData: {
      answers: Record<string, string>;
      markedForReview: string[];
      timeSpent: number;
    }) => {
      const res = await apiRequest("POST", `/api/quizzes/${quizId}/submit`, submissionData);
      return await res.json();
    },
    onSuccess: (data) => {
      resetQuiz();
      queryClient.invalidateQueries({ queryKey: ["/api/attempts"] });
      setLocation(`/results/${data.attempt.id}`);
    },
    onError: (error: Error) => {
      toast({
        title: "Submission failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    },
  });

  // Initialize quiz when data is loaded
  useEffect(() => {
    if (quizData?.quiz) {
      startQuiz(quizData.quiz.id, quizData.quiz.duration);
    }
  }, [quizData?.quiz, startQuiz]);

  // Timer countdown effect
  useEffect(() => {
    if (!isTimerRunning || timeRemaining <= 0) return;

    const interval = setInterval(() => {
      decrementTime();
    }, 1000);

    return () => clearInterval(interval);
  }, [isTimerRunning, timeRemaining, decrementTime]);

  // Auto-submit when time runs out
  useEffect(() => {
    if (timeRemaining === 0 && quizData?.quiz && !submitQuizMutation.isPending) {
      handleSubmit();
    }
  }, [timeRemaining]);

  const handleAnswerSelect = (optionId: string) => {
    if (quizData?.questions[currentQuestionIndex]) {
      setAnswer(quizData.questions[currentQuestionIndex].id, optionId);
    }
  };

  const handleToggleReview = () => {
    if (quizData?.questions[currentQuestionIndex]) {
      toggleMarkForReview(quizData.questions[currentQuestionIndex].id);
    }
  };

  const handleNext = () => {
    if (quizData && currentQuestionIndex < quizData.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const handleSubmit = () => {
    if (!quizData?.quiz) return;

    const timeSpent = (quizData.quiz.duration * 60) - timeRemaining;
    const markedArray = Array.from(markedForReview);

    submitQuizMutation.mutate({
      answers,
      markedForReview: markedArray,
      timeSpent,
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!quizData || !quizData.questions.length) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold mb-2">Quiz not found</h2>
          <Button onClick={() => setLocation("/dashboard")}>Back to Dashboard</Button>
        </div>
      </div>
    );
  }

  const currentQuestion = quizData.questions[currentQuestionIndex];
  const isCurrentMarked = markedForReview.has(currentQuestion.id);
  const currentAnswer = answers[currentQuestion.id];

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b bg-background sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between gap-4 flex-wrap">
            <div className="flex-1 min-w-[200px]">
              <QuizProgress
                current={currentQuestionIndex + 1}
                total={quizData.questions.length}
              />
            </div>
            <QuizTimer
              seconds={timeRemaining}
            />
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 pb-20 md:pb-8">
        <QuestionCard
          question={currentQuestion.questionText}
          options={currentQuestion.options}
          selectedAnswer={currentAnswer}
          onAnswerSelect={handleAnswerSelect}
          isMarkedForReview={isCurrentMarked}
          onToggleReview={handleToggleReview}
        />

        <div className="max-w-3xl mx-auto mt-6 flex items-center justify-between gap-4">
          <Button
            onClick={handlePrevious}
            disabled={currentQuestionIndex === 0}
            variant="outline"
            data-testid="button-previous"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>

          {currentQuestionIndex === quizData.questions.length - 1 ? (
            <Button 
              onClick={handleSubmit} 
              disabled={submitQuizMutation.isPending}
              data-testid="button-submit"
            >
              {submitQuizMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                "Submit Quiz"
              )}
            </Button>
          ) : (
            <Button 
              onClick={handleNext} 
              data-testid="button-next"
            >
              Next
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          )}
        </div>
      </main>
    </div>
  );
}
