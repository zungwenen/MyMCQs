import { useState } from "react";
import AdminSidebar from "@/components/AdminSidebar";
import AdminMobileHeader from "@/components/AdminMobileHeader";
import { Card } from "@/components/ui/card";
import { Users, FileQuestion, DollarSign, TrendingUp, Loader2 } from "lucide-react";
import { useQuery } from "@tanstack/react-query";

interface AnalyticsData {
  totalUsers: number;
  totalRevenue: number;
  averageScore: number;
  activeQuizzes: number;
  recentAttempts: Array<{
    id: string;
    userId: string;
    quizId: string;
    score: number;
    completedAt: Date;
  }>;
}

export default function AdminDashboard() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const { data: analytics, isLoading } = useQuery<AnalyticsData>({
    queryKey: ["/api/admin/analytics"],
  });

  const stats = [
    { 
      label: "Total Users", 
      value: analytics?.totalUsers.toLocaleString() || "0", 
      icon: Users, 
      color: "text-chart-1" 
    },
    { 
      label: "Active Quizzes", 
      value: analytics?.activeQuizzes.toString() || "0", 
      icon: FileQuestion, 
      color: "text-chart-2" 
    },
    { 
      label: "Revenue", 
      value: `₦${analytics?.totalRevenue.toLocaleString() || "0"}`, 
      icon: DollarSign, 
      color: "text-chart-3" 
    },
    { 
      label: "Avg. Score", 
      value: `${Math.round(analytics?.averageScore || 0)}%`, 
      icon: TrendingUp, 
      color: "text-chart-4" 
    },
  ];

  const formatTimeAgo = (date: Date) => {
    const seconds = Math.floor((new Date().getTime() - new Date(date).getTime()) / 1000);
    
    if (seconds < 60) return "just now";
    if (seconds < 3600) return `${Math.floor(seconds / 60)} minutes ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)} hours ago`;
    return `${Math.floor(seconds / 86400)} days ago`;
  };

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar 
        mobileOpen={mobileMenuOpen}
        onMobileClose={() => setMobileMenuOpen(false)}
      />
      
      <main className="flex-1 overflow-auto">
        <AdminMobileHeader onMenuClick={() => setMobileMenuOpen(true)} />
        <div className="p-4 md:p-8">
          <div className="mb-6 md:mb-8">
            <h1 className="text-2xl md:text-3xl font-bold mb-2" data-testid="text-dashboard-title">Dashboard</h1>
            <p className="text-muted-foreground">Welcome back, Admin</p>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-12">
              <Loader2 className="w-8 h-8 animate-spin text-primary" />
            </div>
          ) : (
            <>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
                {stats.map((stat) => {
                  const Icon = stat.icon;
                  return (
                    <Card key={stat.label} className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-sm text-muted-foreground">{stat.label}</span>
                        <Icon className={`w-5 h-5 ${stat.color}`} />
                      </div>
                      <p className="text-3xl font-bold" data-testid={`text-${stat.label.toLowerCase().replace(/\s+/g, '-')}`}>
                        {stat.value}
                      </p>
                    </Card>
                  );
                })}
              </div>

              <Card className="p-6">
                <h2 className="text-xl font-semibold mb-6" data-testid="text-recent-activity">Recent Activity</h2>
                <div className="space-y-4">
                  {analytics?.recentAttempts && analytics.recentAttempts.length > 0 ? (
                    analytics.recentAttempts.map((attempt, index) => (
                      <div
                        key={attempt.id}
                        className="flex items-center justify-between p-4 rounded-lg border hover-elevate"
                        data-testid={`activity-${index}`}
                      >
                        <div className="flex-1">
                          <p className="font-medium">User {attempt.userId.slice(0, 8)}</p>
                          <p className="text-sm text-muted-foreground">Quiz {attempt.quizId.slice(0, 8)}</p>
                        </div>
                        <div className="flex items-center gap-6">
                          <div className="text-right">
                            <p className="font-semibold">{Math.round((attempt.score / 100) * 100)}%</p>
                            <p className="text-xs text-muted-foreground">
                              {formatTimeAgo(attempt.completedAt)}
                            </p>
                          </div>
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-center text-muted-foreground py-4">No recent activity</p>
                  )}
                </div>
              </Card>
            </>
          )}
        </div>
      </main>
    </div>
  );
}
