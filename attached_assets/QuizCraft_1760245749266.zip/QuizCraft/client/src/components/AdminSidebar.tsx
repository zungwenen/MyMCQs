import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent } from "@/components/ui/sheet";
import {
  LayoutDashboard,
  FileQuestion,
  Settings,
  CreditCard,
  BarChart3,
  LogOut,
  Crown,
  Split,
} from "lucide-react";
import { useAuthStore } from "@/stores/authStore";
import { apiRequest } from "@/lib/queryClient";

const menuItems = [
  { path: "/admin", label: "Dashboard", icon: LayoutDashboard },
  { path: "/admin/quizzes", label: "Manage Quizzes", icon: FileQuestion },
  { path: "/admin/membership", label: "Membership Plans", icon: Crown },
  { path: "/admin/settings", label: "Quiz Settings", icon: Settings },
  { path: "/admin/split-payments", label: "Split Payments", icon: Split },
  { path: "/admin/payments", label: "Payments", icon: CreditCard },
  { path: "/admin/analytics", label: "Analytics", icon: BarChart3 },
];

interface AdminSidebarProps {
  mobileOpen?: boolean;
  onMobileClose?: () => void;
}

function SidebarContent({ onItemClick }: { onItemClick?: () => void }) {
  const [location, setLocation] = useLocation();
  const { logout } = useAuthStore();

  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/admin/logout");
      logout();
      setLocation("/admin/login");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  return (
    <>
      <div className="p-6 border-b border-sidebar-border">
        <h1 className="text-xl font-bold text-sidebar-foreground" data-testid="text-admin-title">
          Admin Panel
        </h1>
      </div>

      <nav className="flex-1 p-4 space-y-1 overflow-y-auto">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = location === item.path;

          return (
            <Link key={item.path} href={item.path}>
              <Button
                variant="ghost"
                className={`w-full justify-start gap-3 ${
                  isActive ? "bg-sidebar-accent" : ""
                }`}
                onClick={onItemClick}
                data-testid={`link-${item.label.toLowerCase().replace(/\s+/g, '-')}`}
              >
                <Icon className="w-5 h-5" />
                {item.label}
              </Button>
            </Link>
          );
        })}
      </nav>

      <div className="p-4 border-t border-sidebar-border">
        <Button
          variant="ghost"
          className="w-full justify-start gap-3 text-destructive hover:text-destructive"
          onClick={handleLogout}
          data-testid="button-logout"
        >
          <LogOut className="w-5 h-5" />
          Logout
        </Button>
      </div>
    </>
  );
}

export default function AdminSidebar({ mobileOpen = false, onMobileClose }: AdminSidebarProps) {
  return (
    <>
      {/* Desktop Sidebar - hidden on mobile */}
      <div className="hidden md:flex md:w-64 h-screen bg-sidebar border-r border-sidebar-border flex-col">
        <SidebarContent />
      </div>

      {/* Mobile Sidebar - Sheet drawer */}
      <Sheet open={mobileOpen} onOpenChange={onMobileClose}>
        <SheetContent side="left" className="w-64 p-0 bg-sidebar border-sidebar-border">
          <div className="h-full flex flex-col">
            <SidebarContent onItemClick={onMobileClose} />
          </div>
        </SheetContent>
      </Sheet>
    </>
  );
}
