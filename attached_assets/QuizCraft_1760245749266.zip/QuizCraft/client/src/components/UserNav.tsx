import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { User, Settings, LogOut, Trophy } from "lucide-react";
import ThemeToggle from "./ThemeToggle";

interface UserNavProps {
  userName?: string;
  userPhone?: string;
  onProfileClick?: () => void;
  onAchievementsClick?: () => void;
  onSettingsClick?: () => void;
  onLogout?: () => void;
}

export default function UserNav({ userName = "User", userPhone, onProfileClick, onAchievementsClick, onSettingsClick, onLogout }: UserNavProps) {
  const initials = userName
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="flex items-center gap-3">
      <ThemeToggle />
      
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" className="relative h-10 w-10 rounded-full" data-testid="button-user-menu">
            <Avatar>
              <AvatarFallback className="bg-primary text-primary-foreground">
                {initials}
              </AvatarFallback>
            </Avatar>
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          <DropdownMenuLabel>
            <div className="flex flex-col space-y-1">
              <p className="text-sm font-medium" data-testid="text-user-name">{userName}</p>
              {userPhone && (
                <p className="text-xs text-muted-foreground" data-testid="text-user-phone">
                  {userPhone}
                </p>
              )}
            </div>
          </DropdownMenuLabel>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={onProfileClick} data-testid="menu-profile">
            <User className="mr-2 h-4 w-4" />
            Profile
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onAchievementsClick} data-testid="menu-achievements">
            <Trophy className="mr-2 h-4 w-4" />
            Achievements
          </DropdownMenuItem>
          <DropdownMenuItem onClick={onSettingsClick} data-testid="menu-settings">
            <Settings className="mr-2 h-4 w-4" />
            Settings
          </DropdownMenuItem>
          <DropdownMenuSeparator />
          <DropdownMenuItem onClick={onLogout} data-testid="menu-logout">
            <LogOut className="mr-2 h-4 w-4" />
            Logout
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
