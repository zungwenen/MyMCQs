import { Home, User, Trophy, LogOut } from "lucide-react";
import { useLocation } from "wouter";
import { useAuthStore } from "@/stores/authStore";
import { apiRequest } from "@/lib/queryClient";

export default function MobileBottomNav() {
  const [location, setLocation] = useLocation();
  const { logout } = useAuthStore();

  const handleLogout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout");
      logout();
      setLocation("/");
    } catch (error) {
      console.error("Logout failed:", error);
    }
  };

  const navItems = [
    {
      id: "home",
      label: "Home",
      icon: Home,
      path: "/dashboard",
      onClick: () => setLocation("/dashboard"),
    },
    {
      id: "profile",
      label: "Profile",
      icon: User,
      path: "/profile",
      onClick: () => setLocation("/profile"),
    },
    {
      id: "perks",
      label: "Perks",
      icon: Trophy,
      path: "/achievements",
      onClick: () => setLocation("/achievements"),
    },
    {
      id: "logout",
      label: "Logout",
      icon: LogOut,
      path: null,
      onClick: handleLogout,
    },
  ];

  return (
    <nav 
      className="fixed bottom-0 left-0 right-0 z-50 md:hidden bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-t"
      data-testid="nav-mobile-bottom"
    >
      <div className="grid grid-cols-4 h-16">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = item.path ? location === item.path : false;
          
          return (
            <button
              key={item.id}
              onClick={item.onClick}
              className={`flex flex-col items-center justify-center gap-1 hover-elevate active-elevate-2 transition-colors ${
                isActive ? "text-primary" : "text-muted-foreground"
              }`}
              aria-current={isActive ? "page" : undefined}
              data-testid={`button-nav-${item.id}`}
            >
              <Icon className={`w-5 h-5 ${isActive ? "text-primary" : ""}`} />
              <span className="text-[9px] font-medium">{item.label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
}
