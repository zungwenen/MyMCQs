import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CheckCircle, Crown, Loader2, Calendar, DollarSign, Mail } from "lucide-react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { MembershipPlan } from "@shared/schema";
import { z } from "zod";

interface MembershipModalProps {
  open: boolean;
  onClose: () => void;
  onPurchaseSuccess?: () => void;
}

const emailSchema = z.string().email("Please enter a valid email address");

export default function MembershipModal({ 
  open, 
  onClose, 
  onPurchaseSuccess 
}: MembershipModalProps) {
  const { toast } = useToast();
  const [paymentUrl, setPaymentUrl] = useState<string | null>(null);
  const [selectedPlan, setSelectedPlan] = useState<MembershipPlan | null>(null);
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState<string | null>(null);

  const { data: plansData, isLoading } = useQuery({
    queryKey: ["/api/membership/plans/active"],
    enabled: open,
  });

  const plans = (plansData as { plans: MembershipPlan[] })?.plans || [];

  useEffect(() => {
    if (plans.length > 0 && !selectedPlan) {
      setSelectedPlan(plans[0]);
    }
  }, [plans, selectedPlan]);

  const initializePayment = useMutation({
    mutationFn: async ({ planId, email }: { planId: string; email: string }) => {
      const res = await apiRequest("POST", "/api/payments/initialize-membership", { planId, email });
      return await res.json();
    },
    onSuccess: (data: { authorizationUrl: string; reference: string }) => {
      setPaymentUrl(data.authorizationUrl);
      
      // Open Paystack payment page in a new window
      const paymentWindow = window.open(data.authorizationUrl, "_blank", "width=600,height=700");
      
      // Poll for payment completion
      const pollInterval = setInterval(async () => {
        try {
          const verifyRes = await apiRequest("POST", "/api/payments/verify", { 
            reference: data.reference 
          });
          const verifyData = await verifyRes.json();
          
          if (verifyData.success) {
            clearInterval(pollInterval);
            paymentWindow?.close();
            queryClient.invalidateQueries({ queryKey: ["/api/membership/user"] });
            toast({
              title: "Welcome to Premium!",
              description: "You now have unlimited access to all premium quizzes",
            });
            onPurchaseSuccess?.();
            onClose();
          }
        } catch (error) {
          // Payment not yet completed, continue polling
        }
      }, 3000); // Poll every 3 seconds
      
      // Stop polling after 5 minutes
      setTimeout(() => clearInterval(pollInterval), 5 * 60 * 1000);
    },
    onError: (error: Error) => {
      toast({
        title: "Payment initialization failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    },
  });

  const handlePurchase = () => {
    if (!selectedPlan) return;
    
    // Validate email
    const validation = emailSchema.safeParse(email);
    if (!validation.success) {
      setEmailError(validation.error.errors[0].message);
      return;
    }
    
    setEmailError(null);
    initializePayment.mutate({ planId: selectedPlan.id, email });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] sm:max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-lg sm:text-xl" data-testid="text-membership-title">
            <Crown className="w-5 h-5 sm:w-6 sm:h-6 text-primary" />
            Unlock All Premium Quizzes
          </DialogTitle>
          <DialogDescription className="text-sm">
            One-time payment for unlimited access to all premium content
          </DialogDescription>
        </DialogHeader>

        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <Loader2 className="w-8 h-8 animate-spin text-primary" />
          </div>
        ) : plans.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No membership plans available at the moment</p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Plan Selection */}
            {plans.length > 1 && (
              <div className="grid gap-4">
                {plans.map((plan) => (
                  <Card
                    key={plan.id}
                    className={`p-4 cursor-pointer transition-all ${
                      selectedPlan?.id === plan.id
                        ? "border-primary border-2 bg-primary/5"
                        : "hover-elevate"
                    }`}
                    onClick={() => setSelectedPlan(plan)}
                    data-testid={`plan-option-${plan.id}`}
                  >
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-semibold text-lg">{plan.name}</h4>
                        <p className="text-sm text-muted-foreground">{plan.description}</p>
                      </div>
                      <div className="text-right">
                        <div className="text-2xl font-bold text-primary">
                          ₦{parseFloat(plan.price).toLocaleString()}
                        </div>
                        <div className="text-xs text-muted-foreground">
                          {plan.duration === 0 ? "Lifetime" : `${plan.duration} days`}
                        </div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            )}

            {/* Selected Plan Details */}
            {selectedPlan && (
              <Card className="p-4 sm:p-6 border-2 border-primary/20 bg-primary/5">
                <div className="text-center mb-4 sm:mb-6">
                  <div className="inline-flex p-2 sm:p-3 bg-primary/10 rounded-full mb-3 sm:mb-4">
                    <Crown className="w-6 h-6 sm:w-8 sm:h-8 text-primary" />
                  </div>
                  <h3 className="text-xl sm:text-2xl font-bold mb-2" data-testid="text-selected-plan-name">
                    {selectedPlan.name}
                  </h3>
                  <div className="text-2xl sm:text-4xl font-bold text-primary mb-2" data-testid="text-selected-plan-price">
                    ₦{parseFloat(selectedPlan.price).toLocaleString()}
                  </div>
                  <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="w-4 h-4" />
                    <span>{selectedPlan.duration === 0 ? "Lifetime Access" : `${selectedPlan.duration} Days Access`}</span>
                  </div>
                </div>

                {/* Email Input */}
                <div className="space-y-2 mb-4 sm:mb-6">
                  <Label htmlFor="membership-email" className="flex items-center gap-2 text-sm sm:text-base">
                    <Mail className="w-4 h-4" />
                    Email Address
                  </Label>
                  <Input
                    id="membership-email"
                    type="email"
                    placeholder="your.email@example.com"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      setEmailError(null);
                    }}
                    className={emailError ? "border-destructive" : ""}
                    data-testid="input-membership-email"
                  />
                  {emailError && (
                    <p className="text-sm text-destructive" data-testid="text-email-error">{emailError}</p>
                  )}
                  <p className="text-xs text-muted-foreground">
                    Required for payment confirmation and receipt
                  </p>
                </div>

                <div className="space-y-3 mb-6">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5 flex-shrink-0" />
                    <p className="text-sm">Access to all premium quizzes</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5 flex-shrink-0" />
                    <p className="text-sm">Unlimited quiz attempts</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5 flex-shrink-0" />
                    <p className="text-sm">Instant feedback on answers</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5 flex-shrink-0" />
                    <p className="text-sm">Detailed performance analytics</p>
                  </div>
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5 flex-shrink-0" />
                    <p className="text-sm">Access to all future premium content</p>
                  </div>
                </div>

                <Button
                  onClick={handlePurchase}
                  className="w-full"
                  size="lg"
                  disabled={initializePayment.isPending || !!paymentUrl}
                  data-testid="button-purchase-membership"
                >
                  {initializePayment.isPending ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Processing...
                    </>
                  ) : paymentUrl ? (
                    "Waiting for payment..."
                  ) : (
                    <>
                      <Crown className="w-4 h-4 mr-2" />
                      Get Premium Access - ₦{parseFloat(selectedPlan.price).toLocaleString()}
                    </>
                  )}
                </Button>

                <p className="text-xs text-center text-muted-foreground mt-4">
                  Secure payment powered by Paystack
                </p>
              </Card>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}
