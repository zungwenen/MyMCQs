import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Flag, CheckCircle, XCircle, Volume2, VolumeX } from "lucide-react";
import { useSpeech } from "@/hooks/useSpeech";

interface Option {
  id: string;
  text: string;
}

interface QuestionCardProps {
  question: string;
  options: Option[];
  selectedAnswer?: string;
  onAnswerSelect: (optionId: string) => void;
  isMarkedForReview?: boolean;
  onToggleReview?: () => void;
  showFeedback?: boolean;
  correctAnswer?: string;
}

export default function QuestionCard({
  question,
  options,
  selectedAnswer,
  onAnswerSelect,
  isMarkedForReview = false,
  onToggleReview,
  showFeedback = false,
  correctAnswer,
}: QuestionCardProps) {
  const { toggle, currentText, isSpeaking } = useSpeech();

  return (
    <div className="w-full max-w-3xl mx-auto">
      <Card className="p-6 md:p-8">
        <div className="flex items-start justify-between gap-4 mb-6">
          <h2 className="text-lg md:text-xl font-medium leading-relaxed flex-1" data-testid="text-question">
            {question}
          </h2>
          <Button
            variant="ghost"
            size="icon"
            onClick={() => toggle(question)}
            aria-label="Read question aloud"
            data-testid="button-speak-question"
          >
            {isSpeaking && currentText === question ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </Button>
        </div>

        <div className="space-y-3 mb-6">
          {options.map((option) => {
            const isSelected = selectedAnswer === option.id;
            const isCorrect = showFeedback && correctAnswer === option.id;
            const isWrong = showFeedback && isSelected && correctAnswer !== option.id;

            return (
              <div
                key={option.id}
                className={`flex items-center gap-2 p-4 rounded-lg border-2 transition-all ${
                  isCorrect
                    ? "border-chart-2 bg-chart-2/10"
                    : isWrong
                    ? "border-destructive bg-destructive/10"
                    : isSelected
                    ? "border-primary bg-primary/5"
                    : "border-border"
                }`}
                data-testid={`option-container-${option.id}`}
              >
                <button
                  onClick={() => !showFeedback && onAnswerSelect(option.id)}
                  disabled={showFeedback}
                  className="flex items-center gap-3 flex-1 text-left hover-elevate"
                  data-testid={`button-option-${option.id}`}
                >
                  <div
                    className={`w-5 h-5 rounded-full border-2 flex items-center justify-center ${
                      isSelected ? "border-primary bg-primary" : "border-muted-foreground"
                    }`}
                  >
                    {isSelected && <div className="w-2 h-2 bg-white rounded-full" />}
                  </div>
                  <span className="flex-1">{option.text}</span>
                  {showFeedback && isCorrect && <CheckCircle className="w-5 h-5 text-chart-2" />}
                  {showFeedback && isWrong && <XCircle className="w-5 h-5 text-destructive" />}
                </button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => toggle(option.text)}
                  aria-label={`Read option ${option.text} aloud`}
                  data-testid={`button-speak-option-${option.id}`}
                  className="shrink-0"
                >
                  {isSpeaking && currentText === option.text ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                </Button>
              </div>
            );
          })}
        </div>

        {onToggleReview && (
          <div className="flex items-center justify-between pt-4 border-t">
            <button
              onClick={onToggleReview}
              className="flex items-center gap-2 text-sm hover-elevate p-2 rounded-md"
              data-testid="button-mark-review"
            >
              <Checkbox checked={isMarkedForReview} />
              <Flag className={`w-4 h-4 ${isMarkedForReview ? "fill-primary text-primary" : ""}`} />
              <span>Mark for review</span>
            </button>
          </div>
        )}
      </Card>
    </div>
  );
}
