import { useState } from "react";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Phone, ArrowRight, Loader2 } from "lucide-react";
import OTPInput from "./OTPInput";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useAuthStore } from "@/stores/authStore";

interface AuthModalProps {
  open: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

export default function AuthModal({ open, onClose, onSuccess }: AuthModalProps) {
  const [step, setStep] = useState<"phone" | "otp">("phone");
  const [phone, setPhone] = useState("");
  const [countdown, setCountdown] = useState(0);
  const [sendMethod, setSendMethod] = useState<"whatsapp" | "sms">("whatsapp");
  const { toast } = useToast();
  const { setUser } = useAuthStore();

  const sendOtpMutation = useMutation({
    mutationFn: async (phoneNumber: string) => {
      const res = await apiRequest("POST", "/api/auth/send-otp", { phoneNumber });
      return await res.json();
    },
    onSuccess: (data: { success: boolean; method: "whatsapp" | "sms" }) => {
      setStep("otp");
      setSendMethod(data.method);
      setCountdown(60);
      
      const interval = setInterval(() => {
        setCountdown((prev) => {
          if (prev <= 1) {
            clearInterval(interval);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);

      toast({
        title: "Verification code sent",
        description: `We sent a 6-digit code via ${data.method === "whatsapp" ? "WhatsApp" : "SMS"}`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to send code",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    },
  });

  const verifyOtpMutation = useMutation({
    mutationFn: async ({ phoneNumber, otp }: { phoneNumber: string; otp: string }) => {
      const res = await apiRequest("POST", "/api/auth/verify-otp", { phoneNumber, otp });
      return await res.json();
    },
    onSuccess: (data: { success: boolean; user: any }) => {
      setUser(data.user);
      toast({
        title: "Welcome!",
        description: "You've successfully signed in",
      });
      onSuccess?.();
      onClose();
      setStep("phone");
      setPhone("");
    },
    onError: (error: Error) => {
      toast({
        title: "Verification failed",
        description: error.message || "Invalid or expired code",
        variant: "destructive",
      });
    },
  });

  const handleSendOTP = () => {
    if (!phone.startsWith('+')) {
      toast({
        title: "Invalid phone number",
        description: "Please include country code (e.g., +234 for Nigeria)",
        variant: "destructive",
      });
      return;
    }
    sendOtpMutation.mutate(phone);
  };

  const handleResend = () => {
    sendOtpMutation.mutate(phone);
  };

  const handleVerifyOTP = (otp: string) => {
    verifyOtpMutation.mutate({ phoneNumber: phone, otp });
  };

  const isLoading = sendOtpMutation.isPending || verifyOtpMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-[95vw] sm:max-w-md p-0 gap-0 bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-950 dark:to-cyan-950">
        <div className="p-4 sm:p-8">
          {step === "otp" ? (
            <div className="space-y-4 sm:space-y-6">
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-primary rounded-full flex items-center justify-center mb-3 sm:mb-4">
                  <Phone className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold mb-2">Verify Your Phone</h2>
                <p className="text-sm sm:text-base text-muted-foreground">
                  We sent a code via {sendMethod === "whatsapp" ? "WhatsApp" : "SMS"} to {phone}
                </p>
              </div>

              <Card className="border-0 shadow-lg">
                <CardContent className="pt-6 space-y-6">
                  <OTPInput
                    length={6}
                    onComplete={handleVerifyOTP}
                    disabled={isLoading}
                  />

                  {countdown > 0 ? (
                    <p className="text-sm text-center text-muted-foreground">
                      Resend code in {countdown}s
                    </p>
                  ) : (
                    <Button
                      onClick={handleResend}
                      variant="ghost"
                      disabled={isLoading}
                      className="w-full"
                      data-testid="button-resend-sms"
                    >
                      Resend via SMS
                    </Button>
                  )}

                  {isLoading && (
                    <div className="flex items-center justify-center gap-2 text-sm text-muted-foreground">
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Verifying...
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          ) : (
            <div className="space-y-4 sm:space-y-6">
              <div className="flex flex-col items-center text-center">
                <div className="w-12 h-12 sm:w-16 sm:h-16 bg-primary rounded-full flex items-center justify-center mb-3 sm:mb-4">
                  <Phone className="w-6 h-6 sm:w-8 sm:h-8 text-white" />
                </div>
                <h2 className="text-xl sm:text-2xl font-bold mb-2">Welcome to Easyread IQ</h2>
                <p className="text-sm sm:text-base text-muted-foreground">Enter your phone number to get started</p>
              </div>

              <Card className="border-0 shadow-lg">
                <CardHeader>
                  <CardTitle className="text-lg">Phone Verification</CardTitle>
                  <CardDescription>
                    We'll send you a verification code via WhatsApp or SMS
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number</Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="+2349023544240"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && phone) {
                            handleSendOTP();
                          }
                        }}
                        className="pl-9"
                        data-testid="input-phone"
                      />
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Include country code (e.g., +234 for Nigeria)
                    </p>
                  </div>

                  <Button
                    onClick={handleSendOTP}
                    disabled={!phone || isLoading}
                    className="w-full"
                    data-testid="button-send-otp"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Sending via WhatsApp...
                      </>
                    ) : (
                      <>
                        Send Verification Code
                        <ArrowRight className="w-4 h-4 ml-2" />
                      </>
                    )}
                  </Button>

                  <p className="text-xs text-center text-muted-foreground">
                    By continuing, you agree to our Terms of Service and Privacy Policy
                  </p>
                </CardContent>
              </Card>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
