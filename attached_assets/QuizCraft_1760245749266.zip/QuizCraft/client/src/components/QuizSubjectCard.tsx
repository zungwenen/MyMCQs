import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Lock } from "lucide-react";

interface QuizSubjectCardProps {
  title: string;
  description: string;
  isPremium: boolean;
  questionsCount: number;
  duration: number;
  onStartQuiz: () => void;
}

export default function QuizSubjectCard({
  title,
  description,
  isPremium,
  questionsCount,
  duration,
  onStartQuiz,
}: QuizSubjectCardProps) {

  return (
    <Card className="p-6 hover-elevate transition-all flex flex-col h-full">
      <div className="flex items-start justify-between mb-3">
        <div className="p-3 bg-primary/10 rounded-lg">
          <BookOpen className="w-6 h-6 text-primary" />
        </div>
        {isPremium ? (
          <Badge className="bg-primary text-primary-foreground no-default-hover-elevate" data-testid={`badge-premium-${title}`}>
            <Lock className="w-3 h-3 mr-1" />
            Premium
          </Badge>
        ) : (
          <Badge variant="outline" className="text-chart-2 border-chart-2" data-testid={`badge-free-${title}`}>
            Free
          </Badge>
        )}
      </div>

      <h3 className="text-xl font-semibold mb-2" data-testid={`text-title-${title}`}>
        {title}
      </h3>
      <p className="text-sm text-muted-foreground mb-4 line-clamp-2 flex-grow" data-testid={`text-description-${title}`}>
        {description}
      </p>

      <div className="flex items-center gap-4 mb-4 text-sm text-muted-foreground">
        <span data-testid={`text-questions-${title}`}>{questionsCount} Questions</span>
        <span>•</span>
        <span data-testid={`text-duration-${title}`}>{duration} mins</span>
      </div>

      <Button
        onClick={onStartQuiz}
        className="w-full"
        variant={isPremium ? "outline" : "default"}
        data-testid={`button-start-${title}`}
      >
        {isPremium ? "Unlock Quiz" : "Start Quiz"}
      </Button>
    </Card>
  );
}
