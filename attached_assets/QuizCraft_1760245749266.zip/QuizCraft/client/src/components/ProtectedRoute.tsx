import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuthStore } from "@/stores/authStore";

interface ProtectedRouteProps {
  children: React.ReactNode;
  requireAdmin?: boolean;
}

export default function ProtectedRoute({ children, requireAdmin = false }: ProtectedRouteProps) {
  const [, setLocation] = useLocation();
  const { isAuthenticated, isAdmin } = useAuthStore();

  useEffect(() => {
    if (requireAdmin && !isAdmin) {
      setLocation("/admin/login");
    } else if (!requireAdmin && !isAuthenticated) {
      setLocation("/");
    }
  }, [isAuthenticated, isAdmin, requireAdmin, setLocation]);

  if (requireAdmin && !isAdmin) {
    return null;
  }

  if (!requireAdmin && !isAuthenticated) {
    return null;
  }

  return <>{children}</>;
}
