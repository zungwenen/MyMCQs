import { Progress } from "@/components/ui/progress";

interface QuizProgressProps {
  current: number;
  total: number;
  showPercentage?: boolean;
}

export default function QuizProgress({ current, total, showPercentage = true }: QuizProgressProps) {
  const percentage = Math.round((current / total) * 100);

  return (
    <div className="w-full">
      <div className="flex items-center justify-between mb-2">
        <span className="text-sm font-medium" data-testid="text-progress">
          Question {current} of {total}
        </span>
        {showPercentage && (
          <span className="text-sm text-muted-foreground" data-testid="text-percentage">
            {percentage}%
          </span>
        )}
      </div>
      <Progress value={percentage} className="h-2" data-testid="progress-bar" />
    </div>
  );
}
