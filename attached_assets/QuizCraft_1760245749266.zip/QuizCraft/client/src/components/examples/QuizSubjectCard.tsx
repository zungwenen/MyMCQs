import QuizSubjectCard from '../QuizSubjectCard';

export default function QuizSubjectCardExample() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 p-6">
      <QuizSubjectCard
        title="Business Law"
        description="Test your knowledge of corporate regulations, contracts, and legal frameworks"
        isPremium={false}
        questionsCount={25}
        duration={30}
        onStartQuiz={() => console.log('Starting Business Law quiz')}
      />
      <QuizSubjectCard
        title="Corporate Governance"
        description="Master the principles of board management, compliance, and ethical leadership"
        isPremium={true}
        isPaid={true}
        questionsCount={30}
        duration={45}
        onStartQuiz={() => console.log('Starting Corporate Governance quiz')}
      />
      <QuizSubjectCard
        title="Advanced Taxation"
        description="Deep dive into tax planning, international taxation, and compliance strategies"
        isPremium={true}
        isPaid={false}
        questionsCount={40}
        duration={60}
        onStartQuiz={() => console.log('Starting Advanced Taxation quiz')}
      />
    </div>
  );
}
