import { useState } from 'react';
import PaymentModal from '../PaymentModal';
import { Button } from '@/components/ui/button';

export default function PaymentModalExample() {
  const [open, setOpen] = useState(false);

  return (
    <div className="p-6">
      <Button onClick={() => setOpen(true)} data-testid="button-open-payment">
        Open Payment Modal
      </Button>
      <PaymentModal
        open={open}
        onClose={() => setOpen(false)}
        quizTitle="Advanced Taxation"
        price={29.99}
        onPaymentSuccess={() => console.log('Payment successful')}
      />
    </div>
  );
}
