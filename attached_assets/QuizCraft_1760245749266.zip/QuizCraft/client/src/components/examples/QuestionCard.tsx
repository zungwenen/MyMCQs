import { useState } from 'react';
import QuestionCard from '../QuestionCard';

export default function QuestionCardExample() {
  const [selected, setSelected] = useState<string>('');
  const [marked, setMarked] = useState(false);

  const options = [
    { id: 'a', text: 'The board of directors has ultimate authority over company decisions' },
    { id: 'b', text: 'Shareholders elect the board members to represent their interests' },
    { id: 'c', text: 'The CEO reports directly to shareholders' },
    { id: 'd', text: 'Independent directors must own company shares' },
  ];

  return (
    <div className="p-6 space-y-8">
      <QuestionCard
        question="Which of the following best describes the role of a board of directors in corporate governance?"
        options={options}
        selectedAnswer={selected}
        onAnswerSelect={setSelected}
        isMarkedForReview={marked}
        onToggleReview={() => setMarked(!marked)}
      />
      
      <QuestionCard
        question="What is the primary purpose of internal controls in a business?"
        options={[
          { id: 'a', text: 'To increase company profits' },
          { id: 'b', text: 'To safeguard assets and ensure accuracy of financial records' },
          { id: 'c', text: 'To reduce employee headcount' },
          { id: 'd', text: 'To eliminate all business risks' },
        ]}
        selectedAnswer="c"
        onAnswerSelect={() => {}}
        showFeedback={true}
        correctAnswer="b"
      />
    </div>
  );
}
