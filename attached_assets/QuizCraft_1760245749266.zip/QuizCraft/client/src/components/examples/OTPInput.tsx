import OTPInput from '../OTPInput';

export default function OTPInputExample() {
  return (
    <div className="p-6 max-w-md mx-auto">
      <h3 className="text-lg font-semibold mb-4 text-center">Enter Verification Code</h3>
      <OTPInput
        length={6}
        onComplete={(otp) => console.log('OTP Complete:', otp)}
      />
    </div>
  );
}
