import QuizTimer from '../QuizTimer';

export default function QuizTimerExample() {
  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center gap-6">
        <span className="text-sm text-muted-foreground">Normal:</span>
        <QuizTimer initialSeconds={300} onTimeUp={() => console.log('Time up!')} />
      </div>
      <div className="flex items-center gap-6">
        <span className="text-sm text-muted-foreground">Warning:</span>
        <QuizTimer initialSeconds={25} />
      </div>
      <div className="flex items-center gap-6">
        <span className="text-sm text-muted-foreground">Critical:</span>
        <QuizTimer initialSeconds={8} />
      </div>
    </div>
  );
}
