import { Route, Switch } from 'wouter';
import AdminSidebar from '../AdminSidebar';

function DashboardPage() {
  return <div className="p-6"><h2 className="text-2xl font-bold">Dashboard</h2></div>;
}

function QuizzesPage() {
  return <div className="p-6"><h2 className="text-2xl font-bold">Manage Quizzes</h2></div>;
}

export default function AdminSidebarExample() {
  return (
    <div className="flex h-screen">
      <AdminSidebar />
      <div className="flex-1">
        <Switch>
          <Route path="/admin" component={DashboardPage} />
          <Route path="/admin/quizzes" component={QuizzesPage} />
          <Route component={DashboardPage} />
        </Switch>
      </div>
    </div>
  );
}
