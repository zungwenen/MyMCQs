import ResultsCard from '../ResultsCard';

export default function ResultsCardExample() {
  return (
    <div className="p-6 space-y-8">
      <ResultsCard
        score={22}
        totalQuestions={25}
        correctAnswers={22}
        incorrectAnswers={2}
        unattempted={1}
        timeSpent="24:35"
        passingScore={20}
        onRetake={() => console.log('Retake quiz')}
        onReview={() => console.log('Review answers')}
      />
      
      <ResultsCard
        score={15}
        totalQuestions={30}
        correctAnswers={15}
        incorrectAnswers={10}
        unattempted={5}
        timeSpent="38:12"
        passingScore={24}
        onRetake={() => console.log('Retake quiz')}
        onReview={() => console.log('Review answers')}
      />
    </div>
  );
}
