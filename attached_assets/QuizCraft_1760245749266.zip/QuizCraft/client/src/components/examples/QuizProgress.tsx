import QuizProgress from '../QuizProgress';

export default function QuizProgressExample() {
  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6">
      <QuizProgress current={5} total={25} />
      <QuizProgress current={15} total={30} />
      <QuizProgress current={28} total={30} showPercentage={false} />
    </div>
  );
}
