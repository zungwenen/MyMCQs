import UserNav from '../UserNav';

export default function UserNavExample() {
  return (
    <div className="p-6 flex justify-end bg-background border-b">
      <UserNav
        userName="John Doe"
        userPhone="+1 (555) 123-4567"
        onProfileClick={() => console.log('Profile clicked')}
        onLogout={() => console.log('Logout clicked')}
      />
    </div>
  );
}
