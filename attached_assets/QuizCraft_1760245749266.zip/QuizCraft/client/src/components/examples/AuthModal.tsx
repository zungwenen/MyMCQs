import { useState } from 'react';
import AuthModal from '../AuthModal';
import { Button } from '@/components/ui/button';

export default function AuthModalExample() {
  const [open, setOpen] = useState(false);

  return (
    <div className="p-6">
      <Button onClick={() => setOpen(true)} data-testid="button-open-auth">
        Open Auth Modal
      </Button>
      <AuthModal
        open={open}
        onClose={() => setOpen(false)}
        onSuccess={() => console.log('Authentication successful')}
      />
    </div>
  );
}
