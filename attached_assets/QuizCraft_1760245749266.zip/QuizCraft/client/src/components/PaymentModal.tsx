import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CheckCircle, Lock, Loader2, Mail } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";

interface PaymentModalProps {
  open: boolean;
  onClose: () => void;
  quiz: {
    id: string;
    title: string;
    price: string;
  };
  onSuccess?: () => void;
}

const emailSchema = z.string().email("Please enter a valid email address");

export default function PaymentModal({ 
  open, 
  onClose, 
  quiz,
  onSuccess 
}: PaymentModalProps) {
  const { toast } = useToast();
  const [paymentUrl, setPaymentUrl] = useState<string | null>(null);
  const [email, setEmail] = useState("");
  const [emailError, setEmailError] = useState<string | null>(null);

  const initializePayment = useMutation({
    mutationFn: async (email: string) => {
      const res = await apiRequest("POST", "/api/payments/initialize", { quizId: quiz.id, email });
      return await res.json();
    },
    onSuccess: (data: { authorizationUrl: string; reference: string }) => {
      setPaymentUrl(data.authorizationUrl);
      
      // Open Paystack payment page in a new window
      const paymentWindow = window.open(data.authorizationUrl, "_blank", "width=600,height=700");
      
      // Poll for payment completion
      const pollInterval = setInterval(async () => {
        try {
          const verifyRes = await apiRequest("POST", "/api/payments/verify", { 
            reference: data.reference 
          });
          const verifyData = await verifyRes.json();
          
          if (verifyData.success) {
            clearInterval(pollInterval);
            paymentWindow?.close();
            toast({
              title: "Payment successful!",
              description: "You now have access to this quiz",
            });
            onSuccess?.();
            onClose();
          }
        } catch (error) {
          // Payment not yet completed, continue polling
        }
      }, 3000); // Poll every 3 seconds
      
      // Stop polling after 5 minutes
      setTimeout(() => clearInterval(pollInterval), 5 * 60 * 1000);
    },
    onError: (error: Error) => {
      toast({
        title: "Payment initialization failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    },
  });

  const handlePayment = () => {
    // Validate email
    const validation = emailSchema.safeParse(email);
    if (!validation.success) {
      setEmailError(validation.error.errors[0].message);
      return;
    }
    
    setEmailError(null);
    initializePayment.mutate(email);
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle data-testid="text-payment-title">Unlock Premium Quiz</DialogTitle>
          <DialogDescription>
            Get lifetime access to {quiz.title}
          </DialogDescription>
        </DialogHeader>

        <Card className="p-6 border-2 border-primary/20 bg-primary/5">
          <div className="text-center mb-6">
            <div className="inline-flex p-3 bg-primary/10 rounded-full mb-4">
              <Lock className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-2xl font-bold mb-2" data-testid="text-quiz-title">{quiz.title}</h3>
            <div className="text-4xl font-bold text-primary mb-4" data-testid="text-price">
              ₦{parseFloat(quiz.price).toLocaleString()}
            </div>
          </div>

          {/* Email Input */}
          <div className="space-y-2 mb-6">
            <Label htmlFor="payment-email" className="flex items-center gap-2">
              <Mail className="w-4 h-4" />
              Email Address
            </Label>
            <Input
              id="payment-email"
              type="email"
              placeholder="your.email@example.com"
              value={email}
              onChange={(e) => {
                setEmail(e.target.value);
                setEmailError(null);
              }}
              className={emailError ? "border-destructive" : ""}
              data-testid="input-payment-email"
            />
            {emailError && (
              <p className="text-sm text-destructive" data-testid="text-email-error">{emailError}</p>
            )}
            <p className="text-xs text-muted-foreground">
              Required for payment confirmation and receipt
            </p>
          </div>

          <div className="space-y-3 mb-6">
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5 flex-shrink-0" />
              <p className="text-sm">Unlimited attempts</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5 flex-shrink-0" />
              <p className="text-sm">Instant feedback on answers</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5 flex-shrink-0" />
              <p className="text-sm">Detailed performance analytics</p>
            </div>
            <div className="flex items-start gap-3">
              <CheckCircle className="w-5 h-5 text-chart-2 mt-0.5 flex-shrink-0" />
              <p className="text-sm">Lifetime access</p>
            </div>
          </div>

          <Button
            onClick={handlePayment}
            className="w-full"
            size="lg"
            disabled={initializePayment.isPending || !!paymentUrl}
            data-testid="button-pay-now"
          >
            {initializePayment.isPending ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : paymentUrl ? (
              "Waiting for payment..."
            ) : (
              `Pay Now - ₦${parseFloat(quiz.price).toLocaleString()}`
            )}
          </Button>

          <p className="text-xs text-center text-muted-foreground mt-4">
            Secure payment powered by Paystack
          </p>
        </Card>
      </DialogContent>
    </Dialog>
  );
}
