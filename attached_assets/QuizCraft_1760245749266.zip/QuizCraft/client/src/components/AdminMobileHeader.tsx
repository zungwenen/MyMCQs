import { Button } from "@/components/ui/button";
import { Menu } from "lucide-react";

interface AdminMobileHeaderProps {
  onMenuClick: () => void;
}

export default function AdminMobileHeader({ onMenuClick }: AdminMobileHeaderProps) {
  return (
    <div className="md:hidden sticky top-0 z-10 bg-background border-b border-border p-4 flex items-center gap-3">
      <Button
        variant="ghost"
        size="icon"
        onClick={onMenuClick}
        data-testid="button-mobile-menu"
      >
        <Menu className="w-5 h-5" />
      </Button>
      <h1 className="text-lg font-bold">Admin Panel</h1>
    </div>
  );
}
