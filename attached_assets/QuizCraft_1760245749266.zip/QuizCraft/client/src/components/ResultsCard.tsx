import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trophy, Clock, Target, TrendingUp, RotateCcw } from "lucide-react";

interface ResultsCardProps {
  score: number;
  totalQuestions: number;
  correctAnswers: number;
  incorrectAnswers: number;
  unattempted: number;
  timeSpent: string;
  passingScore: number;
  onRetake?: () => void;
  onReview?: () => void;
}

export default function ResultsCard({
  score,
  totalQuestions,
  correctAnswers,
  incorrectAnswers,
  unattempted,
  timeSpent,
  passingScore,
  onRetake,
  onReview,
}: ResultsCardProps) {
  const passed = score >= passingScore;
  const percentage = Math.round((score / totalQuestions) * 100);

  return (
    <div className="w-full max-w-2xl mx-auto">
      <Card className="p-8">
        <div className="text-center mb-8">
          <div className={`inline-flex p-4 rounded-full mb-4 ${passed ? "bg-chart-2/10" : "bg-chart-4/10"}`}>
            {passed ? (
              <Trophy className="w-12 h-12 text-chart-2" />
            ) : (
              <Target className="w-12 h-12 text-chart-4" />
            )}
          </div>
          
          <h2 className="text-3xl font-bold mb-2" data-testid="text-result-status">
            {passed ? "Congratulations! 🎉" : "Keep Practicing!"}
          </h2>
          
          <p className="text-muted-foreground mb-6">
            {passed ? "You've passed the quiz!" : "You'll do better next time"}
          </p>

          <div className="text-6xl font-bold mb-2" data-testid="text-score">
            {percentage}%
          </div>
          
          <p className="text-sm text-muted-foreground" data-testid="text-score-detail">
            {score} out of {totalQuestions} points
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center justify-center gap-2 mb-2">
              <div className="w-3 h-3 bg-chart-2 rounded-full" />
              <span className="text-sm text-muted-foreground">Correct</span>
            </div>
            <p className="text-2xl font-bold" data-testid="text-correct">
              {correctAnswers}
            </p>
          </div>

          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center justify-center gap-2 mb-2">
              <div className="w-3 h-3 bg-destructive rounded-full" />
              <span className="text-sm text-muted-foreground">Incorrect</span>
            </div>
            <p className="text-2xl font-bold" data-testid="text-incorrect">
              {incorrectAnswers}
            </p>
          </div>

          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center justify-center gap-2 mb-2">
              <div className="w-3 h-3 bg-muted-foreground rounded-full" />
              <span className="text-sm text-muted-foreground">Skipped</span>
            </div>
            <p className="text-2xl font-bold" data-testid="text-skipped">
              {unattempted}
            </p>
          </div>

          <div className="text-center p-4 bg-muted/50 rounded-lg">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Clock className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Time</span>
            </div>
            <p className="text-2xl font-bold" data-testid="text-time">
              {timeSpent}
            </p>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
          {onReview && (
            <Button
              onClick={onReview}
              variant="outline"
              className="flex-1"
              data-testid="button-review"
            >
              <TrendingUp className="w-4 h-4 mr-2" />
              Review Answers
            </Button>
          )}
          {onRetake && (
            <Button
              onClick={onRetake}
              className="flex-1"
              data-testid="button-retake"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Retake Quiz
            </Button>
          )}
        </div>
      </Card>
    </div>
  );
}
