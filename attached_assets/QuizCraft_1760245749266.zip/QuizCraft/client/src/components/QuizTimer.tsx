import { Clock } from "lucide-react";

interface QuizTimerProps {
  seconds: number;
}

export default function QuizTimer({ seconds }: QuizTimerProps) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  const isWarning = seconds < 30;
  const isCritical = seconds < 10;

  return (
    <div
      className={`flex items-center gap-2 font-mono text-lg ${
        isCritical ? "text-destructive animate-pulse" : isWarning ? "text-chart-4" : ""
      }`}
      data-testid="timer-display"
    >
      <Clock className="w-5 h-5" />
      <span className="font-semibold">
        {String(minutes).padStart(2, "0")}:{String(remainingSeconds).padStart(2, "0")}
      </span>
    </div>
  );
}
