import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { User, Admin } from "@shared/schema";

interface AuthState {
  user: User | null;
  admin: Admin | null;
  isAuthenticated: boolean;
  isAdmin: boolean;
  setUser: (user: User | null) => void;
  setAdmin: (admin: Admin | null) => void;
  logout: () => void;
}

export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      admin: null,
      isAuthenticated: false,
      isAdmin: false,
      setUser: (user) =>
        set({
          user,
          isAuthenticated: !!user,
          isAdmin: false,
          admin: null,
        }),
      setAdmin: (admin) =>
        set({
          admin,
          isAdmin: !!admin,
          isAuthenticated: false,
          user: null,
        }),
      logout: () =>
        set({
          user: null,
          admin: null,
          isAuthenticated: false,
          isAdmin: false,
        }),
    }),
    {
      name: "auth-storage",
    }
  )
);
