import { create } from "zustand";

interface QuizState {
  currentQuizId: string | null;
  answers: Record<string, string>;
  markedForReview: Set<string>;
  timeRemaining: number;
  isTimerRunning: boolean;
  startQuiz: (quizId: string, duration: number) => void;
  setAnswer: (questionId: string, answer: string) => void;
  toggleMarkForReview: (questionId: string) => void;
  decrementTime: () => void;
  pauseTimer: () => void;
  resumeTimer: () => void;
  resetQuiz: () => void;
}

export const useQuizStore = create<QuizState>((set) => ({
  currentQuizId: null,
  answers: {},
  markedForReview: new Set(),
  timeRemaining: 0,
  isTimerRunning: false,

  startQuiz: (quizId, duration) =>
    set({
      currentQuizId: quizId,
      answers: {},
      markedForReview: new Set(),
      timeRemaining: duration * 60, // Convert minutes to seconds
      isTimerRunning: true,
    }),

  setAnswer: (questionId, answer) =>
    set((state) => ({
      answers: { ...state.answers, [questionId]: answer },
    })),

  toggleMarkForReview: (questionId) =>
    set((state) => {
      const newMarked = new Set(state.markedForReview);
      if (newMarked.has(questionId)) {
        newMarked.delete(questionId);
      } else {
        newMarked.add(questionId);
      }
      return { markedForReview: newMarked };
    }),

  decrementTime: () =>
    set((state) => ({
      timeRemaining: Math.max(0, state.timeRemaining - 1),
    })),

  pauseTimer: () => set({ isTimerRunning: false }),
  
  resumeTimer: () => set({ isTimerRunning: true }),

  resetQuiz: () =>
    set({
      currentQuizId: null,
      answers: {},
      markedForReview: new Set(),
      timeRemaining: 0,
      isTimerRunning: false,
    }),
}));
