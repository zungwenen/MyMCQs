import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import LandingPage from "@/pages/LandingPage";
import UserDashboard from "@/pages/UserDashboard";
import QuizPage from "@/pages/QuizPage";
import ResultsPage from "@/pages/ResultsPage";
import Profile from "@/pages/Profile";
import Achievements from "@/pages/Achievements";
import Settings from "@/pages/Settings";
import AdminDashboard from "@/pages/AdminDashboard";
import AdminLogin from "@/pages/AdminLogin";
import ManageQuizzes from "@/pages/ManageQuizzes";
import ManageQuestions from "@/pages/ManageQuestions";
import MembershipPlans from "@/pages/MembershipPlans";
import QuizSettings from "@/pages/QuizSettings";
import SplitPaymentSettings from "@/pages/SplitPaymentSettings";
import AdminPayments from "@/pages/AdminPayments";
import AdminAnalytics from "@/pages/AdminAnalytics";
import ProtectedRoute from "@/components/ProtectedRoute";
import MobileBottomNav from "@/components/MobileBottomNav";
import NotFound from "@/pages/not-found";
import { useAuthStore } from "@/stores/authStore";
import { useLocation } from "wouter";

function Router() {
  return (
    <Switch>
      <Route path="/" component={LandingPage} />
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/dashboard">
        <ProtectedRoute>
          <UserDashboard />
        </ProtectedRoute>
      </Route>
      <Route path="/quiz/:id">
        <ProtectedRoute>
          <QuizPage />
        </ProtectedRoute>
      </Route>
      <Route path="/results/:attemptId">
        <ProtectedRoute>
          <ResultsPage />
        </ProtectedRoute>
      </Route>
      <Route path="/profile">
        <ProtectedRoute>
          <Profile />
        </ProtectedRoute>
      </Route>
      <Route path="/achievements">
        <ProtectedRoute>
          <Achievements />
        </ProtectedRoute>
      </Route>
      <Route path="/settings">
        <ProtectedRoute>
          <Settings />
        </ProtectedRoute>
      </Route>
      <Route path="/admin">
        <ProtectedRoute requireAdmin>
          <AdminDashboard />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/quizzes">
        <ProtectedRoute requireAdmin>
          <ManageQuizzes />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/quizzes/:quizId/questions">
        <ProtectedRoute requireAdmin>
          <ManageQuestions />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/membership">
        <ProtectedRoute requireAdmin>
          <MembershipPlans />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/settings">
        <ProtectedRoute requireAdmin>
          <QuizSettings />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/split-payments">
        <ProtectedRoute requireAdmin>
          <SplitPaymentSettings />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/payments">
        <ProtectedRoute requireAdmin>
          <AdminPayments />
        </ProtectedRoute>
      </Route>
      <Route path="/admin/analytics">
        <ProtectedRoute requireAdmin>
          <AdminAnalytics />
        </ProtectedRoute>
      </Route>
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const { user } = useAuthStore();
  const [location] = useLocation();
  
  const showMobileNav = user && !location.startsWith("/admin");

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
        {showMobileNav && <MobileBottomNav />}
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
