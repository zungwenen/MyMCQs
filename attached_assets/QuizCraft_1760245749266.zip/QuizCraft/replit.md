# Easyread IQ - Interactive MCQ Learning Platform

## Overview
Easyread IQ is an interactive Multiple Choice Question (MCQ) web application for educational purposes. It allows users to test their knowledge, receive real-time feedback, and track their progress. The platform supports both free and premium content, featuring separate user and admin interfaces, phone-based authentication via OTP (WhatsApp/SMS), and integrated payment services.

Key capabilities include:
- Browsing quizzes without login.
- Authentication via WhatsApp/SMS OTP.
- User dashboards with quiz history and analytics.
- User profiles with statistics, achievements (badge system), and settings.
- Real-time quiz timers and detailed results with answer review.
- Admin dashboards for user analytics and comprehensive quiz/question management.
- Integration with Paystack for premium content payments.
- Mobile-first responsive design for all interfaces.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
- **Frameworks**: React with TypeScript, Vite for bundling, Wouter for routing.
- **State Management**: TanStack Query for server state, Zustand for client-side (auth, quiz state).
- **UI/UX**: Shadcn UI (Radix UI), Tailwind CSS with custom design tokens, Material Design 3 principles, custom HSL color system for light/dark themes.
- **Responsiveness**: Mobile-first design with a primary breakpoint at 768px.
- **Form Management**: React Hook Form with Zod validation.
- **User Pages**: Profile, Achievements (badge system), Settings with theme toggle and account deletion.
- **Mobile Navigation**: Fixed bottom navigation bar for authenticated users on mobile, providing quick access to Home, Profile, Perks, and Logout.
- **Accessibility**: Web Speech API for Text-to-Speech (TTS) integration on quiz questions and answer options, accessible via `useSpeech` hook.

### Backend
- **Server**: Express.js with TypeScript for a REST API.
- **Authentication**: Session-based with `express-session`, custom middleware for auth guards. Phone-based OTP (Twilio) for users; email/password for admins (bcrypt hashing).
- **Database**: PostgreSQL via Neon Database, managed with Drizzle ORM.
- **Schema Design**: Tables for users, OTP verifications, admins, quizzes, questions (JSONB for options), payments, and quiz attempts.
- **API**: RESTful endpoints, consistent error handling, request/response logging.

### Authentication & Authorization
- **User Flow**: Phone number-based registration, OTP via Twilio (WhatsApp/SMS fallback), 7-day session persistence. Development OTP bypass ("123456").
- **Admin Flow**: Separate admin login, `admin@easyreadiq.com` / `admin123` default credentials, protected routes.
- **Authorization**: Middleware (`requireAuth`, `requireAdmin`) and client-side `ProtectedRoute` component.

### Payment Integration
- **Model**: Free quizzes require login; premium quizzes require a one-time membership payment to unlock all premium content.
- **Provider**: Paystack for Nigerian Naira currency transactions.
- **Membership Flow**: Collects user email, initializes payment via Paystack authorization URL, client-side polling for completion, stores payment records.
- **Split Payment System**: Configurable revenue sharing via `splitPaymentSettings` table, supporting percentage or flat splits with specified fee bearers. Settings applied automatically to payment initializations.

## External Dependencies

### Third-Party Services
- **Twilio**: For SMS and WhatsApp OTP delivery.
- **Paystack**: For payment processing and membership management.
- **Neon Database**: Serverless PostgreSQL hosting.

### Key NPM Packages
- **@radix-ui/***: Headless UI primitives.
- **@tanstack/react-query**: Server state management.
- **drizzle-orm**: Type-safe ORM.
- **bcryptjs**: Password hashing.
- **zod**: Schema validation.
- **zustand**: Lightweight state management.
- **date-fns**: Date manipulation.
- **class-variance-authority**, **tailwind-merge**, **clsx**: UI utility packages.

### Development Tools
- **TypeScript**: For type safety.
- **Vite**: Development server.
- **ESBuild**: Production server bundling.

### Design System
- **Fonts**: Inter (primary), JetBrains Mono (monospace).
- **Styling**: Custom HSL color variables, responsive breakpoints.

## Recent Updates

### Bug Fixes (October 10, 2025)

#### Session Timeout Issue (FIXED)
- **Problem**: Sessions were expiring during normal use, causing "Failed to check quiz access" and "Failed to update profile" errors after idle periods
- **Root Cause**: `resave: false` configuration meant sessions weren't refreshed during read-only operations
- **Solution**: 
  - Added `rolling: true` to express-session configuration (server/index.ts)
  - Sessions now automatically refresh on every request
  - Users stay logged in during active use while respecting 7-day maximum lifetime
  - Enhanced error handling to show user-friendly "Session expired" message with automatic redirect
- **Impact**: Users can now navigate and use the app without unexpected session timeouts

#### Modal Responsiveness (FIXED)
- Fixed AuthModal and MembershipModal being too large on mobile devices
- Added responsive width constraints (`max-w-[95vw]` on mobile)
- Reduced padding and scaled down icons/typography on small screens
- Added scrolling support for tall content

#### Answer Review Display (FIXED)
- Fixed bug where all quiz answers were showing as incorrect
- Created dedicated `/api/quizzes/:id/review` endpoint with correct answers
- Proper green/red styling now displays based on correctness

#### Results Page Not Found (FIXED)
- Fixed "Results not found" error after quiz submission
- Added cache invalidation for `/api/attempts` after submission
- Results page now properly displays quiz results