import twilio from "twilio";

const accountSid = process.env.TWILIO_ACCOUNT_SID;
const authToken = process.env.TWILIO_AUTH_TOKEN;
const twilioPhone = process.env.TWILIO_PHONE_NUMBER;
const twilioWhatsApp = process.env.TWILIO_WHATSAPP_NUMBER;

if (!accountSid || !authToken || !twilioPhone || !twilioWhatsApp) {
  console.warn("Twilio credentials not configured. SMS/WhatsApp will not work.");
}

const client = twilio(accountSid, authToken);

export interface SendOtpResult {
  success: boolean;
  method: "whatsapp" | "sms";
  error?: string;
}

export async function sendOtp(phoneNumber: string, otp: string): Promise<SendOtpResult> {
  const message = `Your Easyread IQ verification code is: ${otp}. Valid for 10 minutes.`;

  // Try WhatsApp first
  try {
    await client.messages.create({
      from: `whatsapp:${twilioWhatsApp}`,
      to: `whatsapp:${phoneNumber}`,
      body: message,
    });
    return { success: true, method: "whatsapp" };
  } catch (whatsappError) {
    console.error("WhatsApp send failed, falling back to SMS:", whatsappError);
    
    // Fallback to SMS
    try {
      await client.messages.create({
        from: twilioPhone,
        to: phoneNumber,
        body: message,
      });
      return { success: true, method: "sms" };
    } catch (smsError) {
      console.error("SMS send also failed:", smsError);
      return {
        success: false,
        method: "sms",
        error: "Failed to send OTP via WhatsApp and SMS",
      };
    }
  }
}

export function generateOtp(): string {
  return Math.floor(100000 + Math.random() * 900000).toString();
}
