const PAYSTACK_SECRET_KEY = process.env.PAYSTACK_SECRET_KEY;

if (!PAYSTACK_SECRET_KEY) {
  console.warn("Paystack secret key not configured. Payments will not work.");
}

export interface SplitPaymentConfig {
  subaccount?: string;
  transaction_charge?: number;
  bearer?: "account" | "subaccount" | "all-proportional" | "all";
}

export interface InitializePaymentParams {
  email: string;
  amount: number; // in kobo (smallest currency unit)
  reference: string;
  metadata?: Record<string, any>;
  split?: SplitPaymentConfig;
}

export interface InitializePaymentResult {
  success: boolean;
  authorization_url?: string;
  access_code?: string;
  reference?: string;
  error?: string;
}

export async function initializePayment(params: InitializePaymentParams): Promise<InitializePaymentResult> {
  try {
    const body: any = {
      email: params.email,
      amount: params.amount,
      reference: params.reference,
      metadata: params.metadata,
    };

    // Add split payment configuration if provided
    if (params.split) {
      if (params.split.subaccount) {
        body.subaccount = params.split.subaccount;
      }
      if (params.split.transaction_charge !== undefined) {
        body.transaction_charge = params.split.transaction_charge;
      }
      if (params.split.bearer) {
        body.bearer = params.split.bearer;
      }
    }

    const response = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(body),
    });

    const data = await response.json();

    if (!response.ok || !data.status) {
      return {
        success: false,
        error: data.message || "Payment initialization failed",
      };
    }

    return {
      success: true,
      authorization_url: data.data.authorization_url,
      access_code: data.data.access_code,
      reference: data.data.reference,
    };
  } catch (error) {
    console.error("Paystack initialization error:", error);
    return {
      success: false,
      error: "Failed to initialize payment",
    };
  }
}

export interface VerifyPaymentResult {
  success: boolean;
  status?: string;
  amount?: number;
  reference?: string;
  error?: string;
}

export async function verifyPayment(reference: string): Promise<VerifyPaymentResult> {
  try {
    const response = await fetch(`https://api.paystack.co/transaction/verify/${reference}`, {
      method: "GET",
      headers: {
        Authorization: `Bearer ${PAYSTACK_SECRET_KEY}`,
      },
    });

    const data = await response.json();

    if (!response.ok || !data.status) {
      return {
        success: false,
        error: data.message || "Payment verification failed",
      };
    }

    return {
      success: true,
      status: data.data.status,
      amount: data.data.amount,
      reference: data.data.reference,
    };
  } catch (error) {
    console.error("Paystack verification error:", error);
    return {
      success: false,
      error: "Failed to verify payment",
    };
  }
}
