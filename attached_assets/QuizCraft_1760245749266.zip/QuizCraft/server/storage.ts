import {
  type User,
  type InsertUser,
  type Admin,
  type InsertAdmin,
  type Quiz,
  type InsertQuiz,
  type Question,
  type InsertQuestion,
  type Payment,
  type InsertPayment,
  type QuizAttempt,
  type InsertQuizAttempt,
  type OtpVerification,
  type InsertOtp,
  type MembershipPlan,
  type InsertMembershipPlan,
  type UserMembership,
  type InsertUserMembership,
  type SplitPaymentSettings,
  type InsertSplitPaymentSettings,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByPhone(phoneNumber: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;

  // OTP operations
  createOtp(otp: InsertOtp): Promise<OtpVerification>;
  getOtpByPhone(phoneNumber: string): Promise<OtpVerification | undefined>;
  verifyOtp(phoneNumber: string, otp: string): Promise<boolean>;
  deleteExpiredOtps(): Promise<void>;

  // Admin operations
  getAdmin(id: string): Promise<Admin | undefined>;
  getAdminByEmail(email: string): Promise<Admin | undefined>;
  createAdmin(admin: InsertAdmin): Promise<Admin>;

  // Quiz operations
  getAllQuizzes(): Promise<Quiz[]>;
  getActiveQuizzes(): Promise<Quiz[]>;
  getQuiz(id: string): Promise<Quiz | undefined>;
  createQuiz(quiz: InsertQuiz): Promise<Quiz>;
  updateQuiz(id: string, quiz: Partial<InsertQuiz>): Promise<Quiz | undefined>;
  deleteQuiz(id: string): Promise<boolean>;

  // Question operations
  getQuestionsByQuizId(quizId: string): Promise<Question[]>;
  getQuestion(id: string): Promise<Question | undefined>;
  createQuestion(question: InsertQuestion): Promise<Question>;
  updateQuestion(id: string, question: Partial<InsertQuestion>): Promise<Question | undefined>;
  deleteQuestion(id: string): Promise<boolean>;

  // Payment operations
  createPayment(payment: InsertPayment): Promise<Payment>;
  getPayment(id: string): Promise<Payment | undefined>;
  getUserPayments(userId: string): Promise<Payment[]>;
  hasUserPaidForQuiz(userId: string, quizId: string): Promise<boolean>;
  updatePaymentStatus(id: string, status: string, reference?: string): Promise<Payment | undefined>;

  // Quiz Attempt operations
  createQuizAttempt(attempt: InsertQuizAttempt): Promise<QuizAttempt>;
  getUserAttempts(userId: string): Promise<QuizAttempt[]>;
  getQuizAttempts(quizId: string): Promise<QuizAttempt[]>;
  getUserQuizAttempts(userId: string, quizId: string): Promise<QuizAttempt[]>;

  // Membership Plan operations
  getAllMembershipPlans(): Promise<MembershipPlan[]>;
  getActiveMembershipPlans(): Promise<MembershipPlan[]>;
  getMembershipPlan(id: string): Promise<MembershipPlan | undefined>;
  createMembershipPlan(plan: InsertMembershipPlan): Promise<MembershipPlan>;
  updateMembershipPlan(id: string, plan: Partial<InsertMembershipPlan>): Promise<MembershipPlan | undefined>;
  deleteMembershipPlan(id: string): Promise<boolean>;

  // User Membership operations
  getUserMembership(userId: string): Promise<UserMembership | undefined>;
  createUserMembership(membership: InsertUserMembership): Promise<UserMembership>;
  hasActiveMembership(userId: string): Promise<boolean>;
  getUserMemberships(userId: string): Promise<UserMembership[]>;

  // Split Payment Settings operations
  getSplitPaymentSettings(): Promise<SplitPaymentSettings | undefined>;
  createSplitPaymentSettings(settings: InsertSplitPaymentSettings): Promise<SplitPaymentSettings>;
  updateSplitPaymentSettings(id: string, settings: Partial<InsertSplitPaymentSettings>): Promise<SplitPaymentSettings | undefined>;
  deleteSplitPaymentSettings(id: string): Promise<boolean>;

  // Analytics
  getTotalUsers(): Promise<number>;
  getTotalRevenue(): Promise<number>;
  getAverageScore(): Promise<number>;
  getRecentAttempts(limit: number): Promise<Array<QuizAttempt & { user: User; quiz: Quiz }>>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private otps: Map<string, OtpVerification>;
  private admins: Map<string, Admin>;
  private quizzes: Map<string, Quiz>;
  private questions: Map<string, Question>;
  private payments: Map<string, Payment>;
  private quizAttempts: Map<string, QuizAttempt>;
  private membershipPlans: Map<string, MembershipPlan>;
  private userMemberships: Map<string, UserMembership>;
  private splitPaymentSettings: Map<string, SplitPaymentSettings>;

  constructor() {
    this.users = new Map();
    this.otps = new Map();
    this.admins = new Map();
    this.quizzes = new Map();
    this.questions = new Map();
    this.payments = new Map();
    this.quizAttempts = new Map();
    this.membershipPlans = new Map();
    this.userMemberships = new Map();
    this.splitPaymentSettings = new Map();
    
    // Create default admin
    const defaultAdmin: Admin = {
      id: randomUUID(),
      email: "admin@easyreadiq.com",
      password: "$2b$10$kkc6A/PuiojaCqteICqxfO4yYwxzL2Yxpehe9IB3C33dU.k14AQu6", // "admin123"
      name: "Admin User",
      createdAt: new Date(),
    };
    this.admins.set(defaultAdmin.id, defaultAdmin);
    
    // Seed default membership plan and quizzes
    this.seedMembershipPlans();
    this.seedQuizzes();
  }

  private seedMembershipPlans() {
    const defaultPlan: MembershipPlan = {
      id: randomUUID(),
      name: "Premium All Access",
      description: "One-time payment for lifetime access to all premium quizzes",
      price: "5000.00",
      duration: 0, // 0 = lifetime
      isActive: true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.membershipPlans.set(defaultPlan.id, defaultPlan);
  }

  private seedQuizzes() {
    const quizData = [
      {
        title: "Business Law",
        description: "Test your knowledge of corporate regulations, contracts, and legal frameworks",
        isPremium: false,
        isFree: true, // Free for testing
        price: "0.00",
        duration: 30,
      },
      {
        title: "Corporate Governance",
        description: "Master the principles of board management, compliance, and ethical leadership",
        isPremium: true,
        isFree: false,
        price: "24.99",
        duration: 45,
      },
      {
        title: "Advanced Taxation",
        description: "Deep dive into tax planning, international taxation, and compliance strategies",
        isPremium: true,
        isFree: false,
        price: "29.99",
        duration: 60,
      },
      {
        title: "Financial Accounting",
        description: "Understand accounting principles, financial statements, and reporting standards",
        isPremium: false,
        isFree: true, // Free for testing
        price: "0.00",
        duration: 25,
      },
    ];

    quizData.forEach((quiz) => {
      const id = randomUUID();
      const newQuiz: Quiz = {
        id,
        ...quiz,
        passingScore: 70,
        randomizeQuestions: false,
        showInstantFeedback: false,
        isActive: true,
        createdAt: new Date(),
        updatedAt: new Date(),
      };
      this.quizzes.set(id, newQuiz);

      // Add sample questions
      this.seedQuestionsForQuiz(id);
    });
  }

  private seedQuestionsForQuiz(quizId: string) {
    const sampleQuestions: Array<{
      questionText: string;
      options: Array<{ id: string; text: string }>;
      correctAnswer: string;
    }> = [
      {
        questionText: "Which of the following best describes the role of a board of directors?",
        options: [
          { id: "a", text: "The board has ultimate authority over company decisions" },
          { id: "b", text: "Shareholders elect the board members to represent their interests" },
          { id: "c", text: "The CEO reports directly to shareholders" },
          { id: "d", text: "Independent directors must own company shares" },
        ],
        correctAnswer: "b",
      },
      {
        questionText: "What is the primary purpose of internal controls in a business?",
        options: [
          { id: "a", text: "To increase company profits" },
          { id: "b", text: "To safeguard assets and ensure accuracy of financial records" },
          { id: "c", text: "To reduce employee headcount" },
          { id: "d", text: "To eliminate all business risks" },
        ],
        correctAnswer: "b",
      },
    ];

    sampleQuestions.forEach((q, index) => {
      const id = randomUUID();
      const question: Question = {
        id,
        quizId,
        questionText: q.questionText,
        options: q.options,
        correctAnswer: q.correctAnswer,
        explanation: null,
        order: index,
        createdAt: new Date(),
      };
      this.questions.set(id, question);
    });
  }

  // User operations
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByPhone(phoneNumber: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find((u) => u.phoneNumber === phoneNumber);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = {
      id,
      phoneNumber: insertUser.phoneNumber,
      name: insertUser.name ?? null,
      createdAt: new Date(),
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, userData: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    const updated = { ...user, ...userData };
    this.users.set(id, updated);
    return updated;
  }

  async deleteUser(id: string): Promise<boolean> {
    return this.users.delete(id);
  }

  // OTP operations
  async createOtp(insertOtp: InsertOtp): Promise<OtpVerification> {
    const id = randomUUID();
    const otp: OtpVerification = { ...insertOtp, id, verified: false, createdAt: new Date() };
    this.otps.set(id, otp);
    return otp;
  }

  async getOtpByPhone(phoneNumber: string): Promise<OtpVerification | undefined> {
    return Array.from(this.otps.values())
      .filter((o) => o.phoneNumber === phoneNumber && !o.verified)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())[0];
  }

  async verifyOtp(phoneNumber: string, otpCode: string): Promise<boolean> {
    const otp = await this.getOtpByPhone(phoneNumber);
    if (!otp || otp.otp !== otpCode || new Date() > otp.expiresAt) {
      return false;
    }
    otp.verified = true;
    this.otps.set(otp.id, otp);
    return true;
  }

  async deleteExpiredOtps(): Promise<void> {
    const now = new Date();
    Array.from(this.otps.entries()).forEach(([id, otp]) => {
      if (otp.expiresAt < now) {
        this.otps.delete(id);
      }
    });
  }

  // Admin operations
  async getAdmin(id: string): Promise<Admin | undefined> {
    return this.admins.get(id);
  }

  async getAdminByEmail(email: string): Promise<Admin | undefined> {
    return Array.from(this.admins.values()).find((a) => a.email === email);
  }

  async createAdmin(insertAdmin: InsertAdmin): Promise<Admin> {
    const id = randomUUID();
    const admin: Admin = { ...insertAdmin, id, createdAt: new Date() };
    this.admins.set(id, admin);
    return admin;
  }

  // Quiz operations
  async getAllQuizzes(): Promise<Quiz[]> {
    return Array.from(this.quizzes.values());
  }

  async getActiveQuizzes(): Promise<Quiz[]> {
    return Array.from(this.quizzes.values()).filter((q) => q.isActive);
  }

  async getQuiz(id: string): Promise<Quiz | undefined> {
    return this.quizzes.get(id);
  }

  async createQuiz(insertQuiz: InsertQuiz): Promise<Quiz> {
    const id = randomUUID();
    const quiz: Quiz = {
      id,
      title: insertQuiz.title,
      description: insertQuiz.description,
      isPremium: insertQuiz.isPremium ?? false,
      isFree: insertQuiz.isFree ?? false,
      price: insertQuiz.price ?? "0.00",
      duration: insertQuiz.duration,
      passingScore: insertQuiz.passingScore ?? 70,
      randomizeQuestions: insertQuiz.randomizeQuestions ?? false,
      showInstantFeedback: insertQuiz.showInstantFeedback ?? false,
      isActive: insertQuiz.isActive ?? true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.quizzes.set(id, quiz);
    return quiz;
  }

  async updateQuiz(id: string, quizData: Partial<InsertQuiz>): Promise<Quiz | undefined> {
    const quiz = this.quizzes.get(id);
    if (!quiz) return undefined;
    const updated = { ...quiz, ...quizData, updatedAt: new Date() };
    this.quizzes.set(id, updated);
    return updated;
  }

  async deleteQuiz(id: string): Promise<boolean> {
    return this.quizzes.delete(id);
  }

  // Question operations
  async getQuestionsByQuizId(quizId: string): Promise<Question[]> {
    return Array.from(this.questions.values())
      .filter((q) => q.quizId === quizId)
      .sort((a, b) => a.order - b.order);
  }

  async getQuestion(id: string): Promise<Question | undefined> {
    return this.questions.get(id);
  }

  async createQuestion(insertQuestion: InsertQuestion): Promise<Question> {
    const id = randomUUID();
    const question: Question = {
      id,
      quizId: insertQuestion.quizId,
      questionText: insertQuestion.questionText,
      options: insertQuestion.options as Array<{ id: string; text: string }>,
      correctAnswer: insertQuestion.correctAnswer,
      explanation: insertQuestion.explanation ?? null,
      order: insertQuestion.order ?? 0,
      createdAt: new Date(),
    };
    this.questions.set(id, question);
    return question;
  }

  async updateQuestion(id: string, questionData: Partial<InsertQuestion>): Promise<Question | undefined> {
    const question = this.questions.get(id);
    if (!question) return undefined;
    const updated: Question = {
      ...question,
      ...questionData,
      options: (questionData.options ?? question.options) as Array<{ id: string; text: string }>,
    };
    this.questions.set(id, updated);
    return updated;
  }

  async deleteQuestion(id: string): Promise<boolean> {
    return this.questions.delete(id);
  }

  // Payment operations
  async createPayment(insertPayment: InsertPayment): Promise<Payment> {
    const id = randomUUID();
    const payment: Payment = {
      id,
      userId: insertPayment.userId,
      quizId: insertPayment.quizId ?? null,
      membershipPlanId: insertPayment.membershipPlanId ?? null,
      amount: insertPayment.amount,
      status: insertPayment.status,
      paymentReference: insertPayment.paymentReference ?? null,
      paymentMethod: insertPayment.paymentMethod ?? "paystack",
      createdAt: new Date(),
    };
    this.payments.set(id, payment);
    return payment;
  }

  async getPayment(id: string): Promise<Payment | undefined> {
    return this.payments.get(id);
  }

  async getUserPayments(userId: string): Promise<Payment[]> {
    return Array.from(this.payments.values()).filter((p) => p.userId === userId);
  }

  async hasUserPaidForQuiz(userId: string, quizId: string): Promise<boolean> {
    return Array.from(this.payments.values()).some(
      (p) => p.userId === userId && p.quizId === quizId && p.status === "completed"
    );
  }

  async updatePaymentStatus(id: string, status: string, reference?: string): Promise<Payment | undefined> {
    const payment = this.payments.get(id);
    if (!payment) return undefined;
    const updated = { ...payment, status, ...(reference && { paymentReference: reference }) };
    this.payments.set(id, updated);
    return updated;
  }

  // Quiz Attempt operations
  async createQuizAttempt(insertAttempt: InsertQuizAttempt): Promise<QuizAttempt> {
    const id = randomUUID();
    const attempt: QuizAttempt = {
      id,
      userId: insertAttempt.userId,
      quizId: insertAttempt.quizId,
      answers: insertAttempt.answers,
      markedForReview: (insertAttempt.markedForReview as string[] | undefined) ?? null,
      score: insertAttempt.score,
      totalQuestions: insertAttempt.totalQuestions,
      correctAnswers: insertAttempt.correctAnswers,
      incorrectAnswers: insertAttempt.incorrectAnswers,
      unattempted: insertAttempt.unattempted,
      timeSpent: insertAttempt.timeSpent,
      passed: insertAttempt.passed,
      completedAt: new Date(),
    };
    this.quizAttempts.set(id, attempt);
    return attempt;
  }

  async getUserAttempts(userId: string): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values())
      .filter((a) => a.userId === userId)
      .sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime());
  }

  async getQuizAttempts(quizId: string): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values())
      .filter((a) => a.quizId === quizId)
      .sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime());
  }

  async getUserQuizAttempts(userId: string, quizId: string): Promise<QuizAttempt[]> {
    return Array.from(this.quizAttempts.values())
      .filter((a) => a.userId === userId && a.quizId === quizId)
      .sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime());
  }

  // Analytics
  async getTotalUsers(): Promise<number> {
    return this.users.size;
  }

  async getTotalRevenue(): Promise<number> {
    return Array.from(this.payments.values())
      .filter((p) => p.status === "completed")
      .reduce((sum, p) => sum + parseFloat(p.amount), 0);
  }

  async getAverageScore(): Promise<number> {
    const attempts = Array.from(this.quizAttempts.values());
    if (attempts.length === 0) return 0;
    const totalScore = attempts.reduce((sum, a) => sum + a.score, 0);
    return Math.round((totalScore / attempts.length) * 100) / 100;
  }

  async getRecentAttempts(limit: number): Promise<Array<QuizAttempt & { user: User; quiz: Quiz }>> {
    const attempts = Array.from(this.quizAttempts.values())
      .sort((a, b) => b.completedAt.getTime() - a.completedAt.getTime())
      .slice(0, limit);

    return attempts.map((attempt) => ({
      ...attempt,
      user: this.users.get(attempt.userId)!,
      quiz: this.quizzes.get(attempt.quizId)!,
    }));
  }

  // Membership Plan operations
  async getAllMembershipPlans(): Promise<MembershipPlan[]> {
    return Array.from(this.membershipPlans.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getActiveMembershipPlans(): Promise<MembershipPlan[]> {
    return Array.from(this.membershipPlans.values())
      .filter((p) => p.isActive)
      .sort((a, b) => parseFloat(a.price) - parseFloat(b.price));
  }

  async getMembershipPlan(id: string): Promise<MembershipPlan | undefined> {
    return this.membershipPlans.get(id);
  }

  async createMembershipPlan(insertPlan: InsertMembershipPlan): Promise<MembershipPlan> {
    const id = randomUUID();
    const plan: MembershipPlan = {
      id,
      name: insertPlan.name,
      description: insertPlan.description,
      price: insertPlan.price,
      duration: insertPlan.duration,
      isActive: insertPlan.isActive ?? true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.membershipPlans.set(id, plan);
    return plan;
  }

  async updateMembershipPlan(id: string, updateData: Partial<InsertMembershipPlan>): Promise<MembershipPlan | undefined> {
    const plan = this.membershipPlans.get(id);
    if (!plan) return undefined;
    const updated: MembershipPlan = {
      ...plan,
      ...updateData,
      updatedAt: new Date(),
    };
    this.membershipPlans.set(id, updated);
    return updated;
  }

  async deleteMembershipPlan(id: string): Promise<boolean> {
    return this.membershipPlans.delete(id);
  }

  // User Membership operations
  async getUserMembership(userId: string): Promise<UserMembership | undefined> {
    const memberships = Array.from(this.userMemberships.values())
      .filter((m) => m.userId === userId && m.status === 'active')
      .sort((a, b) => b.purchaseDate.getTime() - a.purchaseDate.getTime());
    
    if (memberships.length === 0) return undefined;
    
    const membership = memberships[0];
    
    // Check if membership has expired
    if (membership.expiryDate && membership.expiryDate < new Date()) {
      const expired: UserMembership = { ...membership, status: 'expired' };
      this.userMemberships.set(membership.id, expired);
      return undefined;
    }
    
    return membership;
  }

  async createUserMembership(insertMembership: InsertUserMembership): Promise<UserMembership> {
    const id = randomUUID();
    const membership: UserMembership = {
      id,
      userId: insertMembership.userId,
      planId: insertMembership.planId,
      purchaseDate: insertMembership.purchaseDate ?? new Date(),
      expiryDate: insertMembership.expiryDate ?? null,
      status: insertMembership.status,
      paymentId: insertMembership.paymentId ?? null,
      createdAt: new Date(),
    };
    this.userMemberships.set(id, membership);
    return membership;
  }

  async hasActiveMembership(userId: string): Promise<boolean> {
    const membership = await this.getUserMembership(userId);
    return membership !== undefined;
  }

  async getUserMemberships(userId: string): Promise<UserMembership[]> {
    return Array.from(this.userMemberships.values())
      .filter((m) => m.userId === userId)
      .sort((a, b) => b.purchaseDate.getTime() - a.purchaseDate.getTime());
  }

  // Split Payment Settings operations
  async getSplitPaymentSettings(): Promise<SplitPaymentSettings | undefined> {
    const activeSettings = Array.from(this.splitPaymentSettings.values())
      .filter((s) => s.isActive)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
    
    return activeSettings[0];
  }

  async createSplitPaymentSettings(insertSettings: InsertSplitPaymentSettings): Promise<SplitPaymentSettings> {
    const id = randomUUID();
    const settings: SplitPaymentSettings = {
      id,
      subaccountCode: insertSettings.subaccountCode,
      splitType: insertSettings.splitType,
      splitValue: insertSettings.splitValue,
      bearer: insertSettings.bearer ?? "account",
      isActive: insertSettings.isActive ?? true,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    this.splitPaymentSettings.set(id, settings);
    return settings;
  }

  async updateSplitPaymentSettings(id: string, updateSettings: Partial<InsertSplitPaymentSettings>): Promise<SplitPaymentSettings | undefined> {
    const settings = this.splitPaymentSettings.get(id);
    if (!settings) return undefined;

    const updated: SplitPaymentSettings = {
      ...settings,
      ...updateSettings,
      updatedAt: new Date(),
    };
    this.splitPaymentSettings.set(id, updated);
    return updated;
  }

  async deleteSplitPaymentSettings(id: string): Promise<boolean> {
    return this.splitPaymentSettings.delete(id);
  }
}

export const storage = new MemStorage();
