import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { sendOtp, generateOtp } from "./lib/twilio";
import { initializePayment, verifyPayment } from "./lib/paystack";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { insertQuizSchema, insertQuestionSchema, sessionSchema } from "@shared/schema";

// Extend Express Request to include session
declare module "express-session" {
  interface SessionData {
    userId?: string;
    adminId?: string;
    phoneNumber?: string;
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Middleware to check if user is authenticated
  const requireAuth = (req: Request, res: Response, next: Function) => {
    if (!req.session.userId) {
      return res.status(401).json({ error: "Unauthorized" });
    }
    next();
  };

  // Middleware to check if admin is authenticated
  const requireAdmin = (req: Request, res: Response, next: Function) => {
    console.log("[requireAdmin] Session ID:", req.sessionID);
    console.log("[requireAdmin] Admin ID:", req.session.adminId);
    console.log("[requireAdmin] Session:", JSON.stringify(req.session));
    
    if (!req.session.adminId) {
      console.log("[requireAdmin] No adminId in session - returning 401");
      return res.status(401).json({ error: "Unauthorized - Admin access required" });
    }
    next();
  };

  // === AUTH ROUTES ===

  // Send OTP via WhatsApp/SMS
  app.post("/api/auth/send-otp", async (req: Request, res: Response) => {
    try {
      const { phoneNumber } = req.body;
      
      if (!phoneNumber) {
        return res.status(400).json({ error: "Phone number is required" });
      }

      const otp = generateOtp();
      const expiresAt = new Date(Date.now() + 10 * 60 * 1000); // 10 minutes

      // Delete any existing OTPs for this number
      await storage.deleteExpiredOtps();

      // Development mode: Skip actual SMS/WhatsApp sending
      const isDevelopment = process.env.NODE_ENV === "development";
      let result;
      
      if (isDevelopment) {
        console.log(`[DEV MODE] OTP for ${phoneNumber}: ${otp} (use 123456 to bypass)`);
        result = { success: true, method: "whatsapp" as const };
      } else {
        // Send OTP via Twilio
        result = await sendOtp(phoneNumber, otp);
        
        if (!result.success) {
          return res.status(500).json({ error: result.error });
        }
      }

      // Store OTP
      await storage.createOtp({
        phoneNumber,
        otp,
        expiresAt,
        method: result.method,
      });

      res.json({ success: true, method: result.method });
    } catch (error) {
      console.error("Send OTP error:", error);
      res.status(500).json({ error: "Failed to send OTP" });
    }
  });

  // Verify OTP and create/login user
  app.post("/api/auth/verify-otp", async (req: Request, res: Response) => {
    try {
      const { phoneNumber, otp } = req.body;

      if (!phoneNumber || !otp) {
        return res.status(400).json({ error: "Phone number and OTP are required" });
      }

      // Development bypass: accept "123456" as valid OTP in development
      const isDevelopment = process.env.NODE_ENV === "development";
      const isDevOtp = isDevelopment && otp === "123456";
      
      const isValid = isDevOtp || await storage.verifyOtp(phoneNumber, otp);
      
      if (!isValid) {
        return res.status(400).json({ error: "Invalid or expired OTP" });
      }

      // Get or create user
      let user = await storage.getUserByPhone(phoneNumber);
      
      if (!user) {
        user = await storage.createUser({ phoneNumber });
      }

      // Set session
      req.session.userId = user.id;
      req.session.phoneNumber = user.phoneNumber;

      res.json({ success: true, user });
    } catch (error) {
      console.error("Verify OTP error:", error);
      res.status(500).json({ error: "Failed to verify OTP" });
    }
  });

  // Get current user
  app.get("/api/auth/me", requireAuth, async (req: Request, res: Response) => {
    try {
      const user = await storage.getUser(req.session.userId!);
      res.json({ user });
    } catch (error) {
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  // Update user profile
  app.patch("/api/auth/me", requireAuth, async (req: Request, res: Response) => {
    try {
      const { name } = req.body;
      const user = await storage.updateUser(req.session.userId!, { name });
      res.json({ user });
    } catch (error) {
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  // Logout
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to logout" });
      }
      res.json({ success: true });
    });
  });

  // Delete user account
  app.delete("/api/auth/me", requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId!;
      await storage.deleteUser(userId);
      
      req.session.destroy((err) => {
        if (err) {
          console.error("Session destroy error:", err);
        }
        res.json({ success: true });
      });
    } catch (error) {
      console.error("Delete user error:", error);
      res.status(500).json({ error: "Failed to delete account" });
    }
  });

  // Get user statistics
  app.get("/api/user/stats", requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId!;
      const attempts = await storage.getUserAttempts(userId);
      
      if (attempts.length === 0) {
        return res.json({
          totalAttempts: 0,
          averageScore: 0,
          bestScore: 0,
          totalTimeSpent: 0,
          uniqueQuizzes: 0,
        });
      }

      const totalAttempts = attempts.length;
      const averageScore = attempts.reduce((sum, a) => sum + a.score, 0) / totalAttempts;
      const bestScore = Math.max(...attempts.map(a => a.score));
      const totalTimeSpent = attempts.reduce((sum, a) => sum + a.timeSpent, 0);
      const uniqueQuizzes = new Set(attempts.map(a => a.quizId)).size;

      res.json({
        totalAttempts,
        averageScore: Math.round(averageScore),
        bestScore,
        totalTimeSpent,
        uniqueQuizzes,
      });
    } catch (error) {
      console.error("Get user stats error:", error);
      res.status(500).json({ error: "Failed to get user statistics" });
    }
  });

  // Get user achievements
  app.get("/api/user/achievements", requireAuth, async (req: Request, res: Response) => {
    try {
      const userId = req.session.userId!;
      const attempts = await storage.getUserAttempts(userId);
      
      const achievements = [];

      // First Steps - Complete first quiz
      if (attempts.length >= 1) {
        achievements.push({
          id: "first-steps",
          name: "First Steps",
          description: "Complete your first quiz",
          icon: "BookOpen",
          unlocked: true,
          progress: 1,
          total: 1,
        });
      } else {
        achievements.push({
          id: "first-steps",
          name: "First Steps",
          description: "Complete your first quiz",
          icon: "BookOpen",
          unlocked: false,
          progress: 0,
          total: 1,
        });
      }

      // Perfect Score - Get 100% on any quiz
      const hasPerfectScore = attempts.some(a => a.score === 100);
      achievements.push({
        id: "perfect-score",
        name: "Perfect Score",
        description: "Get 100% on any quiz",
        icon: "Star",
        unlocked: hasPerfectScore,
        progress: hasPerfectScore ? 1 : 0,
        total: 1,
      });

      // Quiz Master - Complete 10 quizzes
      achievements.push({
        id: "quiz-master",
        name: "Quiz Master",
        description: "Complete 10 quizzes",
        icon: "Award",
        unlocked: attempts.length >= 10,
        progress: Math.min(attempts.length, 10),
        total: 10,
      });

      // Speed Demon - Complete quiz in under 50% of time
      let hasSpeedDemon = false;
      for (const attempt of attempts) {
        const quiz = await storage.getQuiz(attempt.quizId);
        if (quiz) {
          const halfTime = (quiz.duration * 60) / 2;
          if (attempt.timeSpent < halfTime) {
            hasSpeedDemon = true;
            break;
          }
        }
      }
      achievements.push({
        id: "speed-demon",
        name: "Speed Demon",
        description: "Complete a quiz in under 50% of allocated time",
        icon: "Zap",
        unlocked: hasSpeedDemon,
        progress: hasSpeedDemon ? 1 : 0,
        total: 1,
      });

      // Consistent Learner - Attempt quizzes on 5 different days
      const uniqueDays = new Set(
        attempts.map(a => a.completedAt.toISOString().split('T')[0])
      );
      achievements.push({
        id: "consistent-learner",
        name: "Consistent Learner",
        description: "Take quizzes on 5 different days",
        icon: "Calendar",
        unlocked: uniqueDays.size >= 5,
        progress: Math.min(uniqueDays.size, 5),
        total: 5,
      });

      // High Achiever - Average score above 80%
      const averageScore = attempts.length > 0 
        ? attempts.reduce((sum, a) => sum + a.score, 0) / attempts.length
        : 0;
      achievements.push({
        id: "high-achiever",
        name: "High Achiever",
        description: "Maintain an average score above 80%",
        icon: "TrendingUp",
        unlocked: averageScore >= 80 && attempts.length >= 3,
        progress: Math.round(averageScore),
        total: 80,
      });

      res.json({ achievements });
    } catch (error) {
      console.error("Get achievements error:", error);
      res.status(500).json({ error: "Failed to get achievements" });
    }
  });

  // === ADMIN AUTH ROUTES ===

  // Admin login
  app.post("/api/admin/login", async (req: Request, res: Response) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return res.status(400).json({ error: "Email and password are required" });
      }

      const admin = await storage.getAdminByEmail(email);
      
      if (!admin) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      const isValid = await bcrypt.compare(password, admin.password);
      
      if (!isValid) {
        return res.status(401).json({ error: "Invalid credentials" });
      }

      req.session.adminId = admin.id;
      console.log("[Admin Login] Setting adminId:", admin.id);
      console.log("[Admin Login] Session ID:", req.sessionID);
      
      // Explicitly save session to ensure adminId persists
      req.session.save((err) => {
        if (err) {
          console.error("[Admin Login] Session save error:", err);
          return res.status(500).json({ error: "Failed to save session" });
        }
        console.log("[Admin Login] Session saved successfully");
        console.log("[Admin Login] Session after save:", JSON.stringify(req.session));
        res.json({ success: true, admin: { id: admin.id, email: admin.email, name: admin.name } });
      });
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ error: "Failed to login" });
    }
  });

  // Admin logout
  app.post("/api/admin/logout", (req: Request, res: Response) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Failed to logout" });
      }
      res.json({ success: true });
    });
  });

  // Get current admin
  app.get("/api/admin/me", requireAdmin, async (req: Request, res: Response) => {
    try {
      const admin = await storage.getAdmin(req.session.adminId!);
      if (admin) {
        const { password, ...adminData } = admin;
        res.json({ admin: adminData });
      } else {
        res.status(404).json({ error: "Admin not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to get admin" });
    }
  });

  // === QUIZ ROUTES ===

  // Get all active quizzes
  app.get("/api/quizzes", async (req: Request, res: Response) => {
    try {
      const quizzes = await storage.getActiveQuizzes();
      
      // Get question counts for each quiz
      const quizzesWithCounts = await Promise.all(
        quizzes.map(async (quiz) => {
          const questions = await storage.getQuestionsByQuizId(quiz.id);
          return { ...quiz, questionsCount: questions.length };
        })
      );

      res.json({ quizzes: quizzesWithCounts });
    } catch (error) {
      res.status(500).json({ error: "Failed to get quizzes" });
    }
  });

  // Get single quiz
  app.get("/api/quizzes/:id", async (req: Request, res: Response) => {
    try {
      const quiz = await storage.getQuiz(req.params.id);
      
      if (!quiz) {
        return res.status(404).json({ error: "Quiz not found" });
      }

      const questions = await storage.getQuestionsByQuizId(quiz.id);
      res.json({ quiz, questions });
    } catch (error) {
      res.status(500).json({ error: "Failed to get quiz" });
    }
  });

  // Check if user has paid for quiz
  app.get("/api/quizzes/:id/access", requireAuth, async (req: Request, res: Response) => {
    try {
      const quiz = await storage.getQuiz(req.params.id);
      
      if (!quiz) {
        return res.status(404).json({ error: "Quiz not found" });
      }

      // Allow access if quiz is free
      if (quiz.isFree || !quiz.isPremium) {
        return res.json({ hasAccess: true });
      }

      // For premium quizzes, check membership only
      const hasActiveMembership = await storage.hasActiveMembership(req.session.userId!);
      
      res.json({ hasAccess: hasActiveMembership });
    } catch (error) {
      res.status(500).json({ error: "Failed to check access" });
    }
  });

  // Get quiz questions (only if user has access)
  app.get("/api/quizzes/:id/questions", requireAuth, async (req: Request, res: Response) => {
    try {
      const quiz = await storage.getQuiz(req.params.id);
      
      if (!quiz) {
        return res.status(404).json({ error: "Quiz not found" });
      }

      // Check access for premium quizzes
      if (quiz.isPremium && !quiz.isFree) {
        // Allow access if user has active membership
        const hasActiveMembership = await storage.hasActiveMembership(req.session.userId!);
        
        if (!hasActiveMembership) {
          return res.status(403).json({ error: "Access denied - active membership required" });
        }
      }

      let questions = await storage.getQuestionsByQuizId(quiz.id);
      
      // Randomize if enabled
      if (quiz.randomizeQuestions) {
        questions = questions.sort(() => Math.random() - 0.5);
      }

      // Remove correct answers from response
      const questionsWithoutAnswers = questions.map(({ correctAnswer, explanation, ...q }) => q);

      res.json({ questions: questionsWithoutAnswers, quiz });
    } catch (error) {
      res.status(500).json({ error: "Failed to get questions" });
    }
  });

  // Submit quiz attempt
  app.post("/api/quizzes/:id/submit", requireAuth, async (req: Request, res: Response) => {
    try {
      const quiz = await storage.getQuiz(req.params.id);
      
      if (!quiz) {
        return res.status(404).json({ error: "Quiz not found" });
      }

      const { answers, markedForReview, timeSpent } = req.body;
      const questions = await storage.getQuestionsByQuizId(quiz.id);

      // Calculate score
      let correctAnswers = 0;
      let incorrectAnswers = 0;
      let unattempted = 0;

      const results = questions.map((question) => {
        const userAnswer = answers[question.id];
        const isCorrect = userAnswer === question.correctAnswer;
        
        if (!userAnswer) {
          unattempted++;
        } else if (isCorrect) {
          correctAnswers++;
        } else {
          incorrectAnswers++;
        }

        return {
          questionId: question.id,
          userAnswer,
          correctAnswer: question.correctAnswer,
          isCorrect,
          explanation: question.explanation,
        };
      });

      const score = correctAnswers;
      const totalQuestions = questions.length;
      const percentage = (score / totalQuestions) * 100;
      const passed = percentage >= quiz.passingScore;

      // Save attempt
      const attempt = await storage.createQuizAttempt({
        userId: req.session.userId!,
        quizId: quiz.id,
        answers,
        markedForReview,
        score,
        totalQuestions,
        correctAnswers,
        incorrectAnswers,
        unattempted,
        timeSpent,
        passed,
      });

      res.json({
        attempt,
        results: quiz.showInstantFeedback ? results : undefined,
      });
    } catch (error) {
      console.error("Submit quiz error:", error);
      res.status(500).json({ error: "Failed to submit quiz" });
    }
  });

  // Get user's quiz attempts
  app.get("/api/attempts", requireAuth, async (req: Request, res: Response) => {
    try {
      const attempts = await storage.getUserAttempts(req.session.userId!);
      res.json({ attempts });
    } catch (error) {
      res.status(500).json({ error: "Failed to get attempts" });
    }
  });

  // Get questions with answers for review (after quiz completion)
  app.get("/api/quizzes/:id/review", requireAuth, async (req: Request, res: Response) => {
    try {
      const quiz = await storage.getQuiz(req.params.id);
      
      if (!quiz) {
        return res.status(404).json({ error: "Quiz not found" });
      }

      // Verify user has completed this quiz
      const attempts = await storage.getUserAttempts(req.session.userId!);
      const hasAttempted = attempts.some(attempt => attempt.quizId === quiz.id);
      
      if (!hasAttempted) {
        return res.status(403).json({ error: "You must complete the quiz before reviewing answers" });
      }

      // Return questions with correct answers for review
      const questions = await storage.getQuestionsByQuizId(quiz.id);
      res.json({ questions, quiz });
    } catch (error) {
      res.status(500).json({ error: "Failed to get review questions" });
    }
  });

  // === PAYMENT ROUTES ===

  // Initialize payment
  app.post("/api/payments/initialize", requireAuth, async (req: Request, res: Response) => {
    try {
      const { quizId, email } = req.body;
      
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      
      const quiz = await storage.getQuiz(quizId);
      
      if (!quiz) {
        return res.status(404).json({ error: "Quiz not found" });
      }

      if (!quiz.isPremium) {
        return res.status(400).json({ error: "This quiz is free" });
      }

      const user = await storage.getUser(req.session.userId!);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Create payment record
      const payment = await storage.createPayment({
        userId: user.id,
        quizId: quiz.id,
        amount: quiz.price,
        status: "pending",
      });

      // Get split payment settings if configured
      const splitSettings = await storage.getSplitPaymentSettings();
      let splitConfig = undefined;
      
      if (splitSettings?.isActive && splitSettings.subaccountCode) {
        splitConfig = {
          subaccount: splitSettings.subaccountCode,
          bearer: splitSettings.feeBearer as "account" | "subaccount" | "all-proportional" | "all",
        };
        
        // Only add transaction_charge for flat fee split (percentage is handled by subaccount config)
        if (splitSettings.splitType === "flat") {
          splitConfig.transaction_charge = Math.round(parseFloat(splitSettings.splitValue) * 100); // Convert to kobo
        }
      }

      // Initialize Paystack payment
      const result = await initializePayment({
        email, // Use the email provided by the user
        amount: Math.round(parseFloat(quiz.price) * 100), // Convert to kobo
        reference: payment.id,
        metadata: {
          userId: user.id,
          quizId: quiz.id,
          quizTitle: quiz.title,
        },
        split: splitConfig,
      });

      if (!result.success) {
        return res.status(500).json({ error: result.error });
      }

      res.json({
        paymentId: payment.id,
        authorizationUrl: result.authorization_url,
        reference: result.reference,
      });
    } catch (error) {
      console.error("Initialize payment error:", error);
      res.status(500).json({ error: "Failed to initialize payment" });
    }
  });

  // Verify payment
  app.post("/api/payments/verify", requireAuth, async (req: Request, res: Response) => {
    try {
      const { reference } = req.body;
      
      const payment = await storage.getPayment(reference);
      
      if (!payment) {
        return res.status(404).json({ error: "Payment not found" });
      }

      if (payment.userId !== req.session.userId) {
        return res.status(403).json({ error: "Unauthorized" });
      }

      const result = await verifyPayment(reference);
      
      if (!result.success) {
        return res.status(500).json({ error: result.error });
      }

      // Update payment status
      const status = result.status === "success" ? "completed" : "failed";
      await storage.updatePaymentStatus(payment.id, status, reference);

      // If this is a membership payment and it's successful, create the user membership
      if (status === "completed" && payment.membershipPlanId) {
        const plan = await storage.getMembershipPlan(payment.membershipPlanId);
        
        if (plan) {
          const expiryDate = plan.duration === 0 
            ? null 
            : new Date(Date.now() + plan.duration * 24 * 60 * 60 * 1000);
          
          await storage.createUserMembership({
            userId: payment.userId,
            planId: plan.id,
            purchaseDate: new Date(),
            expiryDate,
            status: "active",
            paymentId: payment.id,
          });
        }
      }

      res.json({ success: status === "completed", payment });
    } catch (error) {
      console.error("Verify payment error:", error);
      res.status(500).json({ error: "Failed to verify payment" });
    }
  });

  // Get user payments
  app.get("/api/payments", requireAuth, async (req: Request, res: Response) => {
    try {
      const payments = await storage.getUserPayments(req.session.userId!);
      res.json({ payments });
    } catch (error) {
      res.status(500).json({ error: "Failed to get payments" });
    }
  });

  // Initialize membership payment
  app.post("/api/payments/initialize-membership", requireAuth, async (req: Request, res: Response) => {
    try {
      const { planId, email } = req.body;
      
      if (!email) {
        return res.status(400).json({ error: "Email is required" });
      }
      
      const plan = await storage.getMembershipPlan(planId);
      
      if (!plan || !plan.isActive) {
        return res.status(404).json({ error: "Membership plan not found or inactive" });
      }

      const user = await storage.getUser(req.session.userId!);
      
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }

      // Create payment record for membership
      const payment = await storage.createPayment({
        userId: user.id,
        membershipPlanId: plan.id,
        amount: plan.price,
        status: "pending",
      });

      // Get split payment settings if configured
      const splitSettings = await storage.getSplitPaymentSettings();
      let splitConfig = undefined;
      
      if (splitSettings?.isActive && splitSettings.subaccountCode) {
        splitConfig = {
          subaccount: splitSettings.subaccountCode,
          bearer: splitSettings.feeBearer as "account" | "subaccount" | "all-proportional" | "all",
        };
        
        // Only add transaction_charge for flat fee split (percentage is handled by subaccount config)
        if (splitSettings.splitType === "flat") {
          splitConfig.transaction_charge = Math.round(parseFloat(splitSettings.splitValue) * 100); // Convert to kobo
        }
      }

      // Initialize Paystack payment
      const result = await initializePayment({
        email, // Use the email provided by the user
        amount: Math.round(parseFloat(plan.price) * 100), // Convert to kobo
        reference: payment.id,
        metadata: {
          userId: user.id,
          membershipPlanId: plan.id,
          planName: plan.name,
          duration: plan.duration,
        },
        split: splitConfig,
      });

      if (!result.success) {
        return res.status(500).json({ error: result.error });
      }

      res.json({
        paymentId: payment.id,
        authorizationUrl: result.authorization_url,
        reference: result.reference,
      });
    } catch (error) {
      console.error("Initialize membership payment error:", error);
      res.status(500).json({ error: "Failed to initialize membership payment" });
    }
  });

  // === MEMBERSHIP ROUTES ===

  // Get active membership plans (public)
  app.get("/api/membership/plans/active", async (req: Request, res: Response) => {
    try {
      const plans = await storage.getActiveMembershipPlans();
      res.json({ plans });
    } catch (error) {
      res.status(500).json({ error: "Failed to get membership plans" });
    }
  });

  // Get user's active membership
  app.get("/api/membership/user", requireAuth, async (req: Request, res: Response) => {
    try {
      const membership = await storage.getUserMembership(req.session.userId!);
      const hasAccess = await storage.hasActiveMembership(req.session.userId!);
      res.json({ membership, hasAccess });
    } catch (error) {
      res.status(500).json({ error: "Failed to get user membership" });
    }
  });

  // Get all membership plans (admin)
  app.get("/api/admin/membership/plans", requireAdmin, async (req: Request, res: Response) => {
    try {
      const plans = await storage.getAllMembershipPlans();
      res.json({ plans });
    } catch (error) {
      res.status(500).json({ error: "Failed to get membership plans" });
    }
  });

  // Create membership plan (admin)
  app.post("/api/admin/membership/plans", requireAdmin, async (req: Request, res: Response) => {
    try {
      const { name, description, price, duration, isActive = true } = req.body;
      
      if (!name || !description || price === undefined || duration === undefined) {
        return res.status(400).json({ error: "Missing required fields" });
      }

      const plan = await storage.createMembershipPlan({
        name,
        description,
        price: price.toString(),
        duration: parseInt(duration),
        isActive,
      });
      
      res.json({ plan });
    } catch (error) {
      console.error("Create membership plan error:", error);
      res.status(500).json({ error: "Failed to create membership plan" });
    }
  });

  // Update membership plan (admin)
  app.patch("/api/admin/membership/plans/:id", requireAdmin, async (req: Request, res: Response) => {
    try {
      const updateData: any = {};
      
      if (req.body.name !== undefined) updateData.name = req.body.name;
      if (req.body.description !== undefined) updateData.description = req.body.description;
      if (req.body.price !== undefined) updateData.price = req.body.price.toString();
      if (req.body.duration !== undefined) updateData.duration = parseInt(req.body.duration);
      if (req.body.isActive !== undefined) updateData.isActive = req.body.isActive;
      
      const plan = await storage.updateMembershipPlan(req.params.id, updateData);
      
      if (!plan) {
        return res.status(404).json({ error: "Membership plan not found" });
      }
      
      res.json({ plan });
    } catch (error) {
      console.error("Update membership plan error:", error);
      res.status(500).json({ error: "Failed to update membership plan" });
    }
  });

  // Delete membership plan (admin)
  app.delete("/api/admin/membership/plans/:id", requireAdmin, async (req: Request, res: Response) => {
    try {
      const success = await storage.deleteMembershipPlan(req.params.id);
      
      if (!success) {
        return res.status(404).json({ error: "Membership plan not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Delete membership plan error:", error);
      res.status(500).json({ error: "Failed to delete membership plan" });
    }
  });

  // === ADMIN QUIZ MANAGEMENT ROUTES ===

  // Create quiz
  app.post("/api/admin/quizzes", requireAdmin, async (req: Request, res: Response) => {
    try {
      const quizData = insertQuizSchema.parse(req.body);
      const quiz = await storage.createQuiz(quizData);
      res.json({ quiz });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid quiz data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create quiz" });
    }
  });

  // Update quiz
  app.patch("/api/admin/quizzes/:id", requireAdmin, async (req: Request, res: Response) => {
    try {
      const quiz = await storage.updateQuiz(req.params.id, req.body);
      
      if (!quiz) {
        return res.status(404).json({ error: "Quiz not found" });
      }

      res.json({ quiz });
    } catch (error) {
      res.status(500).json({ error: "Failed to update quiz" });
    }
  });

  // Delete quiz
  app.delete("/api/admin/quizzes/:id", requireAdmin, async (req: Request, res: Response) => {
    try {
      const deleted = await storage.deleteQuiz(req.params.id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Quiz not found" });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete quiz" });
    }
  });

  // Create question
  app.post("/api/admin/questions", requireAdmin, async (req: Request, res: Response) => {
    try {
      const questionData = insertQuestionSchema.parse(req.body);
      const question = await storage.createQuestion(questionData);
      res.json({ question });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid question data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create question" });
    }
  });

  // Update question
  app.patch("/api/admin/questions/:id", requireAdmin, async (req: Request, res: Response) => {
    try {
      const question = await storage.updateQuestion(req.params.id, req.body);
      
      if (!question) {
        return res.status(404).json({ error: "Question not found" });
      }

      res.json({ question });
    } catch (error) {
      res.status(500).json({ error: "Failed to update question" });
    }
  });

  // Delete question
  app.delete("/api/admin/questions/:id", requireAdmin, async (req: Request, res: Response) => {
    try {
      const deleted = await storage.deleteQuestion(req.params.id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Question not found" });
      }

      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete question" });
    }
  });

  // === ADMIN ANALYTICS ROUTES ===

  // Get analytics
  app.get("/api/admin/analytics", requireAdmin, async (req: Request, res: Response) => {
    try {
      const totalUsers = await storage.getTotalUsers();
      const totalRevenue = await storage.getTotalRevenue();
      const averageScore = await storage.getAverageScore();
      const recentAttempts = await storage.getRecentAttempts(10);
      const quizzes = await storage.getAllQuizzes();

      res.json({
        totalUsers,
        totalRevenue,
        averageScore,
        activeQuizzes: quizzes.filter((q) => q.isActive).length,
        recentAttempts,
      });
    } catch (error) {
      res.status(500).json({ error: "Failed to get analytics" });
    }
  });

  // === SPLIT PAYMENT SETTINGS ROUTES ===

  // Get split payment settings
  app.get("/api/admin/split-payment-settings", requireAdmin, async (req: Request, res: Response) => {
    try {
      const settings = await storage.getSplitPaymentSettings();
      res.json({ settings: settings || null });
    } catch (error) {
      console.error("Get split payment settings error:", error);
      res.status(500).json({ error: "Failed to get split payment settings" });
    }
  });

  // Create split payment settings
  app.post("/api/admin/split-payment-settings", requireAdmin, async (req: Request, res: Response) => {
    try {
      const settings = await storage.createSplitPaymentSettings(req.body);
      res.json({ settings });
    } catch (error) {
      console.error("Create split payment settings error:", error);
      res.status(500).json({ error: "Failed to create split payment settings" });
    }
  });

  // Update split payment settings
  app.patch("/api/admin/split-payment-settings/:id", requireAdmin, async (req: Request, res: Response) => {
    try {
      const settings = await storage.updateSplitPaymentSettings(req.params.id, req.body);
      
      if (!settings) {
        return res.status(404).json({ error: "Split payment settings not found" });
      }
      
      res.json({ settings });
    } catch (error) {
      console.error("Update split payment settings error:", error);
      res.status(500).json({ error: "Failed to update split payment settings" });
    }
  });

  // Delete split payment settings
  app.delete("/api/admin/split-payment-settings/:id", requireAdmin, async (req: Request, res: Response) => {
    try {
      const success = await storage.deleteSplitPaymentSettings(req.params.id);
      
      if (!success) {
        return res.status(404).json({ error: "Split payment settings not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Delete split payment settings error:", error);
      res.status(500).json({ error: "Failed to delete split payment settings" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
