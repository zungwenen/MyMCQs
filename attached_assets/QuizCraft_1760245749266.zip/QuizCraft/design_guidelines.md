# MCQ Quiz Web App - Design Guidelines

## Design Approach

**Selected System:** Material Design 3 principles with modern educational platform influences (Duolingo, Khan Academy)  
**Rationale:** Utility-focused quiz application requiring clear feedback states, information hierarchy, and mobile-first responsive design. Material Design provides excellent component patterns for forms, progress indicators, and data visualization while maintaining accessibility standards.

---

## Core Design Elements

### A. Color Palette

**Primary Colors:**
- Primary: 217 91% 60% (Vibrant blue - trust, learning, focus)
- Primary Dark: 217 91% 45% (darker state)
- On Primary: 0 0% 100% (white text)

**Secondary/Accent:**
- Success: 142 76% 36% (correct answers, achievements)
- Error: 0 84% 60% (incorrect answers, alerts)
- Warning: 45 93% 47% (premium features, important notices)
- Info: 199 89% 48% (helpful tips, information)

**Neutral Palette:**
- Background Light: 0 0% 98%
- Background Dark: 222 47% 11%
- Surface Light: 0 0% 100%
- Surface Dark: 217 33% 17%
- Text Primary Light: 222 47% 11%
- Text Primary Dark: 0 0% 98%
- Text Secondary: 215 16% 47%

**Quiz-Specific Colors:**
- Quiz Card Border: 217 20% 85%
- Free Tag: 142 71% 45% (green)
- Premium Tag: 280 60% 50% (purple)
- Timer Warning: 25 95% 53% (orange when <30s)

### B. Typography

**Font Families:**
- Primary: 'Inter' (headers, UI elements) - via Google Fonts
- Secondary: 'Inter' (body text, questions)
- Monospace: 'JetBrains Mono' (OTP inputs, timer)

**Type Scale:**
- Hero/Landing: text-5xl font-bold (48px)
- Page Headers: text-3xl font-bold (30px)
- Section Headers: text-2xl font-semibold (24px)
- Card Titles: text-xl font-semibold (20px)
- Body Large: text-lg (18px) - quiz questions
- Body: text-base (16px)
- Small: text-sm (14px) - metadata
- Tiny: text-xs (12px) - labels, tags

**Question Text Styling:**
- Font size: text-lg md:text-xl
- Line height: leading-relaxed
- Weight: font-medium
- Max width: max-w-3xl for readability

### C. Layout System

**Spacing Primitives:**
- Core units: 2, 4, 6, 8, 12, 16, 20, 24 (Tailwind scale)
- Common patterns:
  - Card padding: p-6 md:p-8
  - Section spacing: py-12 md:py-16
  - Component gaps: gap-4 or gap-6
  - Button padding: px-6 py-3

**Container Widths:**
- Max width: max-w-7xl (admin dashboard, quiz lists)
- Content width: max-w-4xl (quiz interface)
- Form width: max-w-md (auth forms)
- Full width: w-full (mobile, modals)

**Grid System:**
- Quiz cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3
- Admin tables: Single column with horizontal scroll on mobile
- Dashboard stats: grid-cols-2 md:grid-cols-4

### D. Component Library

**Navigation (User):**
- Top bar: Fixed header with logo, user avatar, logout
- Mobile: Hamburger menu with slide-out drawer
- Height: h-16
- Background: Glassmorphic blur with subtle border-b

**Navigation (Admin):**
- Sidebar: Fixed left sidebar (hidden on mobile)
- Width: w-64
- Collapsible sections for different admin functions
- Active state: Background accent with left border indicator

**Cards - Quiz Subject Cards:**
- Border: border rounded-xl
- Shadow: shadow-md hover:shadow-xl transition
- Padding: p-6
- Structure:
  - Subject icon/emoji (top)
  - Title (text-xl font-semibold)
  - Description (text-sm text-gray-600, 2 lines)
  - Tag badge (Free/Premium)
  - CTA button (full width)

**Cards - Question Cards:**
- Border: border-2 rounded-lg
- Options: Radio buttons with full-width clickable areas
- Selected state: border-primary bg-primary/5
- Correct feedback: border-green-500 bg-green-50
- Incorrect feedback: border-red-500 bg-red-50

**Forms:**
- Input fields: 
  - Border: border-2 rounded-lg
  - Height: h-12
  - Focus: ring-2 ring-primary
  - Error: border-red-500
- OTP Input: 
  - Individual digit boxes: w-12 h-14 text-2xl text-center
  - Font: font-mono
  - Gap: gap-2

**Buttons:**
- Primary: bg-primary text-white rounded-lg px-6 py-3 font-semibold
- Secondary: border-2 border-primary text-primary rounded-lg px-6 py-3
- Outline on images: backdrop-blur-md bg-white/20 border-2 border-white text-white
- Icon buttons: p-3 rounded-full
- Disabled: opacity-50 cursor-not-allowed

**Progress Indicators:**
- Quiz progress bar:
  - Height: h-2 rounded-full
  - Background: bg-gray-200
  - Fill: bg-primary transition-all
  - Show percentage text above
- Loading: Spinner with brand colors

**Modals/Overlays:**
- Background: backdrop-blur-sm bg-black/40
- Content: bg-white rounded-2xl p-8 max-w-md
- Header: text-2xl font-bold mb-4
- Close button: Absolute top-right

**Data Display:**
- Score cards: Large number (text-4xl font-bold) with label
- Stats grid: 4-column on desktop, 2 on mobile
- Tables: Striped rows with hover states
- Badges: rounded-full px-3 py-1 text-xs font-semibold

**Timer Display:**
- Font: font-mono text-2xl
- Warning state (<30s): text-orange-500 animate-pulse
- Critical state (<10s): text-red-500 font-bold

**Feedback Elements:**
- Success toast: bg-green-500 text-white rounded-lg p-4
- Error toast: bg-red-500 text-white rounded-lg p-4
- Info banner: bg-blue-50 border-l-4 border-blue-500 p-4

### E. Animations & Interactions

**Use Sparingly:**
- Card hover: Subtle lift (translate-y-1) + shadow increase
- Button hover: Slight scale (scale-105)
- Page transitions: Fade in only
- Modal entrance: Fade + scale from center
- Success feedback: Gentle pulse once
- Loading states: Subtle skeleton shimmer

**NO complex scroll animations or parallax effects**

---

## Screen-Specific Guidelines

### Authentication Screens
- Centered layout with max-w-md
- Phone input with country code selector
- OTP: 6 individual boxes, auto-focus next
- Status messages below input
- "Resend OTP" link with countdown timer
- Twilio branding/badge at bottom

### User Dashboard
- Hero section (if used): Minimal - user greeting + quick stats (h-48)
- No large hero image needed
- Subject grid: 3 columns desktop, 1 mobile
- Each card: Clear Free/Premium indicator
- Filter/search bar above grid
- Empty state: Friendly illustration + message

### Quiz Interface
- Fixed header: Progress bar + timer + question counter
- Question area: Centered, max-w-3xl
- Options: Full-width, clear selection states
- Navigation: Previous/Next buttons (bottom)
- Mark for review: Checkbox with flag icon
- Submit: Prominent button, requires confirmation modal

### Results Screen
- Large score display at top (text-6xl)
- Pass/fail indicator with color coding
- Breakdown: Correct/Incorrect/Unattempted
- Time spent
- Review answers button
- Retake quiz CTA

### Admin Dashboard
- Sidebar navigation with icons
- Main content area: max-w-7xl
- Tables: Sortable columns, pagination
- Action buttons: Icon + text
- Forms: Two-column layout on desktop
- Analytics: Charts with clear legends

### Payment Flow
- Modal overlay for payment
- Paystack integration: Branded iframe
- Clear pricing display
- Security badges
- Transaction confirmation screen

---

## Images

**User Dashboard:**
- Empty state illustration: Friendly character holding books/quiz icon (centered, ~200px width)

**Admin Dashboard:**  
- No images needed - focus on data tables and forms

**Results Screen:**
- Success illustration: Trophy/celebration icon (~120px) if passed
- Retry illustration: Friendly encouragement graphic if failed

**Hero Images:** 
- NOT REQUIRED - This is a utility-focused app where dashboard efficiency matters more than visual storytelling

---

## Accessibility & Responsive Design

- Minimum touch target: 44x44px
- Color contrast: WCAG AA compliant
- Focus indicators: Visible ring on all interactive elements
- Screen reader labels on all inputs
- Mobile breakpoints: sm:640px, md:768px, lg:1024px, xl:1280px
- Mobile-first approach: Stack everything vertically, larger touch targets
- Dark mode: Maintained throughout with proper contrast ratios