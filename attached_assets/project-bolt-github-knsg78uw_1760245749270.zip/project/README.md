# QuizMaster - Comprehensive MCQ Quiz Application

A modern, full-stack multiple-choice quiz web application built with React, TypeScript, and Supabase. Features WhatsApp/SMS authentication, payment integration, and comprehensive admin controls.

## 🚀 Features

### User Features
- **Phone Authentication**: WhatsApp/SMS OTP verification via Twilio
- **Admin Authentication**: Dedicated email/password login for administrators
- **Interactive Quizzes**: Timed quizzes with progress tracking
- **Premium Content**: Paystack payment integration for premium quizzes
- **Progress Tracking**: Detailed quiz history and performance analytics
- **Responsive Design**: Mobile-first design with dark/light mode
- **Real-time Updates**: Live quiz progress and leaderboards

### Admin Features
- **Quiz Management**: Create, edit, and manage quizzes and questions
- **User Analytics**: Comprehensive user engagement metrics
- **Payment Tracking**: Monitor premium purchases and revenue
- **Content Control**: Manage subjects, difficulty levels, and access controls

## 🛠️ Technical Stack

- **Frontend**: React 18+ with TypeScript
- **Styling**: TailwindCSS with dark/light mode support
- **State Management**: Zustand for global state
- **Data Fetching**: TanStack Query for server state management
- **Backend**: Supabase (PostgreSQL, Auth, Edge Functions, Storage)
- **Authentication**: Twilio API (WhatsApp primary, SMS fallback)
- **Payments**: Paystack integration
- **Animations**: Framer Motion

## 📦 Installation & Setup

### Prerequisites
- Node.js 18+ and npm
- Supabase account
- Twilio account (for OTP)
- Paystack account (for payments)

### 1. Clone and Install Dependencies
```bash
git clone <repository-url>
cd quizmaster-app
npm install
```

### 2. Environment Variables
Copy `.env.example` to `.env` and fill in your credentials:

```bash
cp .env.example .env
```

Required environment variables:
```env
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
TWILIO_ACCOUNT_SID=your_twilio_account_sid
TWILIO_AUTH_TOKEN=your_twilio_auth_token
TWILIO_PHONE_NUMBER=your_twilio_phone_number
PAYSTACK_SECRET_KEY=your_paystack_secret_key
PAYSTACK_PUBLIC_KEY=your_paystack_public_key
```

### 3. Database Setup
The database schema is automatically applied when you connect Supabase. The migration file creates:
- User profiles and authentication
- Quiz subjects and questions
- Payment tracking
- Analytics tables
- Row Level Security policies

### 4. Run the Application
```bash
npm run dev
```

## 🏗️ Architecture

### Frontend Structure
```
src/
├── components/          # Reusable UI components
│   ├── ui/             # Basic UI elements (Button, Input, Card)
│   ├── auth/           # Authentication components
│   ├── quiz/           # Quiz-related components
│   └── admin/          # Admin dashboard components
├── pages/              # Route components
├── hooks/              # Custom React hooks
├── store/              # Zustand stores
├── services/           # API services
├── utils/              # Utility functions
└── types/              # TypeScript definitions
```

### Backend (Supabase)
```
supabase/
├── migrations/         # Database schema migrations
└── functions/          # Edge functions
    ├── send-otp/       # Twilio OTP integration
    ├── verify-payment/ # Paystack verification
    └── _shared/        # Shared utilities
```

## 🔐 Authentication Flow

### User Authentication
1. **Phone Number Entry**: User enters phone with country code
2. **OTP Generation**: System generates 6-digit code
3. **Delivery Attempt**: 
   - Primary: WhatsApp via Twilio
   - Fallback: SMS if WhatsApp fails
4. **Verification**: User enters OTP code
5. **Profile Creation**: Automatic profile setup on first login

### Admin Authentication
1. **Admin Login Page**: Administrators access `/admin/login`
2. **Email/Password**: Standard email and password authentication
3. **Admin Verification**: System checks admin_users table for privileges
4. **Dashboard Access**: Direct redirect to admin dashboard upon success

## 💳 Payment Integration

### Paystack Integration
- Secure payment processing for premium content
- Split payment support for multiple stakeholders
- Webhook verification for payment confirmation
- Automatic access grant upon successful payment

### Payment Flow
1. User selects premium quiz
2. Paystack checkout initialization
3. Payment processing
4. Webhook verification via Edge Function
5. Database update and access grant

## 🎯 Quiz System

### Quiz Features
- **Multiple Choice Questions**: A, B, C, D options
- **Timer Support**: Optional time limits
- **Progress Tracking**: Save and resume capability
- **Randomization**: Question order randomization
- **Scoring**: Automatic scoring with pass/fail logic
- **Explanations**: Optional answer explanations

### Question Management
- Rich text editor for question content
- Image support for visual questions
- Bulk import/export capabilities
- Categorization by subjects and difficulty

## 📊 Analytics & Reporting

### User Analytics
- Quiz completion rates
- Average scores and performance trends
- Time spent on quizzes
- Payment conversion metrics

### Admin Dashboard
- User engagement metrics
- Revenue tracking
- Popular content analysis
- Performance monitoring

## 🎨 Design System

### Color Palette
- **Primary**: Blue (#3B82F6)
- **Secondary**: Indigo (#6366F1) 
- **Accent**: Emerald (#10B981)
- **Success**: Green
- **Warning**: Amber
- **Error**: Red

### Responsive Design
- **Mobile**: < 768px
- **Tablet**: 768px - 1024px  
- **Desktop**: > 1024px

### Accessibility
- WCAG 2.1 AA compliance
- Keyboard navigation support
- Screen reader optimization
- High contrast mode support

## 🚀 Deployment

### Frontend Deployment
The application can be deployed to any static hosting service:

```bash
npm run build
```

### Supabase Deployment
Edge functions are automatically deployed when using Supabase hosting.

### Environment Variables
Ensure all environment variables are properly set in your deployment environment.

## 🔧 Development

### Available Scripts
```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build
npm run lint         # Run ESLint
npm run typecheck    # Run TypeScript checks
```

### Code Quality
- ESLint configuration for code quality
- TypeScript for type safety
- Prettier for code formatting
- Husky for pre-commit hooks

## 📝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests if applicable
5. Submit a pull request

## 📄 License

This project is licensed under the MIT License - see the LICENSE file for details.

## 🆘 Support

For support and questions:
- Create an issue in the repository
- Check the documentation
- Review the FAQ section

## 🔄 Roadmap

- [ ] Mobile app development (React Native)
- [ ] Advanced analytics dashboard
- [ ] Multi-language support
- [ ] Voice questions support
- [ ] AI-powered question generation
- [ ] Advanced gamification features