import { useState } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { supabase } from '../lib/supabase';

interface PaystackConfig {
  email: string;
  amount: number;
  reference: string;
  publicKey: string;
}

interface PaystackResponse {
  reference: string;
  status: string;
  trans?: string;
  transaction?: string;
  trxref?: string;
}

export const usePaystack = () => {
  const [isProcessing, setIsProcessing] = useState(false);
  const queryClient = useQueryClient();

  const initializePayment = async (
    amount: number,
    email: string,
    quizId: string,
    userId: string,
    onSuccess?: () => void,
    onClose?: () => void
  ) => {
    const publicKey = import.meta.env.VITE_PAYSTACK_PUBLIC_KEY;

    if (!publicKey) {
      alert('Payment system is not configured. Please contact support.');
      return;
    }

    const reference = `quiz_${quizId}_${Date.now()}`;

    try {
      setIsProcessing(true);

      const { error: paymentRecordError } = await supabase
        .from('payments')
        .insert({
          user_id: userId,
          quiz_id: quizId,
          paystack_reference: reference,
          amount_naira: amount,
          payment_status: 'pending',
        });

      if (paymentRecordError) {
        throw new Error('Failed to create payment record');
      }

      const handler = (window as any).PaystackPop.setup({
        key: publicKey,
        email,
        amount: amount * 100,
        currency: 'NGN',
        ref: reference,
        callback: async (response: PaystackResponse) => {
          try {
            const { data: verificationData, error: verificationError } = await supabase.functions.invoke(
              'verify-payment',
              {
                body: {
                  reference: response.reference,
                  userId,
                },
              }
            );

            if (verificationError || !verificationData?.success) {
              throw new Error('Payment verification failed');
            }

            queryClient.invalidateQueries({ queryKey: ['profile'] });
            queryClient.invalidateQueries({ queryKey: ['quiz-detail'] });

            if (onSuccess) {
              onSuccess();
            }

            alert('Payment successful! You now have access to this quiz.');
          } catch (error) {
            console.error('Payment verification error:', error);
            alert('Payment verification failed. Please contact support with reference: ' + response.reference);
          } finally {
            setIsProcessing(false);
          }
        },
        onClose: () => {
          setIsProcessing(false);
          if (onClose) {
            onClose();
          }
        },
      });

      handler.openIframe();
    } catch (error) {
      console.error('Payment initialization error:', error);
      alert('Failed to initialize payment. Please try again.');
      setIsProcessing(false);
    }
  };

  return {
    initializePayment,
    isProcessing,
  };
};
