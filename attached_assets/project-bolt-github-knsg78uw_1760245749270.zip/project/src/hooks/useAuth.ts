import { useEffect, useCallback, useRef } from 'react';
import { useAuthStore } from '../store/authStore';
import { supabase } from '../lib/supabase';

export const useAuth = () => {
  const {
    user,
    profile,
    isAdmin,
    isLoading,
    isAuthenticated,
    setUser,
    setProfile,
    setIsAdmin,
    setLoading,
  } = useAuthStore();

  const isLoadingUserData = useRef(false);

  const loadUserData = useCallback(async (userId: string) => {
    if (isLoadingUserData.current) {
      return;
    }

    isLoadingUserData.current = true;

    try {
      const [profileResult, adminResult] = await Promise.all([
        supabase
          .from('profiles')
          .select('*')
          .eq('user_id', userId)
          .maybeSingle(),
        supabase
          .from('admin_users')
          .select('id, role, permissions')
          .eq('user_id', userId)
          .maybeSingle()
      ]);

      if (profileResult.error && profileResult.error.code !== 'PGRST116') {
        console.error('Error loading profile:', profileResult.error);
      }

      if (adminResult.error && adminResult.error.code !== 'PGRST116') {
        console.error('Error loading admin status:', adminResult.error);
      }

      if (profileResult.data) {
        setProfile(profileResult.data);
      }

      setIsAdmin(!!adminResult.data);
      setLoading(false);
    } catch (error) {
      console.error('Error loading user data:', error);
      setLoading(false);
    } finally {
      isLoadingUserData.current = false;
    }
  }, [setProfile, setIsAdmin, setLoading]);

  const refreshProfile = useCallback(async () => {
    if (user?.id) {
      await loadUserData(user.id);
    }
  }, [user?.id, loadUserData]);

  useEffect(() => {
    let mounted = true;

    const getInitialSession = async () => {
      try {
        const { data: { session }, error } = await supabase.auth.getSession();

        if (!mounted) return;

        if (error) {
          console.error('Error getting session:', error);
          setLoading(false);
          return;
        }

        if (session?.user) {
          setUser(session.user);
          await loadUserData(session.user.id);
        } else {
          setUser(null);
          setLoading(false);
        }
      } catch (error) {
        console.error('Error in getInitialSession:', error);
        if (mounted) {
          setLoading(false);
        }
      }
    };

    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (!mounted) return;

        console.log('Auth state changed:', event, session?.user?.id);

        if (event === 'SIGNED_IN' && session?.user) {
          setUser(session.user);
          await loadUserData(session.user.id);
        } else if (event === 'SIGNED_OUT') {
          setUser(null);
          setProfile(null);
          setIsAdmin(false);
          setLoading(false);
        } else if (event === 'TOKEN_REFRESHED' && session?.user) {
          setUser(session.user);
        }
      }
    );

    getInitialSession();

    return () => {
      mounted = false;
      subscription.unsubscribe();
    };
  }, [setUser, setProfile, setIsAdmin, setLoading, loadUserData]);

  return {
    user,
    profile,
    isAdmin,
    isLoading,
    isAuthenticated,
    refreshProfile,
  };
};