import React, { memo, useCallback } from 'react';
import { NavLink } from 'react-router-dom';
import {
  Home,
  BookOpen,
  Trophy,
  User,
  Settings,
  CreditCard,
  X,
  Crown,
  Shield,
  List
} from 'lucide-react';
import { useAppStore } from '../store/appStore';
import { useAuth } from '../hooks/useAuth';
import { cn } from '../utils/cn';
import { Button } from './ui/Button';

const navigation = [
  { name: 'Dashboard', href: '/dashboard', icon: Home },
  { name: 'Quizzes', href: '/quizzes', icon: BookOpen },
  { name: 'Leaderboard', href: '/leaderboard', icon: Trophy },
  { name: 'Profile', href: '/profile', icon: User },
  { name: 'Payments', href: '/payments', icon: CreditCard },
  { name: 'Settings', href: '/settings', icon: Settings },
];

export const Sidebar: React.FC = memo(() => {
  const sidebarOpen = useAppStore((state) => state.sidebarOpen);
  const setSidebarOpen = useAppStore((state) => state.setSidebarOpen);
  const { profile, isAdmin } = useAuth();

  const handleCloseSidebar = useCallback(() => {
    setSidebarOpen(false);
  }, [setSidebarOpen]);

  return (
    <>
      {/* Desktop sidebar */}
      <div className="hidden lg:flex lg:flex-col lg:w-64 lg:fixed lg:inset-y-0 bg-white dark:bg-gray-800 border-r border-gray-200 dark:border-gray-700">
        <div className="flex-1 flex flex-col min-h-0 overflow-y-auto">
          {/* Logo */}
          <div className="flex items-center h-16 px-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900 dark:text-white">
                QuizMaster
              </span>
            </div>
          </div>

          {/* Premium status */}
          {profile?.is_premium && (
            <div className="px-4 py-3 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 mx-4 mt-4 rounded-lg flex-shrink-0">
              <div className="flex items-center space-x-2">
                <Crown className="w-4 h-4 text-amber-600" />
                <span className="text-sm font-medium text-amber-800 dark:text-amber-400">
                  Premium Member
                </span>
              </div>
            </div>
          )}

          {/* Admin status */}
          {isAdmin && (
            <div className="px-4 py-3 bg-gradient-to-r from-red-50 to-pink-50 dark:from-red-900/20 dark:to-pink-900/20 mx-4 mt-4 rounded-lg flex-shrink-0">
              <div className="flex items-center space-x-2">
                <Shield className="w-4 h-4 text-red-600" />
                <span className="text-sm font-medium text-red-800 dark:text-red-400">
                  Administrator
                </span>
              </div>
            </div>
          )}

          {/* Navigation */}
          <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto">
            {navigation.map((item) => (
              <NavLink
                key={item.name}
                to={item.href}
                className={({ isActive }) =>
                  cn(
                    'group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                    isActive
                      ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-400'
                      : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                  )
                }
              >
                <item.icon className="mr-3 w-5 h-5" />
                {item.name}
              </NavLink>
            ))}

            {/* Admin Navigation */}
            {isAdmin && (
              <>
                <div className="pt-4 pb-2">
                  <h3 className="px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Administration
                  </h3>
                </div>
                <NavLink
                  to="/admin/dashboard"
                  className={({ isActive }) =>
                    cn(
                      'group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                      isActive
                        ? 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-400'
                        : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                    )
                  }
                >
                  <Shield className="mr-3 w-5 h-5" />
                  Admin Dashboard
                </NavLink>
                <NavLink
                  to="/admin/subjects"
                  className={({ isActive }) =>
                    cn(
                      'group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                      isActive
                        ? 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-400'
                        : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                    )
                  }
                >
                  <BookOpen className="mr-3 w-5 h-5" />
                  Manage Subjects
                </NavLink>
                <NavLink
                  to="/admin/quizzes"
                  className={({ isActive }) =>
                    cn(
                      'group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                      isActive
                        ? 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-400'
                        : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                    )
                  }
                >
                  <BookOpen className="mr-3 w-5 h-5" />
                  Manage Quizzes
                </NavLink>
                <NavLink
                  to="/admin/questions"
                  className={({ isActive }) =>
                    cn(
                      'group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                      isActive
                        ? 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-400'
                        : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                    )
                  }
                >
                  <List className="mr-3 w-5 h-5" />
                  Manage Questions
                </NavLink>
              </>
            )}
          </nav>
        </div>
      </div>

      {/* Mobile sidebar */}
      <div
        className={cn(
          'lg:hidden fixed inset-y-0 left-0 z-40 w-64 bg-white dark:bg-gray-800 transform transition-transform duration-300 ease-in-out border-r border-gray-200 dark:border-gray-700',
          sidebarOpen ? 'translate-x-0' : '-translate-x-full'
        )}
      >
        <div className="flex flex-col h-full">
          <div className="flex items-center justify-between h-16 px-4 border-b border-gray-200 dark:border-gray-700 flex-shrink-0">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold text-gray-900 dark:text-white">
                QuizMaster
              </span>
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={handleCloseSidebar}
            >
              <X className="w-5 h-5" />
            </Button>
          </div>

          <div className="flex-1 overflow-y-auto">
            {/* Premium status */}
            {profile?.is_premium && (
              <div className="px-4 py-3 bg-gradient-to-r from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 mx-4 mt-4 rounded-lg">
                <div className="flex items-center space-x-2">
                  <Crown className="w-4 h-4 text-amber-600" />
                  <span className="text-sm font-medium text-amber-800 dark:text-amber-400">
                    Premium Member
                  </span>
                </div>
              </div>
            )}

            {/* Admin status */}
            {isAdmin && (
              <div className="px-4 py-3 bg-gradient-to-r from-red-50 to-pink-50 dark:from-red-900/20 dark:to-pink-900/20 mx-4 mt-4 rounded-lg">
                <div className="flex items-center space-x-2">
                  <Shield className="w-4 h-4 text-red-600" />
                  <span className="text-sm font-medium text-red-800 dark:text-red-400">
                    Administrator
                  </span>
                </div>
              </div>
            )}

            {/* Navigation */}
            <nav className="px-4 py-4 space-y-1">
              {navigation.map((item) => (
                <NavLink
                  key={item.name}
                  to={item.href}
                  className={({ isActive }) =>
                    cn(
                      'group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                      isActive
                        ? 'bg-blue-100 text-blue-700 dark:bg-blue-900/50 dark:text-blue-400'
                        : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                    )
                  }
                  onClick={handleCloseSidebar}
                >
                  <item.icon className="mr-3 w-5 h-5" />
                  {item.name}
                </NavLink>
              ))}

              {/* Admin Navigation */}
              {isAdmin && (
                <>
                  <div className="pt-4 pb-2">
                    <h3 className="px-3 text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                      Administration
                    </h3>
                  </div>
                  <NavLink
                    to="/admin/dashboard"
                    className={({ isActive }) =>
                      cn(
                        'group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                        isActive
                          ? 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-400'
                          : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                      )
                    }
                    onClick={handleCloseSidebar}
                  >
                    <Shield className="mr-3 w-5 h-5" />
                    Admin Dashboard
                  </NavLink>
                  <NavLink
                    to="/admin/subjects"
                    className={({ isActive }) =>
                      cn(
                        'group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                        isActive
                          ? 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-400'
                          : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                      )
                    }
                    onClick={handleCloseSidebar}
                  >
                    <BookOpen className="mr-3 w-5 h-5" />
                    Manage Subjects
                  </NavLink>
                  <NavLink
                    to="/admin/quizzes"
                    className={({ isActive }) =>
                      cn(
                        'group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                        isActive
                          ? 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-400'
                          : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                      )
                    }
                    onClick={handleCloseSidebar}
                  >
                    <BookOpen className="mr-3 w-5 h-5" />
                    Manage Quizzes
                  </NavLink>
                  <NavLink
                    to="/admin/questions"
                    className={({ isActive }) =>
                      cn(
                        'group flex items-center px-3 py-2 text-sm font-medium rounded-lg transition-colors',
                        isActive
                          ? 'bg-red-100 text-red-700 dark:bg-red-900/50 dark:text-red-400'
                          : 'text-gray-700 hover:bg-gray-100 dark:text-gray-300 dark:hover:bg-gray-700'
                      )
                    }
                    onClick={handleCloseSidebar}
                  >
                    <List className="mr-3 w-5 h-5" />
                    Manage Questions
                  </NavLink>
                </>
              )}
            </nav>
          </div>
        </div>
      </div>
    </>
  );
});
