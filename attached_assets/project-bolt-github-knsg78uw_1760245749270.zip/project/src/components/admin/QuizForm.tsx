import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { supabase } from '../../lib/supabase';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

const quizSchema = z.object({
  title: z.string().min(1, 'Quiz title is required').max(200, 'Title must be less than 200 characters'),
  description: z.string().max(1000, 'Description must be less than 1000 characters').optional(),
  subject_id: z.string().min(1, 'Subject is required'),
  difficulty_level: z.enum(['beginner', 'intermediate', 'advanced']).optional(),
  time_limit_minutes: z.number().min(1, 'Time limit must be at least 1 minute').max(300, 'Time limit cannot exceed 300 minutes').optional(),
  passing_score: z.number().min(1, 'Passing score must be at least 1%').max(100, 'Passing score cannot exceed 100%'),
  question_randomize: z.boolean(),
  is_premium: z.boolean(),
  price_naira: z.number().min(0, 'Price cannot be negative'),
  is_active: z.boolean(),
  instant_feedback: z.boolean(),
});

type QuizFormData = z.infer<typeof quizSchema>;

interface Quiz {
  id: string;
  subject_id: string;
  title: string;
  description: string | null;
  difficulty_level: 'beginner' | 'intermediate' | 'advanced' | null;
  time_limit_minutes: number | null;
  passing_score: number;
  question_randomize: boolean;
  is_premium: boolean;
  price_naira: number;
  total_questions: number;
  is_active: boolean;
  instant_feedback: boolean;
}

interface QuizFormProps {
  quiz?: Quiz;
  onSuccess: () => void;
  onCancel: () => void;
}

export const QuizForm: React.FC<QuizFormProps> = ({
  quiz,
  onSuccess,
  onCancel,
}) => {
  const queryClient = useQueryClient();
  const isEditing = !!quiz;

  // Fetch subjects for dropdown
  const { data: subjects } = useQuery({
    queryKey: ['subjects'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('subjects')
        .select('id, name, icon')
        .order('display_order');
      
      if (error) throw error;
      return data;
    },
  });

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm<QuizFormData>({
    resolver: zodResolver(quizSchema),
    defaultValues: {
      title: quiz?.title || '',
      description: quiz?.description || '',
      subject_id: quiz?.subject_id || '',
      difficulty_level: quiz?.difficulty_level || undefined,
      time_limit_minutes: quiz?.time_limit_minutes || undefined,
      passing_score: quiz?.passing_score || 60,
      question_randomize: quiz?.question_randomize ?? true,
      is_premium: quiz?.is_premium || false,
      price_naira: quiz?.price_naira || 0,
      is_active: quiz?.is_active ?? true,
      instant_feedback: quiz?.instant_feedback || false,
    },
  });

  const isPremium = watch('is_premium');
  const hasTimeLimit = watch('time_limit_minutes');

  const mutation = useMutation({
    mutationFn: async (data: QuizFormData) => {
      const quizData = {
        ...data,
        time_limit_minutes: data.time_limit_minutes || null,
        difficulty_level: data.difficulty_level || null,
        description: data.description || null,
      };

      if (isEditing) {
        const { error } = await supabase
          .from('quizzes')
          .update(quizData)
          .eq('id', quiz.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('quizzes')
          .insert([{ ...quizData, total_questions: 0 }]);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-quizzes'] });
      queryClient.invalidateQueries({ queryKey: ['quizzes'] });
      onSuccess();
    },
    onError: (error) => {
      console.error('Error saving quiz:', error);
      alert('Failed to save quiz. Please try again.');
    },
  });

  const onSubmit = (data: QuizFormData) => {
    mutation.mutate(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      {/* Basic Information */}
      <div className="space-y-4">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white">
          Basic Information
        </h3>
        
        <Input
          {...register('title')}
          label="Quiz Title"
          placeholder="Enter quiz title"
          error={errors.title?.message}
        />

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Description
          </label>
          <textarea
            {...register('description')}
            rows={3}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-50 disabled:text-gray-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white transition-colors duration-200"
            placeholder="Enter quiz description (optional)"
          />
          {errors.description && (
            <p className="text-sm text-red-600 dark:text-red-400 mt-1">
              {errors.description.message}
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Subject
          </label>
          <select
            {...register('subject_id')}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white transition-colors duration-200"
          >
            <option value="">Select a subject</option>
            {subjects?.map((subject) => (
              <option key={subject.id} value={subject.id}>
                {subject.icon} {subject.name}
              </option>
            ))}
          </select>
          {errors.subject_id && (
            <p className="text-sm text-red-600 dark:text-red-400 mt-1">
              {errors.subject_id.message}
            </p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
            Difficulty Level
          </label>
          <select
            {...register('difficulty_level')}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white transition-colors duration-200"
          >
            <option value="">Select difficulty (optional)</option>
            <option value="beginner">Beginner</option>
            <option value="intermediate">Intermediate</option>
            <option value="advanced">Advanced</option>
          </select>
        </div>
      </div>

      {/* Grading Settings */}
      <div className="space-y-4 border-t border-gray-200 dark:border-gray-700 pt-6">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white">
          Grading Settings
        </h3>

        <Input
          {...register('passing_score', { valueAsNumber: true })}
          type="number"
          label="Passing Score (%)"
          placeholder="60"
          min="1"
          max="100"
          error={errors.passing_score?.message}
          helperText="Minimum percentage required to pass the quiz"
        />

        <Input
          {...register('time_limit_minutes', { valueAsNumber: true })}
          type="number"
          label="Time Limit (minutes)"
          placeholder="30"
          min="1"
          max="300"
          error={errors.time_limit_minutes?.message}
          helperText="Leave empty for no time limit"
        />

        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <input
              {...register('question_randomize')}
              type="checkbox"
              id="question_randomize"
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            />
            <label
              htmlFor="question_randomize"
              className="text-sm font-medium text-gray-700 dark:text-gray-300"
            >
              Randomize Question Order
            </label>
          </div>

          <div className="flex items-center space-x-2">
            <input
              {...register('instant_feedback')}
              type="checkbox"
              id="instant_feedback"
              className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            />
            <label
              htmlFor="instant_feedback"
              className="text-sm font-medium text-gray-700 dark:text-gray-300"
            >
              Enable Instant Feedback
            </label>
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 ml-6">
            Show correct/incorrect feedback immediately after each question
          </p>
        </div>
      </div>

      {/* Premium Settings */}
      <div className="space-y-4 border-t border-gray-200 dark:border-gray-700 pt-6">
        <h3 className="text-lg font-medium text-gray-900 dark:text-white">
          Access Settings
        </h3>

        <div className="flex items-center space-x-2">
          <input
            {...register('is_premium')}
            type="checkbox"
            id="is_premium"
            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
          />
          <label
            htmlFor="is_premium"
            className="text-sm font-medium text-gray-700 dark:text-gray-300"
          >
            Premium Quiz
          </label>
        </div>

        {isPremium && (
          <Input
            {...register('price_naira', { valueAsNumber: true })}
            type="number"
            label="Price (₦)"
            placeholder="1000"
            min="0"
            error={errors.price_naira?.message}
            helperText="Price in Nigerian Naira"
          />
        )}

        <div className="flex items-center space-x-2">
          <input
            {...register('is_active')}
            type="checkbox"
            id="is_active"
            className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
          />
          <label
            htmlFor="is_active"
            className="text-sm font-medium text-gray-700 dark:text-gray-300"
          >
            Active Quiz
          </label>
        </div>
        <p className="text-xs text-gray-500 dark:text-gray-400 ml-6">
          Only active quizzes are visible to users
        </p>
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          disabled={mutation.isPending}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          loading={mutation.isPending}
          disabled={mutation.isPending}
        >
          {isEditing ? 'Update Quiz' : 'Create Quiz'}
        </Button>
      </div>
    </form>
  );
};