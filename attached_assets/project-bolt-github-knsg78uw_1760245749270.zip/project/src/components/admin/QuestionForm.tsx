import React, { useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../../lib/supabase';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

const questionSchema = z.object({
  question_text: z.string().min(1, 'Question text is required').max(1000, 'Question too long'),
  option_a: z.string().min(1, 'Option A is required').max(500, 'Option too long'),
  option_b: z.string().min(1, 'Option B is required').max(500, 'Option too long'),
  option_c: z.string().min(1, 'Option C is required').max(500, 'Option too long'),
  option_d: z.string().min(1, 'Option D is required').max(500, 'Option too long'),
  correct_answer: z.enum(['A', 'B', 'C', 'D'], {
    required_error: 'Please select the correct answer',
  }),
  explanation: z.string().max(1000, 'Explanation too long').optional(),
  points: z.number().min(1, 'Points must be at least 1').max(100, 'Points cannot exceed 100'),
  display_order: z.number().optional(),
});

type QuestionFormData = z.infer<typeof questionSchema>;

interface QuestionFormProps {
  quizId: string;
  question?: {
    id: string;
    question_text: string;
    option_a: string;
    option_b: string;
    option_c: string;
    option_d: string;
    correct_answer: 'A' | 'B' | 'C' | 'D';
    explanation: string | null;
    points: number;
    display_order: number | null;
  } | null;
  onSuccess: () => void;
  onCancel: () => void;
}

export const QuestionForm: React.FC<QuestionFormProps> = ({
  quizId,
  question,
  onSuccess,
  onCancel,
}) => {
  const queryClient = useQueryClient();

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
    watch,
  } = useForm<QuestionFormData>({
    resolver: zodResolver(questionSchema),
    defaultValues: {
      question_text: question?.question_text || '',
      option_a: question?.option_a || '',
      option_b: question?.option_b || '',
      option_c: question?.option_c || '',
      option_d: question?.option_d || '',
      correct_answer: question?.correct_answer || 'A',
      explanation: question?.explanation || '',
      points: question?.points || 1,
      display_order: question?.display_order || 0,
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: QuestionFormData) => {
      const questionData = {
        quiz_id: quizId,
        ...data,
      };

      if (question?.id) {
        const { error } = await supabase
          .from('questions')
          .update(questionData)
          .eq('id', question.id);

        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('questions')
          .insert(questionData);

        if (error) throw error;

        const { error: updateError } = await supabase.rpc('increment', {
          row_id: quizId,
          x: 1,
        }).single();
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-questions', quizId] });
      queryClient.invalidateQueries({ queryKey: ['admin-quizzes'] });
      onSuccess();
    },
    onError: (error) => {
      console.error('Error saving question:', error);
      alert('Failed to save question. Please try again.');
    },
  });

  const onSubmit = (data: QuestionFormData) => {
    mutation.mutate(data);
  };

  const correctAnswer = watch('correct_answer');

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Question Text *
        </label>
        <textarea
          {...register('question_text')}
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-white"
          placeholder="Enter your question here..."
        />
        {errors.question_text && (
          <p className="mt-1 text-sm text-red-600">{errors.question_text.message}</p>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Option A * {correctAnswer === 'A' && <span className="text-green-600">(Correct)</span>}
          </label>
          <textarea
            {...register('option_a')}
            rows={2}
            className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-white ${
              correctAnswer === 'A' ? 'border-green-500' : 'border-gray-300 dark:border-gray-600'
            }`}
            placeholder="Option A"
          />
          {errors.option_a && (
            <p className="mt-1 text-sm text-red-600">{errors.option_a.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Option B * {correctAnswer === 'B' && <span className="text-green-600">(Correct)</span>}
          </label>
          <textarea
            {...register('option_b')}
            rows={2}
            className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-white ${
              correctAnswer === 'B' ? 'border-green-500' : 'border-gray-300 dark:border-gray-600'
            }`}
            placeholder="Option B"
          />
          {errors.option_b && (
            <p className="mt-1 text-sm text-red-600">{errors.option_b.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Option C * {correctAnswer === 'C' && <span className="text-green-600">(Correct)</span>}
          </label>
          <textarea
            {...register('option_c')}
            rows={2}
            className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-white ${
              correctAnswer === 'C' ? 'border-green-500' : 'border-gray-300 dark:border-gray-600'
            }`}
            placeholder="Option C"
          />
          {errors.option_c && (
            <p className="mt-1 text-sm text-red-600">{errors.option_c.message}</p>
          )}
        </div>

        <div>
          <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Option D * {correctAnswer === 'D' && <span className="text-green-600">(Correct)</span>}
          </label>
          <textarea
            {...register('option_d')}
            rows={2}
            className={`w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-white ${
              correctAnswer === 'D' ? 'border-green-500' : 'border-gray-300 dark:border-gray-600'
            }`}
            placeholder="Option D"
          />
          {errors.option_d && (
            <p className="mt-1 text-sm text-red-600">{errors.option_d.message}</p>
          )}
        </div>
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Correct Answer *
        </label>
        <div className="grid grid-cols-4 gap-2">
          {(['A', 'B', 'C', 'D'] as const).map((option) => (
            <label
              key={option}
              className={`flex items-center justify-center px-4 py-3 border-2 rounded-lg cursor-pointer transition-all ${
                correctAnswer === option
                  ? 'border-green-500 bg-green-50 dark:bg-green-900/30'
                  : 'border-gray-300 dark:border-gray-600 hover:border-gray-400 dark:hover:border-gray-500'
              }`}
            >
              <input
                type="radio"
                {...register('correct_answer')}
                value={option}
                className="sr-only"
              />
              <span className="text-lg font-semibold">{option}</span>
            </label>
          ))}
        </div>
        {errors.correct_answer && (
          <p className="mt-1 text-sm text-red-600">{errors.correct_answer.message}</p>
        )}
      </div>

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
          Explanation (Optional)
        </label>
        <textarea
          {...register('explanation')}
          rows={2}
          className="w-full px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-800 dark:text-white"
          placeholder="Provide an explanation for the correct answer..."
        />
        {errors.explanation && (
          <p className="mt-1 text-sm text-red-600">{errors.explanation.message}</p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-4">
        <Input
          {...register('points', { valueAsNumber: true })}
          type="number"
          label="Points"
          error={errors.points?.message}
          min={1}
          max={100}
        />

        <Input
          {...register('display_order', { valueAsNumber: true })}
          type="number"
          label="Display Order (Optional)"
          error={errors.display_order?.message}
          min={0}
        />
      </div>

      <div className="flex justify-end space-x-3 pt-4 border-t border-gray-200 dark:border-gray-700">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          disabled={mutation.isPending}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          loading={mutation.isPending}
          disabled={mutation.isPending}
        >
          {question ? 'Update Question' : 'Add Question'}
        </Button>
      </div>
    </form>
  );
};
