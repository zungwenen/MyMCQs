import React from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { supabase } from '../../lib/supabase';
import { Input } from '../ui/Input';
import { Button } from '../ui/Button';

const subjectSchema = z.object({
  name: z.string().min(1, 'Subject name is required').max(100, 'Name must be less than 100 characters'),
  description: z.string().max(500, 'Description must be less than 500 characters').optional(),
  icon: z.string().max(10, 'Icon must be less than 10 characters').optional(),
  is_premium: z.boolean(),
  display_order: z.number().min(0, 'Display order must be 0 or greater'),
});

type SubjectFormData = z.infer<typeof subjectSchema>;

interface Subject {
  id: string;
  name: string;
  description: string | null;
  icon: string | null;
  is_premium: boolean;
  display_order: number;
}

interface SubjectFormProps {
  subject?: Subject;
  onSuccess: () => void;
  onCancel: () => void;
}

export const SubjectForm: React.FC<SubjectFormProps> = ({
  subject,
  onSuccess,
  onCancel,
}) => {
  const queryClient = useQueryClient();
  const isEditing = !!subject;

  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SubjectFormData>({
    resolver: zodResolver(subjectSchema),
    defaultValues: {
      name: subject?.name || '',
      description: subject?.description || '',
      icon: subject?.icon || '',
      is_premium: subject?.is_premium || false,
      display_order: subject?.display_order || 0,
    },
  });

  const mutation = useMutation({
    mutationFn: async (data: SubjectFormData) => {
      if (isEditing) {
        const { error } = await supabase
          .from('subjects')
          .update(data)
          .eq('id', subject.id);
        if (error) throw error;
      } else {
        const { error } = await supabase
          .from('subjects')
          .insert([data]);
        if (error) throw error;
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['subjects'] });
      onSuccess();
    },
    onError: (error) => {
      console.error('Error saving subject:', error);
      alert('Failed to save subject. Please try again.');
    },
  });

  const onSubmit = (data: SubjectFormData) => {
    mutation.mutate(data);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <Input
        {...register('name')}
        label="Subject Name"
        placeholder="Enter subject name"
        error={errors.name?.message}
      />

      <div>
        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
          Description
        </label>
        <textarea
          {...register('description')}
          rows={3}
          className="w-full px-3 py-2 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500 disabled:bg-gray-50 disabled:text-gray-500 dark:bg-gray-800 dark:border-gray-600 dark:text-white transition-colors duration-200"
          placeholder="Enter subject description (optional)"
        />
        {errors.description && (
          <p className="text-sm text-red-600 dark:text-red-400 mt-1">
            {errors.description.message}
          </p>
        )}
      </div>

      <Input
        {...register('icon')}
        label="Icon (Emoji)"
        placeholder="📚"
        error={errors.icon?.message}
        helperText="Use an emoji to represent this subject"
      />

      <Input
        {...register('display_order', { valueAsNumber: true })}
        type="number"
        label="Display Order"
        placeholder="0"
        error={errors.display_order?.message}
        helperText="Lower numbers appear first in the list"
      />

      <div className="flex items-center space-x-2">
        <input
          {...register('is_premium')}
          type="checkbox"
          id="is_premium"
          className="w-4 h-4 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
        />
        <label
          htmlFor="is_premium"
          className="text-sm font-medium text-gray-700 dark:text-gray-300"
        >
          Premium Subject
        </label>
      </div>

      <div className="flex justify-end space-x-3 pt-4">
        <Button
          type="button"
          variant="outline"
          onClick={onCancel}
          disabled={mutation.isPending}
        >
          Cancel
        </Button>
        <Button
          type="submit"
          loading={mutation.isPending}
          disabled={mutation.isPending}
        >
          {isEditing ? 'Update Subject' : 'Create Subject'}
        </Button>
      </div>
    </form>
  );
};