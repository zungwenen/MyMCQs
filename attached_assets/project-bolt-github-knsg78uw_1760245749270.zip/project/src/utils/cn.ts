// src/utils/cn.ts
import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge'; // Corrected import path

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
