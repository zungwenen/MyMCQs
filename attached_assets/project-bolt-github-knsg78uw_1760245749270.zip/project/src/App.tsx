import React, { useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { useAuth } from './hooks/useAuth';
import { useAppStore } from './store/appStore';
import { Layout } from './components/Layout';
import { Login } from './pages/auth/Login';
import { AdminLogin } from './pages/auth/AdminLogin';
import { Dashboard } from './pages/Dashboard';
import { AdminDashboard } from './pages/admin/AdminDashboard';
import { SubjectManagement } from './pages/admin/SubjectManagement';
import { QuizManagement } from './pages/admin/QuizManagement';
import { QuestionManagement } from './pages/admin/QuestionManagement';
import { Profile } from './pages/Profile';
import { Quizzes } from './pages/Quizzes';
import { QuizDetail } from './pages/QuizDetail';
import { QuizPlay } from './pages/QuizPlay';
import { QuizResult } from './pages/QuizResult';
import './index.css';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 1000 * 60 * 5,
      gcTime: 1000 * 60 * 10,
      retry: 1,
      refetchOnWindowFocus: false,
      refetchOnMount: true,
      refetchOnReconnect: false,
    },
  },
});

const AppContent: React.FC = () => {
  const { isAuthenticated, isAdmin, isLoading } = useAuth();
  const { theme, setTheme } = useAppStore();

  // Initialize theme
  useEffect(() => {
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const storedTheme = localStorage.getItem('app-storage');
    
    if (storedTheme) {
      const parsed = JSON.parse(storedTheme);
      if (parsed.state?.theme) {
        setTheme(parsed.state.theme);
        return;
      }
    }
    
    // Use system preference if no stored theme
    setTheme(mediaQuery.matches ? 'dark' : 'light');
    
    const handleChange = (e: MediaQueryListEvent) => {
      if (!localStorage.getItem('app-storage')) {
        setTheme(e.matches ? 'dark' : 'light');
      }
    };
    
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [setTheme]);

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-gray-600 dark:text-gray-400">Loading...</p>
        </div>
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/login" element={!isAuthenticated ? <Login /> : <Navigate to="/dashboard" replace />} />
      <Route path="/admin/login" element={!isAuthenticated ? <AdminLogin /> : <Navigate to="/admin/dashboard" replace />} />
      
      <Route path="/" element={<Layout />}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={isAuthenticated ? <Dashboard /> : <Navigate to="/login" replace />} />
        
        {/* Quiz Routes */}
        <Route 
          path="quizzes" 
          element={isAuthenticated ? <Quizzes /> : <Navigate to="/login" replace />} 
        />
        <Route 
          path="quizzes/:quizId" 
          element={isAuthenticated ? <QuizDetail /> : <Navigate to="/login" replace />} 
        />
        <Route 
          path="quizzes/:quizId/play" 
          element={isAuthenticated ? <QuizPlay /> : <Navigate to="/login" replace />} 
        />
        <Route 
          path="quizzes/:quizId/result/:attemptId" 
          element={isAuthenticated ? <QuizResult /> : <Navigate to="/login" replace />} 
        />
        
        {/* Profile Route */}
        <Route 
          path="profile" 
          element={isAuthenticated ? <Profile /> : <Navigate to="/login" replace />} 
        />
        
        {/* Admin Routes */}
        <Route 
          path="admin/dashboard" 
          element={
            isAuthenticated && isAdmin ? (
              <AdminDashboard />
            ) : (
              <Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />
            )
          } 
        />
        
        <Route 
          path="admin/subjects" 
          element={
            isAuthenticated && isAdmin ? (
              <SubjectManagement />
            ) : (
              <Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />
            )
          } 
        />
        
        <Route
          path="admin/quizzes"
          element={
            isAuthenticated && isAdmin ? (
              <QuizManagement />
            ) : (
              <Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />
            )
          }
        />

        <Route
          path="admin/questions"
          element={
            isAuthenticated && isAdmin ? (
              <QuestionManagement />
            ) : (
              <Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />
            )
          }
        />

        {/* Protected routes will be added here */}
        <Route path="*" element={<Navigate to={isAuthenticated ? "/dashboard" : "/login"} replace />} />
      </Route>
    </Routes>
  );
};

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Router>
        <AppContent />
      </Router>
      <ReactQueryDevtools initialIsOpen={false} />
    </QueryClientProvider>
  );
}

export default App;