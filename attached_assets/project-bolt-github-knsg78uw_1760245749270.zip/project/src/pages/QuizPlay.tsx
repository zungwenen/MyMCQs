import React, { useState, useEffect, useCallback } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useParams, useNavigate } from 'react-router-dom';
import { Clock, ChevronLeft, ChevronRight, Flag, AlertTriangle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { useAppStore } from '../store/appStore';
import { Card, CardContent, CardHeader } from '../components/ui/Card';
import { Button } from '../components/ui/Button';
import { Badge } from '../components/ui/Badge';
import { Modal } from '../components/ui/Modal';

interface Question {
  id: string;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_answer: 'A' | 'B' | 'C' | 'D';
  explanation: string | null;
  points: number;
  display_order: number | null;
}

interface QuizWithQuestions {
  id: string;
  title: string;
  time_limit_minutes: number | null;
  passing_score: number;
  question_randomize: boolean;
  total_questions: number;
  questions: Question[];
}

export const QuizPlay: React.FC = () => {
  const { quizId } = useParams<{ quizId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { setCurrentQuiz, setQuizTimer, setQuizStartTime, resetQuizState } = useAppStore();

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [answers, setAnswers] = useState<Record<string, 'A' | 'B' | 'C' | 'D'>>({});
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [quizStarted, setQuizStarted] = useState(false);
  const [questionFeedback, setQuestionFeedback] = useState<Record<string, { isCorrect: boolean; shown: boolean }>>({});

  // Fetch quiz and questions
  const { data: quiz, isLoading, error } = useQuery({
    queryKey: ['quiz-play', quizId],
    queryFn: async () => {
      if (!quizId) throw new Error('Quiz ID is required');
      
      const { data, error } = await supabase
        .from('quizzes')
        .select(`
          *,
          questions (*)
        `)
        .eq('id', quizId)
        .eq('is_active', true)
        .single();
      
      if (error) throw error;
      
      const quiz = data as QuizWithQuestions;
      
      // Randomize questions if enabled
      if (quiz.question_randomize) {
        quiz.questions = [...quiz.questions].sort(() => Math.random() - 0.5);
      } else {
        quiz.questions = quiz.questions.sort((a, b) => (a.display_order || 0) - (b.display_order || 0));
      }
      
      return quiz;
    },
    enabled: !!quizId,
  });

  // Submit quiz mutation
  const submitQuizMutation = useMutation({
    mutationFn: async () => {
      if (!quiz || !user) throw new Error('Missing required data');

      const score = Object.entries(answers).reduce((total, [questionId, answer]) => {
        const question = quiz.questions.find(q => q.id === questionId);
        return total + (question?.correct_answer === answer ? question.points : 0);
      }, 0);

      const totalPossiblePoints = quiz.questions.reduce((total, q) => total + q.points, 0);
      const percentage = (score / totalPossiblePoints) * 100;
      const passed = percentage >= quiz.passing_score;

      const timeTaken = quiz.time_limit_minutes 
        ? quiz.time_limit_minutes - Math.floor((timeRemaining || 0) / 60)
        : null;

      const { data, error } = await supabase
        .from('user_quiz_attempts')
        .insert({
          user_id: user.id,
          quiz_id: quiz.id,
          score,
          total_questions: quiz.questions.length,
          time_taken_minutes: timeTaken,
          answers,
          passed,
          completed_at: new Date().toISOString(),
        })
        .select()
        .single();

      if (error) throw error;
      return data;
    },
    onSuccess: (attempt) => {
      resetQuizState();
      navigate(`/quizzes/${quizId}/result/${attempt.id}`);
    },
    onError: (error) => {
      console.error('Error submitting quiz:', error);
      alert('Failed to submit quiz. Please try again.');
      setIsSubmitting(false);
    },
  });

  // Initialize quiz
  useEffect(() => {
    if (quiz && !quizStarted) {
      setCurrentQuiz(quiz);
      setQuizStartTime(new Date());
      
      if (quiz.time_limit_minutes) {
        const totalSeconds = quiz.time_limit_minutes * 60;
        setTimeRemaining(totalSeconds);
        setQuizTimer(totalSeconds);
      }
      
      setQuizStarted(true);
    }
  }, [quiz, quizStarted, setCurrentQuiz, setQuizStartTime, setQuizTimer]);

  // Timer countdown
  useEffect(() => {
    if (timeRemaining === null || timeRemaining <= 0) return;

    const timer = setInterval(() => {
      setTimeRemaining(prev => {
        if (prev === null || prev <= 1) {
          // Auto-submit when time runs out
          handleSubmitQuiz();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [timeRemaining]);

  const handleAnswerSelect = (questionId: string, answer: 'A' | 'B' | 'C' | 'D') => {
    setAnswers(prev => ({
      ...prev,
      [questionId]: answer,
    }));

    // Show instant feedback if enabled
    if (quiz?.instant_feedback && !questionFeedback[questionId]?.shown) {
      const question = quiz.questions.find(q => q.id === questionId);
      if (question) {
        const isCorrect = question.correct_answer === answer;
        setQuestionFeedback(prev => ({
          ...prev,
          [questionId]: { isCorrect, shown: true }
        }));
      }
    }
  };

  const handleNextQuestion = () => {
    if (quiz && currentQuestionIndex < quiz.questions.length - 1) {
      setCurrentQuestionIndex(prev => prev + 1);
    }
  };

  const handlePreviousQuestion = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1);
    }
  };

  const handleSubmitQuiz = useCallback(() => {
    setIsSubmitting(true);
    submitQuizMutation.mutate();
  }, [submitQuizMutation]);

  const formatTime = (seconds: number) => {
    const minutes = Math.floor(seconds / 60);
    const remainingSeconds = seconds % 60;
    return `${minutes}:${remainingSeconds.toString().padStart(2, '0')}`;
  };

  const getAnsweredCount = () => {
    return Object.keys(answers).length;
  };

  const isTimeRunningOut = timeRemaining !== null && timeRemaining < 300; // Less than 5 minutes

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error || !quiz) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600 dark:text-red-400">
          Quiz not found or error loading quiz.
        </p>
        <Button onClick={() => navigate('/quizzes')} className="mt-4">
          Back to Quizzes
        </Button>
      </div>
    );
  }

  const currentQuestion = quiz.questions[currentQuestionIndex];
  const progress = ((currentQuestionIndex + 1) / quiz.questions.length) * 100;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Quiz Header */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-xl font-bold text-gray-900 dark:text-white">
                {quiz.title}
              </h1>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Question {currentQuestionIndex + 1} of {quiz.questions.length}
              </p>
            </div>
            
            <div className="flex items-center space-x-4">
              {timeRemaining !== null && (
                <div className={`flex items-center space-x-2 px-3 py-1 rounded-lg ${
                  isTimeRunningOut 
                    ? 'bg-red-100 text-red-800 dark:bg-red-900/30 dark:text-red-400' 
                    : 'bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-400'
                }`}>
                  <Clock className="w-4 h-4" />
                  <span className="font-mono font-semibold">
                    {formatTime(timeRemaining)}
                  </span>
                </div>
              )}
              
              <Badge variant="info">
                {getAnsweredCount()}/{quiz.questions.length} answered
              </Badge>
            </div>
          </div>
          
          {/* Progress Bar */}
          <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2 mt-4">
            <div 
              className="bg-blue-600 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            />
          </div>
        </CardHeader>
      </Card>

      {/* Question Card */}
      <Card>
        <CardHeader>
          <h2 className="text-lg font-semibold text-gray-900 dark:text-white">
            {currentQuestion.question_text}
          </h2>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {(['A', 'B', 'C', 'D'] as const).map((option) => {
              const optionText = currentQuestion[`option_${option.toLowerCase()}` as keyof Question] as string;
              const isSelected = answers[currentQuestion.id] === option;
              const feedback = questionFeedback[currentQuestion.id];
              const showFeedback = feedback?.shown && quiz?.instant_feedback;
              const isCorrectAnswer = currentQuestion.correct_answer === option;
              const isWrongSelection = showFeedback && isSelected && !feedback.isCorrect;
              const shouldHighlightCorrect = showFeedback && isCorrectAnswer;
              
              return (
                <button
                  key={option}
                  onClick={() => handleAnswerSelect(currentQuestion.id, option)}
                  disabled={showFeedback}
                  className={`w-full p-4 text-left rounded-lg border-2 transition-all ${
                    isSelected
                      ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30'
                     : shouldHighlightCorrect
                     ? 'border-green-500 bg-green-50 dark:bg-green-900/30'
                     : isWrongSelection
                     ? 'border-red-500 bg-red-50 dark:bg-red-900/30'
                      : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                  } ${showFeedback ? 'cursor-not-allowed' : 'cursor-pointer'}`}
                >
                  <div className="flex items-start space-x-3">
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center text-sm font-semibold ${
                      isSelected
                        ? 'border-blue-500 bg-blue-500 text-white'
                        : shouldHighlightCorrect
                        ? 'border-green-500 bg-green-500 text-white'
                        : isWrongSelection
                        ? 'border-red-500 bg-red-500 text-white'
                        : 'border-gray-300 dark:border-gray-600'
                    }`}>
                      {option}
                    </div>
                    <span className="text-gray-900 dark:text-white">
                      {optionText}
                    </span>
                    {showFeedback && isCorrectAnswer && (
                      <span className="ml-auto text-green-600 dark:text-green-400 text-sm font-medium">
                        ✓ Correct
                      </span>
                    )}
                    {showFeedback && isWrongSelection && (
                      <span className="ml-auto text-red-600 dark:text-red-400 text-sm font-medium">
                        ✗ Wrong
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
          </div>

          {/* Instant Feedback Message */}
          {quiz?.instant_feedback && questionFeedback[currentQuestion.id]?.shown && (
            <div className={`mt-4 p-3 rounded-lg border ${
              questionFeedback[currentQuestion.id].isCorrect
                ? 'border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20'
                : 'border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20'
            }`}>
              <p className={`text-sm font-medium ${
                questionFeedback[currentQuestion.id].isCorrect
                  ? 'text-green-800 dark:text-green-400'
                  : 'text-red-800 dark:text-red-400'
              }`}>
                {questionFeedback[currentQuestion.id].isCorrect ? '✓ Correct!' : '✗ Incorrect'}
              </p>
              {currentQuestion.explanation && (
                <p className="text-sm text-gray-700 dark:text-gray-300 mt-1">
                  <strong>Explanation:</strong> {currentQuestion.explanation}
                </p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Navigation */}
      <div className="flex items-center justify-between">
        <Button
          variant="outline"
          onClick={handlePreviousQuestion}
          disabled={currentQuestionIndex === 0}
        >
          <ChevronLeft className="w-4 h-4 mr-2" />
          Previous
        </Button>

        <div className="flex items-center space-x-3">
          {currentQuestionIndex === quiz.questions.length - 1 ? (
            <Button
              onClick={() => setShowSubmitModal(true)}
              disabled={isSubmitting}
              className="bg-green-600 hover:bg-green-700"
            >
              <Flag className="w-4 h-4 mr-2" />
              Submit Quiz
            </Button>
          ) : (
            <Button
              onClick={handleNextQuestion}
              disabled={currentQuestionIndex === quiz.questions.length - 1}
            >
              Next
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          )}
        </div>
      </div>

      {/* Submit Confirmation Modal */}
      <Modal
        isOpen={showSubmitModal}
        onClose={() => setShowSubmitModal(false)}
        title="Submit Quiz"
      >
        <div className="space-y-4">
          <div className="flex items-start space-x-3">
            <AlertTriangle className="w-6 h-6 text-amber-500 mt-1" />
            <div>
              <p className="text-gray-900 dark:text-white">
                Are you sure you want to submit your quiz?
              </p>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                You have answered {getAnsweredCount()} out of {quiz.questions.length} questions.
                {getAnsweredCount() < quiz.questions.length && (
                  <span className="text-amber-600 dark:text-amber-400">
                    {' '}Unanswered questions will be marked as incorrect.
                  </span>
                )}
              </p>
            </div>
          </div>

          <div className="flex justify-end space-x-3 pt-4">
            <Button
              variant="outline"
              onClick={() => setShowSubmitModal(false)}
              disabled={isSubmitting}
            >
              Continue Quiz
            </Button>
            <Button
              onClick={handleSubmitQuiz}
              loading={isSubmitting}
              disabled={isSubmitting}
              className="bg-green-600 hover:bg-green-700"
            >
              Submit Quiz
            </Button>
          </div>
        </div>
      </Modal>
    </div>
  );
};