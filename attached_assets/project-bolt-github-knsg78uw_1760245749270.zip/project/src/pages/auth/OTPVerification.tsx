import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, MessageCircle, MessageSquare, RefreshCw } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Card, CardContent, CardHeader } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';

interface OTPVerificationProps {
  phoneNumber: string;
  deliveryMethod: string;
  onBack: () => void;
}

export const OTPVerification: React.FC<OTPVerificationProps> = ({
  phoneNumber,
  deliveryMethod,
  onBack,
}) => {
  const [otp, setOtp] = useState(['', '', '', '', '', '']);
  const [loading, setLoading] = useState(false);
  const [resendLoading, setResendLoading] = useState(false);
  const [countdown, setCountdown] = useState(600);
  const [error, setError] = useState('');
  const [expiryTime, setExpiryTime] = useState<number>(Date.now() + 600000);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    if (countdown > 0) {
      const timer = setTimeout(() => {
        const remaining = Math.max(0, Math.floor((expiryTime - Date.now()) / 1000));
        setCountdown(remaining);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [countdown, expiryTime]);

  useEffect(() => {
    if (countdown === 0) {
      setError('Verification code has expired. Please request a new one.');
    }
  }, [countdown]);

  const handleOtpChange = (index: number, value: string) => {
    if (value.length > 1) return;

    const newOtp = [...otp];
    newOtp[index] = value;
    setOtp(newOtp);
    setError('');

    // Auto-focus next input
    if (value && index < 5) {
      inputRefs.current[index + 1]?.focus();
    }

    // Auto-submit when all fields are filled
    if (newOtp.every(digit => digit !== '') && newOtp.join('').length === 6) {
      handleVerify(newOtp.join(''));
    }
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !otp[index] && index > 0) {
      inputRefs.current[index - 1]?.focus();
    }
  };

  const handleVerify = async (otpCode = otp.join('')) => {
    if (otpCode.length !== 6) return;

    if (countdown === 0) {
      setError('Verification code has expired. Please request a new one.');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase.auth.verifyOtp({
        phone: phoneNumber,
        token: otpCode,
        type: 'sms',
      });

      if (error) {
        if (error.message.includes('expired') || error.message.includes('invalid')) {
          throw new Error('Verification code has expired or is invalid. Please request a new code.');
        }
        throw error;
      }

      if (data.user) {
        const { error: profileError } = await supabase
          .from('profiles')
          .upsert({
            user_id: data.user.id,
            phone_number: phoneNumber,
            phone_verified: true,
          }, {
            onConflict: 'user_id',
          });

        if (profileError) {
          console.error('Error creating profile:', profileError);
        }

        navigate('/dashboard');
      }
    } catch (error: any) {
      console.error('Verification error:', error);
      if (error.message.includes('expired')) {
        setError('Verification code has expired. Please request a new one.');
        setCountdown(0);
      } else {
        setError(error.message || 'Invalid verification code. Please try again.');
      }
      setOtp(['', '', '', '', '', '']);
      inputRefs.current[0]?.focus();
    } finally {
      setLoading(false);
    }
  };

  const handleResend = async () => {
    setResendLoading(true);
    setError('');
    try {
      const newOtp = Math.floor(100000 + Math.random() * 900000).toString();

      const { data: otpResponse, error: functionError } = await supabase.functions.invoke('send-otp', {
        body: {
          phoneNumber,
          otp: newOtp,
        },
      });

      if (functionError) throw functionError;

      if (otpResponse?.success) {
        const newExpiryTime = Date.now() + 600000;
        setExpiryTime(newExpiryTime);
        setCountdown(600);
        setError('');
        setOtp(['', '', '', '', '', '']);
        inputRefs.current[0]?.focus();

        const { error: authError } = await supabase.auth.signInWithOtp({
          phone: phoneNumber,
          options: {
            data: {
              custom_otp: newOtp,
            },
          },
        });

        if (authError) {
          console.error('Auth error during resend:', authError);
        }

        alert(`New verification code sent via ${otpResponse.deliveryMethod.toUpperCase()}`);
      } else {
        throw new Error('Failed to send OTP');
      }
    } catch (error: any) {
      console.error('Resend error:', error);
      setError(error.message || 'Failed to resend code. Please try again.');
    } finally {
      setResendLoading(false);
    }
  };

  const DeliveryIcon = deliveryMethod === 'whatsapp' ? MessageCircle : MessageSquare;

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800 px-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="mx-auto w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mb-4">
            <DeliveryIcon className="w-8 h-8 text-white" />
          </div>
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white">
            Verify Your Number
          </h2>
          <p className="mt-2 text-gray-600 dark:text-gray-400">
            We sent a 6-digit code to {phoneNumber} via {deliveryMethod.toUpperCase()}
          </p>
          {countdown > 0 && countdown < 120 && (
            <p className="mt-1 text-sm text-amber-600 dark:text-amber-400">
              Code expires in {Math.floor(countdown / 60)}:{String(countdown % 60).padStart(2, '0')}
            </p>
          )}
        </div>

        <Card>
          <CardHeader>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Enter Verification Code
            </h3>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex justify-center space-x-2">
                {otp.map((digit, index) => (
                  <input
                    key={index}
                    ref={el => inputRefs.current[index] = el}
                    type="text"
                    inputMode="numeric"
                    maxLength={1}
                    value={digit}
                    onChange={e => handleOtpChange(index, e.target.value)}
                    onKeyDown={e => handleKeyDown(index, e)}
                    className="w-12 h-12 text-center text-lg font-bold border-2 border-gray-300 rounded-lg focus:border-blue-500 focus:outline-none transition-colors"
                    disabled={loading}
                  />
                ))}
              </div>

              {error && (
                <p className="text-sm text-red-600 text-center">{error}</p>
              )}

              <div className="flex flex-col space-y-3">
                <Button
                  onClick={() => handleVerify()}
                  loading={loading}
                  disabled={otp.some(digit => !digit) || loading}
                  className="w-full"
                >
                  Verify Code
                </Button>

                <div className="flex items-center justify-between">
                  <Button
                    variant="ghost"
                    onClick={onBack}
                    disabled={loading}
                  >
                    <ArrowLeft className="w-4 h-4 mr-2" />
                    Back
                  </Button>

                  <Button
                    variant="ghost"
                    onClick={handleResend}
                    disabled={resendLoading}
                    loading={resendLoading}
                  >
                    <RefreshCw className="w-4 h-4 mr-2" />
                    Resend Code
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};