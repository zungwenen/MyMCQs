import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import {
  Users,
  BookOpen,
  CreditCard,
  TrendingUp,
  Activity,
  DollarSign,
  Award,
} from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Card, CardContent, CardHeader } from '../../components/ui/Card';
import { Badge } from '../../components/ui/Badge';

export const AdminDashboard: React.FC = () => {
  const { data: stats, isLoading } = useQuery({
    queryKey: ['admin-dashboard-stats'],
    queryFn: async () => {
      const [
        usersResult,
        quizzesResult,
        attemptsResult,
        paymentsResult,
        subjectsResult
      ] = await Promise.all([
        supabase.from('profiles').select('id, created_at, is_premium'),
        supabase.from('quizzes').select('id, is_premium, is_active, total_questions'),
        supabase.from('user_quiz_attempts').select('id, score, total_questions, passed, created_at'),
        supabase.from('payments').select('amount_naira, payment_status, created_at').eq('payment_status', 'success'),
        supabase.from('subjects').select('id, name, is_premium')
      ]);

      const users = usersResult.data || [];
      const quizzes = quizzesResult.data || [];
      const attempts = attemptsResult.data || [];
      const payments = paymentsResult.data || [];
      const subjects = subjectsResult.data || [];

      const totalRevenue = payments.reduce((sum, payment) => sum + payment.amount_naira, 0);
      const averageScore = attempts.length > 0
        ? attempts.reduce((sum, attempt) => sum + (attempt.score / attempt.total_questions) * 100, 0) / attempts.length
        : 0;
      const passRate = attempts.length > 0
        ? (attempts.filter(attempt => attempt.passed).length / attempts.length) * 100
        : 0;

      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

      const recentUsers = users.filter(user => new Date(user.created_at) >= sevenDaysAgo).length;
      const recentAttempts = attempts.filter(attempt => new Date(attempt.created_at) >= sevenDaysAgo).length;
      const recentPayments = payments.filter(payment => new Date(payment.created_at) >= sevenDaysAgo);
      const recentRevenue = recentPayments.reduce((sum, payment) => sum + payment.amount_naira, 0);

      return {
        totalUsers: users.length,
        premiumUsers: users.filter(user => user.is_premium).length,
        totalQuizzes: quizzes.length,
        activeQuizzes: quizzes.filter(quiz => quiz.is_active).length,
        premiumQuizzes: quizzes.filter(quiz => quiz.is_premium).length,
        totalSubjects: subjects.length,
        totalAttempts: attempts.length,
        totalRevenue,
        averageScore: Math.round(averageScore),
        passRate: Math.round(passRate),
        recentUsers,
        recentAttempts,
        recentRevenue,
        recentPayments: recentPayments.length
      };
    },
    staleTime: 60000,
    refetchOnWindowFocus: false,
  });

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
          <p className="mt-4 text-sm text-gray-600 dark:text-gray-400">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 sm:space-y-8">
      {/* Header */}
      <div>
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 dark:text-white">
          Admin Dashboard
        </h1>
        <p className="mt-2 text-sm sm:text-base text-gray-600 dark:text-gray-300">
          Overview of your QuizMaster platform
        </p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 sm:gap-6">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-300">
                  Total Users
                </p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                  {stats?.totalUsers || 0}
                </p>
                <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                  +{stats?.recentUsers || 0} this week
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/40 rounded-full flex items-center justify-center flex-shrink-0">
                <Users className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-300">
                  Total Revenue
                </p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                  ₦{stats?.totalRevenue.toLocaleString() || 0}
                </p>
                <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                  +₦{stats?.recentRevenue.toLocaleString() || 0} this week
                </p>
              </div>
              <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/40 rounded-full flex items-center justify-center flex-shrink-0">
                <DollarSign className="w-6 h-6 text-emerald-600 dark:text-emerald-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-300">
                  Quiz Attempts
                </p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                  {stats?.totalAttempts || 0}
                </p>
                <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                  +{stats?.recentAttempts || 0} this week
                </p>
              </div>
              <div className="w-12 h-12 bg-amber-100 dark:bg-amber-900/40 rounded-full flex items-center justify-center flex-shrink-0">
                <Activity className="w-6 h-6 text-amber-600 dark:text-amber-400" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600 dark:text-gray-300">
                  Average Score
                </p>
                <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                  {stats?.averageScore || 0}%
                </p>
                <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                  {stats?.passRate || 0}% pass rate
                </p>
              </div>
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900/40 rounded-full flex items-center justify-center flex-shrink-0">
                <Award className="w-6 h-6 text-blue-600 dark:text-blue-400" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Content Overview */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
        <Card>
          <CardHeader>
            <h2 className="text-lg sm:text-xl font-semibold text-gray-900 dark:text-white">
              Content Overview
            </h2>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 sm:space-y-4">
              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <BookOpen className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                  <span className="font-medium text-gray-900 dark:text-white text-sm sm:text-base">
                    Total Subjects
                  </span>
                </div>
                <Badge variant="info">{stats?.totalSubjects || 0}</Badge>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <BookOpen className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                  <span className="font-medium text-gray-900 dark:text-white text-sm sm:text-base">
                    Active Quizzes
                  </span>
                </div>
                <Badge variant="success">{stats?.activeQuizzes || 0}</Badge>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <BookOpen className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0" />
                  <span className="font-medium text-gray-900 dark:text-white text-sm sm:text-base">
                    Premium Quizzes
                  </span>
                </div>
                <Badge variant="premium">{stats?.premiumQuizzes || 0}</Badge>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Users className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                  <span className="font-medium text-gray-900 dark:text-white text-sm sm:text-base">
                    Premium Users
                  </span>
                </div>
                <Badge variant="premium">{stats?.premiumUsers || 0}</Badge>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <h2 className="text-lg sm:text-xl font-semibold text-gray-900 dark:text-white">
              Recent Activity
            </h2>
            <p className="text-sm text-gray-600 dark:text-gray-300">
              Last 7 days
            </p>
          </CardHeader>
          <CardContent>
            <div className="space-y-3 sm:space-y-4">
              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Users className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                  <span className="font-medium text-gray-900 dark:text-white text-sm sm:text-base">
                    New Users
                  </span>
                </div>
                <span className="text-lg font-bold text-gray-900 dark:text-white">
                  {stats?.recentUsers || 0}
                </span>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <Activity className="w-5 h-5 text-emerald-600 dark:text-emerald-400 flex-shrink-0" />
                  <span className="font-medium text-gray-900 dark:text-white text-sm sm:text-base">
                    Quiz Attempts
                  </span>
                </div>
                <span className="text-lg font-bold text-gray-900 dark:text-white">
                  {stats?.recentAttempts || 0}
                </span>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <CreditCard className="w-5 h-5 text-amber-600 dark:text-amber-400 flex-shrink-0" />
                  <span className="font-medium text-gray-900 dark:text-white text-sm sm:text-base">
                    Payments
                  </span>
                </div>
                <span className="text-lg font-bold text-gray-900 dark:text-white">
                  {stats?.recentPayments || 0}
                </span>
              </div>

              <div className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700/50 rounded-lg">
                <div className="flex items-center space-x-3">
                  <TrendingUp className="w-5 h-5 text-blue-600 dark:text-blue-400 flex-shrink-0" />
                  <span className="font-medium text-gray-900 dark:text-white text-sm sm:text-base">
                    Revenue
                  </span>
                </div>
                <span className="text-lg font-bold text-gray-900 dark:text-white">
                  ₦{stats?.recentRevenue.toLocaleString() || 0}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <h2 className="text-lg sm:text-xl font-semibold text-gray-900 dark:text-white">
            Quick Actions
          </h2>
          <p className="text-sm text-gray-600 dark:text-gray-300">
            Common administrative tasks
          </p>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Link
              to="/admin/subjects"
              className="p-4 text-left border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors block group"
            >
              <BookOpen className="w-8 h-8 text-blue-600 dark:text-blue-400 mb-2 group-hover:scale-110 transition-transform" />
              <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                Manage Subjects
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Create and edit subjects
              </p>
            </Link>

            <Link
              to="/admin/quizzes"
              className="p-4 text-left border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors block group"
            >
              <BookOpen className="w-8 h-8 text-emerald-600 dark:text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
              <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                Manage Quizzes
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Create and configure quizzes
              </p>
            </Link>

            <Link
              to="/admin/questions"
              className="p-4 text-left border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors block group"
            >
              <BookOpen className="w-8 h-8 text-blue-600 dark:text-blue-400 mb-2 group-hover:scale-110 transition-transform" />
              <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                Manage Questions
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Add and edit quiz questions
              </p>
            </Link>

            <button className="p-4 text-left border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors group">
              <Users className="w-8 h-8 text-emerald-600 dark:text-emerald-400 mb-2 group-hover:scale-110 transition-transform" />
              <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                User Management
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                View and manage users
              </p>
            </button>

            <button className="p-4 text-left border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors group">
              <TrendingUp className="w-8 h-8 text-amber-600 dark:text-amber-400 mb-2 group-hover:scale-110 transition-transform" />
              <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                Analytics
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                View detailed reports
              </p>
            </button>

            <button className="p-4 text-left border border-gray-200 dark:border-gray-600 rounded-lg hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors group">
              <CreditCard className="w-8 h-8 text-blue-600 dark:text-blue-400 mb-2 group-hover:scale-110 transition-transform" />
              <h3 className="font-medium text-gray-900 dark:text-white mb-1">
                Payments
              </h3>
              <p className="text-sm text-gray-600 dark:text-gray-300">
                Monitor transactions
              </p>
            </button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
