import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Plus, Edit, Trash2, BookOpen, Check, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { Card, CardContent, CardHeader } from '../../components/ui/Card';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Modal } from '../../components/ui/Modal';
import { QuestionForm } from '../../components/admin/QuestionForm';

interface Question {
  id: string;
  quiz_id: string;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_answer: 'A' | 'B' | 'C' | 'D';
  explanation: string | null;
  points: number;
  display_order: number | null;
  created_at: string;
}

interface Quiz {
  id: string;
  title: string;
  subjects: {
    name: string;
  } | null;
}

export const QuestionManagement: React.FC = () => {
  const [selectedQuizId, setSelectedQuizId] = useState<string | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingQuestion, setEditingQuestion] = useState<Question | null>(null);
  const queryClient = useQueryClient();

  const { data: quizzes, isLoading: quizzesLoading } = useQuery({
    queryKey: ['admin-quizzes-list'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('quizzes')
        .select(`
          id,
          title,
          subjects (
            name
          )
        `)
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data as Quiz[];
    },
  });

  const { data: questions, isLoading: questionsLoading } = useQuery({
    queryKey: ['admin-questions', selectedQuizId],
    queryFn: async () => {
      if (!selectedQuizId) return [];

      const { data, error } = await supabase
        .from('questions')
        .select('*')
        .eq('quiz_id', selectedQuizId)
        .order('display_order', { ascending: true });

      if (error) throw error;
      return data as Question[];
    },
    enabled: !!selectedQuizId,
  });

  const deleteMutation = useMutation({
    mutationFn: async (questionId: string) => {
      const { error } = await supabase
        .from('questions')
        .delete()
        .eq('id', questionId);

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-questions', selectedQuizId] });
      queryClient.invalidateQueries({ queryKey: ['admin-quizzes'] });
    },
    onError: (error) => {
      console.error('Error deleting question:', error);
      alert('Failed to delete question. Please try again.');
    },
  });

  const handleAddQuestion = () => {
    if (!selectedQuizId) {
      alert('Please select a quiz first');
      return;
    }
    setEditingQuestion(null);
    setIsModalOpen(true);
  };

  const handleEditQuestion = (question: Question) => {
    setEditingQuestion(question);
    setIsModalOpen(true);
  };

  const handleDeleteQuestion = (question: Question) => {
    if (window.confirm(`Are you sure you want to delete this question? This action cannot be undone.`)) {
      deleteMutation.mutate(question.id);
    }
  };

  const handleModalClose = () => {
    setIsModalOpen(false);
    setEditingQuestion(null);
  };

  const selectedQuiz = quizzes?.find(q => q.id === selectedQuizId);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
            Question Management
          </h1>
          <p className="text-gray-600 dark:text-gray-400">
            Add and manage quiz questions
          </p>
        </div>
        {selectedQuizId && (
          <Button onClick={handleAddQuestion}>
            <Plus className="w-4 h-4 mr-2" />
            Add Question
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
              Select Quiz
            </h3>
          </CardHeader>
          <CardContent>
            {quizzesLoading ? (
              <div className="text-center py-4">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
              </div>
            ) : quizzes && quizzes.length > 0 ? (
              <div className="space-y-2">
                {quizzes.map((quiz) => (
                  <button
                    key={quiz.id}
                    onClick={() => setSelectedQuizId(quiz.id)}
                    className={`w-full p-3 text-left rounded-lg border transition-colors ${
                      selectedQuizId === quiz.id
                        ? 'border-blue-500 bg-blue-50 dark:bg-blue-900/30'
                        : 'border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600'
                    }`}
                  >
                    <p className="font-medium text-sm text-gray-900 dark:text-white">
                      {quiz.title}
                    </p>
                    <p className="text-xs text-gray-600 dark:text-gray-400 mt-1">
                      {quiz.subjects?.name}
                    </p>
                  </button>
                ))}
              </div>
            ) : (
              <p className="text-sm text-gray-600 dark:text-gray-400 text-center py-4">
                No quizzes available
              </p>
            )}
          </CardContent>
        </Card>

        <div className="lg:col-span-3">
          {!selectedQuizId ? (
            <Card>
              <CardContent className="text-center py-12">
                <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                  Select a quiz to manage questions
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  Choose a quiz from the list to view and edit its questions
                </p>
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                      {selectedQuiz?.title}
                    </h3>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {questions?.length || 0} questions
                    </p>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                {questionsLoading ? (
                  <div className="text-center py-12">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
                  </div>
                ) : questions && questions.length > 0 ? (
                  <div className="space-y-4">
                    {questions.map((question, index) => (
                      <div
                        key={question.id}
                        className="p-4 border border-gray-200 dark:border-gray-700 rounded-lg hover:border-gray-300 dark:hover:border-gray-600 transition-colors"
                      >
                        <div className="flex items-start justify-between mb-3">
                          <div className="flex-1">
                            <div className="flex items-center space-x-2 mb-2">
                              <Badge variant="info">Question {index + 1}</Badge>
                              <Badge variant="success">{question.points} pts</Badge>
                            </div>
                            <p className="text-gray-900 dark:text-white font-medium">
                              {question.question_text}
                            </p>
                          </div>
                          <div className="flex space-x-1 ml-4">
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleEditQuestion(question)}
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="sm"
                              onClick={() => handleDeleteQuestion(question)}
                              disabled={deleteMutation.isPending}
                            >
                              <Trash2 className="w-4 h-4 text-red-500" />
                            </Button>
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-2 text-sm">
                          {(['A', 'B', 'C', 'D'] as const).map((option) => {
                            const optionText = question[`option_${option.toLowerCase()}` as keyof Question] as string;
                            const isCorrect = question.correct_answer === option;
                            return (
                              <div
                                key={option}
                                className={`p-2 rounded border ${
                                  isCorrect
                                    ? 'border-green-500 bg-green-50 dark:bg-green-900/20'
                                    : 'border-gray-200 dark:border-gray-700'
                                }`}
                              >
                                <div className="flex items-start space-x-2">
                                  <span className="font-semibold">{option}.</span>
                                  <span className="flex-1">{optionText}</span>
                                  {isCorrect && (
                                    <Check className="w-4 h-4 text-green-600 flex-shrink-0" />
                                  )}
                                </div>
                              </div>
                            );
                          })}
                        </div>

                        {question.explanation && (
                          <div className="mt-3 p-2 bg-blue-50 dark:bg-blue-900/20 rounded text-sm">
                            <span className="font-medium text-blue-900 dark:text-blue-400">
                              Explanation:
                            </span>{' '}
                            <span className="text-blue-800 dark:text-blue-300">
                              {question.explanation}
                            </span>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
                      No questions yet
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400 mb-4">
                      Get started by creating your first question
                    </p>
                    <Button onClick={handleAddQuestion}>
                      <Plus className="w-4 h-4 mr-2" />
                      Add Question
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <Modal
        isOpen={isModalOpen}
        onClose={handleModalClose}
        title={editingQuestion ? 'Edit Question' : 'Add New Question'}
        size="lg"
      >
        <QuestionForm
          quizId={selectedQuizId || ''}
          question={editingQuestion}
          onSuccess={handleModalClose}
          onCancel={handleModalClose}
        />
      </Modal>
    </div>
  );
};
