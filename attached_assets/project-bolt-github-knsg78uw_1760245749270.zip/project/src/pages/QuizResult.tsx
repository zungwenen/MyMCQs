import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { useParams, Link } from 'react-router-dom';
import { Trophy, Clock, BookOpen, CheckCircle, XCircle, Star, RotateCcw, Home } from 'lucide-react';
import Confetti from 'react-confetti';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { Card, CardContent, CardHeader } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';

interface QuizAttemptWithDetails {
  id: string;
  score: number;
  total_questions: number;
  time_taken_minutes: number | null;
  answers: Record<string, 'A' | 'B' | 'C' | 'D'>;
  passed: boolean;
  created_at: string;
  quizzes: {
    id: string;
    title: string;
    passing_score: number;
    subjects: {
      name: string;
      icon: string | null;
    } | null;
    questions: Array<{
      id: string;
      question_text: string;
      option_a: string;
      option_b: string;
      option_c: string;
      option_d: string;
      correct_answer: 'A' | 'B' | 'C' | 'D';
      explanation: string | null;
      points: number;
    }>;
  };
}

export const QuizResult: React.FC = () => {
  const { quizId, attemptId } = useParams<{ quizId: string; attemptId: string }>();
  const { user } = useAuth();

  // Fetch quiz attempt details
  const { data: attempt, isLoading, error } = useQuery({
    queryKey: ['quiz-result', attemptId],
    queryFn: async () => {
      if (!attemptId || !user) throw new Error('Missing required parameters');
      
      const { data, error } = await supabase
        .from('user_quiz_attempts')
        .select(`
          *,
          quizzes (
            id,
            title,
            passing_score,
            subjects (
              name,
              icon
            ),
            questions (
              id,
              question_text,
              option_a,
              option_b,
              option_c,
              option_d,
              correct_answer,
              explanation,
              points
            )
          )
        `)
        .eq('id', attemptId)
        .eq('user_id', user.id)
        .single();
      
      if (error) throw error;
      return data as QuizAttemptWithDetails;
    },
    enabled: !!attemptId && !!user,
  });

  const getScorePercentage = () => {
    if (!attempt) return 0;
    const totalPoints = attempt.quizzes.questions.reduce((sum, q) => sum + q.points, 0);
    return Math.round((attempt.score / totalPoints) * 100);
  };

  const getScoreColor = () => {
    const percentage = getScorePercentage();
    if (percentage >= 80) return 'text-green-600 dark:text-green-400';
    if (percentage >= 60) return 'text-amber-600 dark:text-amber-400';
    return 'text-red-600 dark:text-red-400';
  };

  const getAnswerDetails = () => {
    if (!attempt) return [];
    
    return attempt.quizzes.questions.map(question => {
      const userAnswer = attempt.answers[question.id];
      const isCorrect = userAnswer === question.correct_answer;
      
      return {
        question,
        userAnswer,
        isCorrect,
        wasAnswered: !!userAnswer,
      };
    });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error || !attempt) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600 dark:text-red-400">
          Quiz result not found or error loading results.
        </p>
        <Button asChild className="mt-4">
          <Link to="/quizzes">Back to Quizzes</Link>
        </Button>
      </div>
    );
  }

  const scorePercentage = getScorePercentage();
  const answerDetails = getAnswerDetails();
  const correctAnswers = answerDetails.filter(a => a.isCorrect).length;
  const showConfetti = attempt.passed && scorePercentage >= 90;

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {showConfetti && (
        <Confetti
          width={window.innerWidth}
          height={window.innerHeight}
          recycle={false}
          numberOfPieces={200}
        />
      )}

      {/* Result Header */}
      <Card className={`border-2 ${attempt.passed ? 'border-green-200 dark:border-green-800' : 'border-red-200 dark:border-red-800'}`}>
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            {attempt.passed ? (
              <div className="w-16 h-16 bg-green-100 dark:bg-green-900/30 rounded-full flex items-center justify-center">
                <Trophy className="w-8 h-8 text-green-600 dark:text-green-400" />
              </div>
            ) : (
              <div className="w-16 h-16 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center">
                <XCircle className="w-8 h-8 text-red-600 dark:text-red-400" />
              </div>
            )}
          </div>

          <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">
            {attempt.passed ? 'Congratulations! 🎉' : 'Quiz Completed'}
          </h1>
          
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            {attempt.quizzes.title}
          </p>

          <div className="flex items-center justify-center space-x-2 mb-4">
            <span className="text-3xl font-bold text-gray-900 dark:text-white">
              {scorePercentage}%
            </span>
            <Badge variant={attempt.passed ? 'success' : 'danger'} className="text-lg px-3 py-1">
              {attempt.passed ? 'PASSED' : 'FAILED'}
            </Badge>
          </div>

          <p className="text-sm text-gray-600 dark:text-gray-400">
            You scored {attempt.score} out of {attempt.quizzes.questions.reduce((sum, q) => sum + q.points, 0)} points
            {attempt.passed ? (
              <span className="text-green-600 dark:text-green-400">
                {' '}(Required: {attempt.quizzes.passing_score}%)
              </span>
            ) : (
              <span className="text-red-600 dark:text-red-400">
                {' '}(Required: {attempt.quizzes.passing_score}%)
              </span>
            )}
          </p>
        </CardHeader>
      </Card>

      {/* Stats Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6 text-center">
            <CheckCircle className="w-8 h-8 text-green-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-gray-900 dark:text-white">
              {correctAnswers}
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Correct</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <XCircle className="w-8 h-8 text-red-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-gray-900 dark:text-white">
              {attempt.total_questions - correctAnswers}
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Incorrect</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <BookOpen className="w-8 h-8 text-blue-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-gray-900 dark:text-white">
              {attempt.total_questions}
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400">Total Questions</p>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6 text-center">
            <Clock className="w-8 h-8 text-purple-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-gray-900 dark:text-white">
              {attempt.time_taken_minutes || 'N/A'}
            </p>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {attempt.time_taken_minutes ? 'Minutes' : 'Time'}
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Question Review */}
      <Card>
        <CardHeader>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            Question Review
          </h2>
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Review your answers and see the correct solutions
          </p>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            {answerDetails.map((detail, index) => (
              <div
                key={detail.question.id}
                className={`p-4 rounded-lg border-2 ${
                  detail.isCorrect
                    ? 'border-green-200 bg-green-50 dark:border-green-800 dark:bg-green-900/20'
                    : detail.wasAnswered
                    ? 'border-red-200 bg-red-50 dark:border-red-800 dark:bg-red-900/20'
                    : 'border-gray-200 bg-gray-50 dark:border-gray-700 dark:bg-gray-800'
                }`}
              >
                <div className="flex items-start justify-between mb-3">
                  <h3 className="font-medium text-gray-900 dark:text-white">
                    Question {index + 1}
                  </h3>
                  <div className="flex items-center space-x-2">
                    {detail.isCorrect ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : detail.wasAnswered ? (
                      <XCircle className="w-5 h-5 text-red-600" />
                    ) : (
                      <div className="w-5 h-5 rounded-full bg-gray-400" />
                    )}
                    <span className="text-sm font-medium">
                      {detail.question.points} point{detail.question.points !== 1 ? 's' : ''}
                    </span>
                  </div>
                </div>

                <p className="text-gray-900 dark:text-white mb-4">
                  {detail.question.question_text}
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-2 mb-4">
                  {(['A', 'B', 'C', 'D'] as const).map((option) => {
                    const optionText = detail.question[`option_${option.toLowerCase()}` as keyof typeof detail.question] as string;
                    const isCorrect = option === detail.question.correct_answer;
                    const isUserAnswer = option === detail.userAnswer;
                    
                    return (
                      <div
                        key={option}
                        className={`p-2 rounded border ${
                          isCorrect
                            ? 'border-green-500 bg-green-100 dark:bg-green-900/30'
                            : isUserAnswer && !isCorrect
                            ? 'border-red-500 bg-red-100 dark:bg-red-900/30'
                            : 'border-gray-200 dark:border-gray-700'
                        }`}
                      >
                        <div className="flex items-center space-x-2">
                          <span className="font-semibold">{option}.</span>
                          <span className="text-sm">{optionText}</span>
                          {isCorrect && <CheckCircle className="w-4 h-4 text-green-600" />}
                          {isUserAnswer && !isCorrect && <XCircle className="w-4 h-4 text-red-600" />}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {detail.question.explanation && (
                  <div className="p-3 bg-blue-50 dark:bg-blue-900/20 rounded border border-blue-200 dark:border-blue-800">
                    <p className="text-sm text-blue-800 dark:text-blue-300">
                      <strong>Explanation:</strong> {detail.question.explanation}
                    </p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Action Buttons */}
      <div className="flex flex-col sm:flex-row gap-4 justify-center">
        <Button asChild variant="outline" size="lg">
          <Link to="/dashboard">
            <Home className="w-5 h-5 mr-2" />
            Back to Dashboard
          </Link>
        </Button>
        
        <Button asChild variant="outline" size="lg">
          <Link to={`/quizzes/${quizId}`}>
            <RotateCcw className="w-5 h-5 mr-2" />
            Retake Quiz
          </Link>
        </Button>
        
        <Button asChild size="lg">
          <Link to="/quizzes">
            <BookOpen className="w-5 h-5 mr-2" />
            Browse More Quizzes
          </Link>
        </Button>
      </div>
    </div>
  );
};