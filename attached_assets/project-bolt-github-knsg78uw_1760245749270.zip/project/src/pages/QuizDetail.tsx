import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, Clock, BookOpen, Trophy, Crown, Users, Star, Play, CreditCard, Lock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { usePaystack } from '../hooks/usePaystack';
import { Card, CardContent, CardHeader } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';
import { Modal } from '../components/ui/Modal';

interface QuizWithSubject {
  id: string;
  title: string;
  description: string | null;
  difficulty_level: 'beginner' | 'intermediate' | 'advanced' | null;
  time_limit_minutes: number | null;
  passing_score: number;
  is_premium: boolean;
  price_naira: number;
  total_questions: number;
  question_randomize: boolean;
  subjects: {
    name: string;
    icon: string | null;
    description: string | null;
  } | null;
}

export const QuizDetail: React.FC = () => {
  const { quizId } = useParams<{ quizId: string }>();
  const navigate = useNavigate();
  const { user, profile, refreshProfile } = useAuth();
  const { initializePayment, isProcessing } = usePaystack();
  const [showPaymentModal, setShowPaymentModal] = useState(false);

  // Fetch quiz details
  const { data: quiz, isLoading, error } = useQuery({
    queryKey: ['quiz-detail', quizId],
    queryFn: async () => {
      if (!quizId) throw new Error('Quiz ID is required');
      
      const { data, error } = await supabase
        .from('quizzes')
        .select(`
          *,
          subjects (
            name,
            icon,
            description
          )
        `)
        .eq('id', quizId)
        .eq('is_active', true)
        .single();
      
      if (error) throw error;
      return data as QuizWithSubject;
    },
    enabled: !!quizId,
  });

  // Fetch user's previous attempts
  const { data: userAttempts } = useQuery({
    queryKey: ['user-quiz-attempts', quizId, user?.id],
    queryFn: async () => {
      if (!user || !quizId) return [];
      
      const { data, error } = await supabase
        .from('user_quiz_attempts')
        .select('*')
        .eq('user_id', user.id)
        .eq('quiz_id', quizId)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data;
    },
    enabled: !!user && !!quizId,
  });

  const handleStartQuiz = () => {
    if (!quiz || !quizId) return;
    navigate(`/quizzes/${quizId}/play`);
  };

  const handlePurchaseQuiz = () => {
    setShowPaymentModal(true);
  };

  const handlePaymentConfirm = async () => {
    if (!quiz || !user || !profile) return;

    const email = user.email || `${profile.phone_number}@quizmaster.temp`;

    initializePayment(
      quiz.price_naira,
      email,
      quiz.id,
      user.id,
      async () => {
        setShowPaymentModal(false);
        await refreshProfile();
      },
      () => {
        setShowPaymentModal(false);
      }
    );
  };

  const getDifficultyColor = (difficulty: string | null) => {
    switch (difficulty) {
      case 'beginner': return 'success';
      case 'intermediate': return 'warning';
      case 'advanced': return 'danger';
      default: return 'default';
    }
  };

  const canAccess = quiz && (!quiz.is_premium || profile?.is_premium);
  const bestAttempt = userAttempts?.[0];

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error || !quiz) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600 dark:text-red-400">
          Quiz not found or error loading quiz details.
        </p>
        <Button asChild className="mt-4">
          <Link to="/quizzes">Back to Quizzes</Link>
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Back Button */}
      <Button variant="ghost" asChild>
        <Link to="/quizzes">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Quizzes
        </Link>
      </Button>

      {/* Quiz Header */}
      <Card>
        <CardHeader>
          <div className="flex items-start justify-between">
            <div className="flex items-start space-x-4">
              <div className="text-3xl">
                {quiz.subjects?.icon || <BookOpen className="w-8 h-8 text-gray-400" />}
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                  {quiz.title}
                </h1>
                <p className="text-gray-600 dark:text-gray-400 mt-1">
                  {quiz.subjects?.name}
                </p>
                {quiz.description && (
                  <p className="text-gray-700 dark:text-gray-300 mt-2">
                    {quiz.description}
                  </p>
                )}
              </div>
            </div>
            {quiz.is_premium && (
              <Crown className="w-6 h-6 text-amber-500" />
            )}
          </div>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Quiz Information */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                Quiz Information
              </h2>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <BookOpen className="w-5 h-5 text-blue-600" />
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Questions</p>
                    <p className="font-semibold">{quiz.total_questions}</p>
                  </div>
                </div>

                {quiz.time_limit_minutes && (
                  <div className="flex items-center space-x-2">
                    <Clock className="w-5 h-5 text-emerald-600" />
                    <div>
                      <p className="text-sm text-gray-600 dark:text-gray-400">Time Limit</p>
                      <p className="font-semibold">{quiz.time_limit_minutes} minutes</p>
                    </div>
                  </div>
                )}

                <div className="flex items-center space-x-2">
                  <Trophy className="w-5 h-5 text-amber-600" />
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Passing Score</p>
                    <p className="font-semibold">{quiz.passing_score}%</p>
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Star className="w-5 h-5 text-purple-600" />
                  <div>
                    <p className="text-sm text-gray-600 dark:text-gray-400">Difficulty</p>
                    <Badge variant={getDifficultyColor(quiz.difficulty_level)}>
                      {quiz.difficulty_level || 'Not specified'}
                    </Badge>
                  </div>
                </div>
              </div>

              <div className="mt-6 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <h3 className="font-medium text-blue-900 dark:text-blue-400 mb-2">
                  Quiz Features
                </h3>
                <ul className="text-sm text-blue-800 dark:text-blue-300 space-y-1">
                  <li>• Multiple choice questions</li>
                  {quiz.question_randomize && <li>• Questions are randomized</li>}
                  {quiz.time_limit_minutes && <li>• Timed quiz with countdown</li>}
                  <li>• Instant results after completion</li>
                  <li>• Detailed explanations for answers</li>
                </ul>
              </div>
            </CardContent>
          </Card>

          {/* Subject Information */}
          {quiz.subjects?.description && (
            <Card>
              <CardHeader>
                <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                  About {quiz.subjects.name}
                </h2>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 dark:text-gray-300">
                  {quiz.subjects.description}
                </p>
              </CardContent>
            </Card>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Start Quiz Card */}
          <Card>
            <CardHeader>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                Ready to Start?
              </h3>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {quiz.is_premium && (
                  <div className="p-3 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <Crown className="w-4 h-4 text-amber-600" />
                      <span className="text-sm font-medium text-amber-800 dark:text-amber-400">
                        Premium Quiz - ₦{quiz.price_naira.toLocaleString()}
                      </span>
                    </div>
                  </div>
                )}

                {canAccess ? (
                  <Button onClick={handleStartQuiz} className="w-full" size="lg">
                    <Play className="w-5 h-5 mr-2" />
                    {bestAttempt ? 'Retake Quiz' : 'Start Quiz'}
                  </Button>
                ) : (
                  <>
                    <Button
                      onClick={handlePurchaseQuiz}
                      className="w-full bg-amber-600 hover:bg-amber-700"
                      size="lg"
                      disabled={isProcessing}
                    >
                      <CreditCard className="w-5 h-5 mr-2" />
                      Purchase for ₦{quiz.price_naira.toLocaleString()}
                    </Button>
                    <div className="flex items-center justify-center space-x-1 text-xs text-gray-600 dark:text-gray-400">
                      <Lock className="w-3 h-3" />
                      <span>Secure payment via Paystack</span>
                    </div>
                  </>
                )}

                {quiz.time_limit_minutes && (
                  <p className="text-xs text-gray-600 dark:text-gray-400 text-center">
                    You'll have {quiz.time_limit_minutes} minutes to complete this quiz
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Previous Attempts */}
          {userAttempts && userAttempts.length > 0 && (
            <Card>
              <CardHeader>
                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                  Your Attempts
                </h3>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {userAttempts.slice(0, 3).map((attempt, index) => (
                    <div
                      key={attempt.id}
                      className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-700 rounded-lg"
                    >
                      <div>
                        <p className="text-sm font-medium">
                          Attempt #{userAttempts.length - index}
                        </p>
                        <p className="text-xs text-gray-600 dark:text-gray-400">
                          {new Date(attempt.created_at).toLocaleDateString()}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge variant={attempt.passed ? 'success' : 'danger'}>
                          {Math.round((attempt.score / attempt.total_questions) * 100)}%
                        </Badge>
                        {attempt.passed && (
                          <Star className="w-4 h-4 text-amber-500 inline ml-1" />
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Payment Confirmation Modal */}
      <Modal
        isOpen={showPaymentModal}
        onClose={() => !isProcessing && setShowPaymentModal(false)}
        title="Purchase Premium Quiz"
      >
        <div className="space-y-4">
          <div className="p-4 bg-amber-50 dark:bg-amber-900/20 rounded-lg">
            <div className="flex items-center space-x-3">
              <Crown className="w-8 h-8 text-amber-600" />
              <div>
                <h3 className="font-semibold text-gray-900 dark:text-white">
                  {quiz?.title}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {quiz?.subjects?.name}
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-400">Quiz Price</span>
              <span className="font-semibold">₦{quiz?.price_naira.toLocaleString()}</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600 dark:text-gray-400">Number of Questions</span>
              <span className="font-semibold">{quiz?.total_questions}</span>
            </div>
            {quiz?.time_limit_minutes && (
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">Time Limit</span>
                <span className="font-semibold">{quiz.time_limit_minutes} minutes</span>
              </div>
            )}
          </div>

          <div className="pt-4 border-t border-gray-200 dark:border-gray-700">
            <div className="flex justify-between items-center mb-4">
              <span className="text-lg font-bold text-gray-900 dark:text-white">Total</span>
              <span className="text-2xl font-bold text-amber-600">₦{quiz?.price_naira.toLocaleString()}</span>
            </div>

            <div className="flex items-center space-x-2 text-xs text-gray-600 dark:text-gray-400 mb-4">
              <Lock className="w-3 h-3" />
              <span>Secure payment powered by Paystack</span>
            </div>

            <div className="flex space-x-3">
              <Button
                variant="outline"
                onClick={() => setShowPaymentModal(false)}
                disabled={isProcessing}
                className="flex-1"
              >
                Cancel
              </Button>
              <Button
                onClick={handlePaymentConfirm}
                disabled={isProcessing}
                loading={isProcessing}
                className="flex-1 bg-amber-600 hover:bg-amber-700"
              >
                <CreditCard className="w-4 h-4 mr-2" />
                Proceed to Payment
              </Button>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};