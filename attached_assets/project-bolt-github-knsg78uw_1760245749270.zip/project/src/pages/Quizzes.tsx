import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'react-router-dom';
import { Clock, BookOpen, Trophy, Crown, Users, Star } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../hooks/useAuth';
import { Card, CardContent, CardHeader } from '../components/ui/Card';
import { Badge } from '../components/ui/Badge';
import { Button } from '../components/ui/Button';

interface Quiz {
  id: string;
  title: string;
  description: string | null;
  difficulty_level: 'beginner' | 'intermediate' | 'advanced' | null;
  time_limit_minutes: number | null;
  passing_score: number;
  is_premium: boolean;
  price_naira: number;
  total_questions: number;
  subjects: {
    name: string;
    icon: string | null;
  } | null;
}

export const Quizzes: React.FC = () => {
  const { user, profile } = useAuth();

  // Fetch all active quizzes
  const { data: quizzes, isLoading, error } = useQuery({
    queryKey: ['quizzes'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('quizzes')
        .select(`
          *,
          subjects (
            name,
            icon
          )
        `)
        .eq('is_active', true)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      return data as Quiz[];
    },
  });

  // Fetch user's quiz attempts to show completion status
  const { data: userAttempts } = useQuery({
    queryKey: ['user-attempts', user?.id],
    queryFn: async () => {
      if (!user) return [];
      
      const { data, error } = await supabase
        .from('user_quiz_attempts')
        .select('quiz_id, score, total_questions, passed, created_at')
        .eq('user_id', user.id);
      
      if (error) throw error;
      return data;
    },
    enabled: !!user,
  });

  const getDifficultyColor = (difficulty: string | null) => {
    switch (difficulty) {
      case 'beginner': return 'success';
      case 'intermediate': return 'warning';
      case 'advanced': return 'danger';
      default: return 'default';
    }
  };

  const getUserAttempt = (quizId: string) => {
    return userAttempts?.find(attempt => attempt.quiz_id === quizId);
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-96">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="text-center py-12">
        <p className="text-red-600 dark:text-red-400">
          Error loading quizzes. Please try again.
        </p>
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="text-center">
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">
          Available Quizzes
        </h1>
        <p className="mt-2 text-gray-600 dark:text-gray-400">
          Test your knowledge with our comprehensive quiz collection
        </p>
      </div>

      {/* Quizzes Grid */}
      {quizzes && quizzes.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {quizzes.map((quiz) => {
            const userAttempt = getUserAttempt(quiz.id);
            const canAccess = !quiz.is_premium || profile?.is_premium;

            return (
              <Card key={quiz.id} hover className="relative">
                {quiz.is_premium && (
                  <div className="absolute top-4 right-4">
                    <Crown className="w-5 h-5 text-amber-500" />
                  </div>
                )}

                <CardHeader>
                  <div className="flex items-start space-x-3">
                    <div className="text-2xl">
                      {quiz.subjects?.icon || <BookOpen className="w-6 h-6 text-gray-400" />}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900 dark:text-white line-clamp-2">
                        {quiz.title}
                      </h3>
                      <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">
                        {quiz.subjects?.name}
                      </p>
                    </div>
                  </div>

                  {quiz.description && (
                    <p className="text-sm text-gray-600 dark:text-gray-400 line-clamp-2 mt-2">
                      {quiz.description}
                    </p>
                  )}
                </CardHeader>

                <CardContent>
                  <div className="space-y-4">
                    {/* Quiz Stats */}
                    <div className="flex items-center justify-between text-sm">
                      <div className="flex items-center space-x-4">
                        <div className="flex items-center space-x-1">
                          <BookOpen className="w-4 h-4 text-gray-400" />
                          <span>{quiz.total_questions} questions</span>
                        </div>
                        {quiz.time_limit_minutes && (
                          <div className="flex items-center space-x-1">
                            <Clock className="w-4 h-4 text-gray-400" />
                            <span>{quiz.time_limit_minutes}min</span>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Badges */}
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        {quiz.difficulty_level && (
                          <Badge variant={getDifficultyColor(quiz.difficulty_level)}>
                            {quiz.difficulty_level}
                          </Badge>
                        )}
                        {quiz.is_premium ? (
                          <Badge variant="premium">
                            ₦{quiz.price_naira.toLocaleString()}
                          </Badge>
                        ) : (
                          <Badge variant="success">Free</Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center space-x-1 text-sm text-gray-500">
                        <Trophy className="w-4 h-4" />
                        <span>{quiz.passing_score}% to pass</span>
                      </div>
                    </div>

                    {/* User's Previous Attempt */}
                    {userAttempt && (
                      <div className="p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                        <div className="flex items-center justify-between">
                          <span className="text-sm font-medium">Previous attempt:</span>
                          <div className="flex items-center space-x-2">
                            <Badge variant={userAttempt.passed ? 'success' : 'danger'}>
                              {Math.round((userAttempt.score / userAttempt.total_questions) * 100)}%
                            </Badge>
                            {userAttempt.passed && (
                              <Star className="w-4 h-4 text-amber-500" />
                            )}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Action Button */}
                    <div className="pt-2">
                      {canAccess ? (
                        <Button asChild className="w-full">
                          <Link to={`/quizzes/${quiz.id}`}>
                            {userAttempt ? 'Retake Quiz' : 'Start Quiz'}
                          </Link>
                        </Button>
                      ) : (
                        <Button variant="outline" className="w-full" disabled>
                          <Crown className="w-4 h-4 mr-2" />
                          Premium Required
                        </Button>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      ) : (
        <Card>
          <CardContent className="text-center py-12">
            <BookOpen className="w-12 h-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
              No quizzes available
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              Check back later for new quizzes
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};