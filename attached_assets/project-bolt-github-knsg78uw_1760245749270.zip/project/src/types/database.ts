export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string;
          user_id: string;
          phone_number: string;
          phone_verified: boolean;
          full_name: string | null;
          avatar_url: string | null;
          is_premium: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          phone_number: string;
          phone_verified?: boolean;
          full_name?: string | null;
          avatar_url?: string | null;
          is_premium?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          phone_number?: string;
          phone_verified?: boolean;
          full_name?: string | null;
          avatar_url?: string | null;
          is_premium?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      subjects: {
        Row: {
          id: string;
          name: string;
          description: string | null;
          icon: string | null;
          is_premium: boolean;
          display_order: number;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          description?: string | null;
          icon?: string | null;
          is_premium?: boolean;
          display_order?: number;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          description?: string | null;
          icon?: string | null;
          is_premium?: boolean;
          display_order?: number;
          created_at?: string;
          updated_at?: string;
        };
      };
      quizzes: {
        Row: {
          id: string;
          subject_id: string;
          title: string;
          description: string | null;
          difficulty_level: 'beginner' | 'intermediate' | 'advanced' | null;
          time_limit_minutes: number | null;
          passing_score: number;
          question_randomize: boolean;
          is_premium: boolean;
          price_naira: number;
          total_questions: number;
          is_active: boolean;
          instant_feedback: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          subject_id: string;
          title: string;
          description?: string | null;
          difficulty_level?: 'beginner' | 'intermediate' | 'advanced' | null;
          time_limit_minutes?: number | null;
          passing_score?: number;
          question_randomize?: boolean;
          is_premium?: boolean;
          price_naira?: number;
          total_questions?: number;
          is_active?: boolean;
          instant_feedback?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          subject_id?: string;
          title?: string;
          description?: string | null;
          difficulty_level?: 'beginner' | 'intermediate' | 'advanced' | null;
          time_limit_minutes?: number | null;
          passing_score?: number;
          question_randomize?: boolean;
          is_premium?: boolean;
          price_naira?: number;
          total_questions?: number;
          is_active?: boolean;
          instant_feedback?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      questions: {
        Row: {
          id: string;
          quiz_id: string;
          question_text: string;
          question_type: string;
          option_a: string;
          option_b: string;
          option_c: string;
          option_d: string;
          correct_answer: 'A' | 'B' | 'C' | 'D';
          explanation: string | null;
          points: number;
          display_order: number | null;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          quiz_id: string;
          question_text: string;
          question_type?: string;
          option_a: string;
          option_b: string;
          option_c: string;
          option_d: string;
          correct_answer: 'A' | 'B' | 'C' | 'D';
          explanation?: string | null;
          points?: number;
          display_order?: number | null;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          quiz_id?: string;
          question_text?: string;
          question_type?: string;
          option_a?: string;
          option_b?: string;
          option_c?: string;
          option_d?: string;
          correct_answer?: 'A' | 'B' | 'C' | 'D';
          explanation?: string | null;
          points?: number;
          display_order?: number | null;
          created_at?: string;
          updated_at?: string;
        };
      };
      user_quiz_attempts: {
        Row: {
          id: string;
          user_id: string;
          quiz_id: string;
          score: number;
          total_questions: number;
          time_taken_minutes: number | null;
          answers: Record<string, any>;
          passed: boolean | null;
          started_at: string;
          completed_at: string | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          quiz_id: string;
          score: number;
          total_questions: number;
          time_taken_minutes?: number | null;
          answers: Record<string, any>;
          passed?: boolean | null;
          started_at?: string;
          completed_at?: string | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          quiz_id?: string;
          score?: number;
          total_questions?: number;
          time_taken_minutes?: number | null;
          answers?: Record<string, any>;
          passed?: boolean | null;
          started_at?: string;
          completed_at?: string | null;
          created_at?: string;
        };
      };
      payments: {
        Row: {
          id: string;
          user_id: string;
          quiz_id: string | null;
          paystack_reference: string;
          amount_naira: number;
          payment_status: 'pending' | 'success' | 'failed' | 'cancelled';
          payment_method: string | null;
          verified_at: string | null;
          metadata: Record<string, any> | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          quiz_id?: string | null;
          paystack_reference: string;
          amount_naira: number;
          payment_status?: 'pending' | 'success' | 'failed' | 'cancelled';
          payment_method?: string | null;
          verified_at?: string | null;
          metadata?: Record<string, any> | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          quiz_id?: string | null;
          paystack_reference?: string;
          amount_naira?: number;
          payment_status?: 'pending' | 'success' | 'failed' | 'cancelled';
          payment_method?: string | null;
          verified_at?: string | null;
          metadata?: Record<string, any> | null;
          created_at?: string;
        };
      };
      admin_users: {
        Row: {
          id: string;
          user_id: string;
          role: 'admin' | 'super_admin';
          permissions: Record<string, any>;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          role?: 'admin' | 'super_admin';
          permissions?: Record<string, any>;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          role?: 'admin' | 'super_admin';
          permissions?: Record<string, any>;
          created_at?: string;
          updated_at?: string;
        };
      };
      quiz_analytics: {
        Row: {
          id: string;
          quiz_id: string;
          user_id: string;
          event_type: string;
          event_data: Record<string, any> | null;
          created_at: string;
        };
        Insert: {
          id?: string;
          quiz_id: string;
          user_id: string;
          event_type: string;
          event_data?: Record<string, any> | null;
          created_at?: string;
        };
        Update: {
          id?: string;
          quiz_id?: string;
          user_id?: string;
          event_type?: string;
          event_data?: Record<string, any> | null;
          created_at?: string;
        };
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
    Enums: {
      [_ in never]: never;
    };
    CompositeTypes: {
      [_ in never]: never;
    };
  };
}