import { create } from 'zustand';
import { persist } from 'zustand/middleware';

interface Quiz {
  id: string;
  title: string;
  subject_id: string;
  difficulty_level: 'beginner' | 'intermediate' | 'advanced';
  time_limit_minutes: number | null;
  passing_score: number;
  is_premium: boolean;
  price_naira: number;
  total_questions: number;
}

interface AppState {
  theme: 'light' | 'dark';
  currentQuiz: Quiz | null;
  quizTimer: number | null;
  quizStartTime: Date | null;
  sidebarOpen: boolean;
  
  // Actions
  setTheme: (theme: 'light' | 'dark') => void;
  toggleTheme: () => void;
  setCurrentQuiz: (quiz: Quiz | null) => void;
  setQuizTimer: (timer: number | null) => void;
  setQuizStartTime: (startTime: Date | null) => void;
  setSidebarOpen: (open: boolean) => void;
  resetQuizState: () => void;
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      theme: 'light',
      currentQuiz: null,
      quizTimer: null,
      quizStartTime: null,
      sidebarOpen: false,

      setTheme: (theme) => {
        set({ theme });
        if (theme === 'dark') {
          document.documentElement.classList.add('dark');
        } else {
          document.documentElement.classList.remove('dark');
        }
      },

      toggleTheme: () => {
        const { theme } = get();
        const newTheme = theme === 'light' ? 'dark' : 'light';
        get().setTheme(newTheme);
      },

      setCurrentQuiz: (currentQuiz) => 
        set({ currentQuiz }),

      setQuizTimer: (quizTimer) => 
        set({ quizTimer }),

      setQuizStartTime: (quizStartTime) => 
        set({ quizStartTime }),

      setSidebarOpen: (sidebarOpen) => 
        set({ sidebarOpen }),

      resetQuizState: () => 
        set({ 
          currentQuiz: null, 
          quizTimer: null, 
          quizStartTime: null 
        }),
    }),
    {
      name: 'app-storage',
      partialize: (state) => ({
        theme: state.theme,
      }),
    }
  )
);