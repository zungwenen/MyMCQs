import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';

interface Profile {
  id: string;
  phone_number: string;
  phone_verified: boolean;
  full_name: string | null;
  avatar_url: string | null;
  is_premium: boolean;
  created_at: string;
  updated_at: string;
}

interface AuthState {
  user: User | null;
  profile: Profile | null;
  isAdmin: boolean;
  isLoading: boolean;
  isAuthenticated: boolean;
  
  // Actions
  setUser: (user: User | null) => void;
  setProfile: (profile: Profile | null) => void;
  setIsAdmin: (isAdmin: boolean) => void;
  setLoading: (loading: boolean) => void;
  logout: () => Promise<void>;
  refreshProfile: () => Promise<void>;
}

export const useAuthStore = create<AuthState>()((set, get) => ({
  user: null,
  profile: null,
  isAdmin: false,
  isLoading: true,
  isAuthenticated: false,

  setUser: (user) =>
    set({
      user,
      isAuthenticated: !!user,
      isLoading: false
    }),

  setProfile: (profile) =>
    set({ profile }),

  setIsAdmin: (isAdmin) =>
    set({ isAdmin }),

  setLoading: (isLoading) =>
    set({ isLoading }),

  logout: async () => {
    await supabase.auth.signOut();
    set({
      user: null,
      profile: null,
      isAdmin: false,
      isAuthenticated: false,
      isLoading: false,
    });
  },

  refreshProfile: async () => {
    const { user } = get();
    if (!user) return;

    try {
      const [profileResult, adminResult] = await Promise.all([
        supabase
          .from('profiles')
          .select('*')
          .eq('user_id', user.id)
          .maybeSingle(),
        supabase
          .from('admin_users')
          .select('id, role')
          .eq('user_id', user.id)
          .maybeSingle()
      ]);

      if (profileResult.error && profileResult.error.code !== 'PGRST116') {
        console.error('Error refreshing profile:', profileResult.error);
      }

      if (adminResult.error && adminResult.error.code !== 'PGRST116') {
        console.error('Error refreshing admin status:', adminResult.error);
      }

      if (profileResult.data) {
        set({ profile: profileResult.data });
      }

      set({ isAdmin: !!adminResult.data });
    } catch (error) {
      console.error('Error refreshing profile:', error);
    }
  },
}));