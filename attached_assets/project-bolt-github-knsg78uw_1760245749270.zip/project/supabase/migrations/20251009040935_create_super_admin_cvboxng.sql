/*
  # Create Super Admin User for cvboxng@gmail.com

  1. Purpose
    - Adds unique constraint on admin_users.user_id (if not exists)
    - Adds unique constraint on profiles.user_id (if not exists)
    - Creates super admin user entry for cvboxng@gmail.com
    - Sets up admin privileges in admin_users table
    - Creates profile with verified phone number
    - Enables full administrative access to QuizMaster platform

  2. Super Admin Details
    - User ID: 342ab1b4-d501-4e5a-af26-9529dcfef043
    - Email: cvboxng@gmail.com
    - Phone: +2348135381616
    - Role: super_admin
    - Permissions: Full access to all administrative functions

  3. Prerequisites
    - The auth.users record MUST be created first via Supabase Dashboard
    - Navigate to: Authentication > Users > Add User
    - Create user with email: cvboxng@gmail.com
    - Set a secure password (at least 12 characters recommended)
    - Auto-confirm the user
    
  4. What This Migration Does
    - Adds UNIQUE constraint on admin_users.user_id if it doesn't exist
    - Adds UNIQUE constraint on profiles.user_id if it doesn't exist
    - Checks if the auth user exists in auth.users table
    - Creates admin_users entry with super_admin role
    - Creates profiles entry with verified phone and premium status
    - Grants all administrative permissions
    - Provides detailed feedback on success or required actions

  5. Security Notes
    - Change password immediately after first login for production use
    - Enable MFA (Multi-Factor Authentication) for this account
    - This account has unrestricted access to all platform features
    - Monitor activity logs for this account regularly
    - Consider creating additional admin accounts with restricted permissions
    
  6. Rollback Instructions
    - To remove admin privileges (emergency only):
      DELETE FROM admin_users WHERE user_id = '342ab1b4-d501-4e5a-af26-9529dcfef043';
      DELETE FROM profiles WHERE user_id = '342ab1b4-d501-4e5a-af26-9529dcfef043';
    - To fully remove user, use Supabase Dashboard: Authentication > Users
*/

-- Step 1: Add unique constraint on admin_users.user_id if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'admin_users_user_id_key' 
    AND conrelid = 'admin_users'::regclass
  ) THEN
    ALTER TABLE admin_users ADD CONSTRAINT admin_users_user_id_key UNIQUE (user_id);
    RAISE NOTICE '✓ Added UNIQUE constraint on admin_users.user_id';
  ELSE
    RAISE NOTICE '✓ UNIQUE constraint on admin_users.user_id already exists';
  END IF;
END $$;

-- Step 2: Add unique constraint on profiles.user_id if it doesn't exist
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'profiles_user_id_key' 
    AND conrelid = 'profiles'::regclass
  ) THEN
    ALTER TABLE profiles ADD CONSTRAINT profiles_user_id_key UNIQUE (user_id);
    RAISE NOTICE '✓ Added UNIQUE constraint on profiles.user_id';
  ELSE
    RAISE NOTICE '✓ UNIQUE constraint on profiles.user_id already exists';
  END IF;
END $$;

-- Step 3: Create super admin user
DO $$
DECLARE
  target_user_id uuid := '342ab1b4-d501-4e5a-af26-9529dcfef043';
  target_email text := 'cvboxng@gmail.com';
  target_phone text := '+2348135381616';
  user_exists boolean;
  admin_record_count integer;
  profile_record_count integer;
BEGIN
  -- Validate UUID format
  IF target_user_id IS NULL THEN
    RAISE EXCEPTION 'Invalid user UUID provided';
  END IF;

  -- Check if user exists in auth.users
  SELECT EXISTS (
    SELECT 1 FROM auth.users WHERE id = target_user_id
  ) INTO user_exists;

  IF NOT user_exists THEN
    -- User doesn't exist yet - provide clear instructions
    RAISE NOTICE '========================================';
    RAISE NOTICE 'SUPER ADMIN USER SETUP REQUIRED';
    RAISE NOTICE '========================================';
    RAISE NOTICE '';
    RAISE NOTICE 'The auth.users record does not exist yet.';
    RAISE NOTICE 'Please complete these steps in Supabase Dashboard:';
    RAISE NOTICE '';
    RAISE NOTICE '1. Navigate to: Authentication > Users';
    RAISE NOTICE '2. Click "Add User" button';
    RAISE NOTICE '3. Enter the following details:';
    RAISE NOTICE '   - Email: %', target_email;
    RAISE NOTICE '   - Phone: %', target_phone;
    RAISE NOTICE '   - Password: (choose a strong password - min 12 chars)';
    RAISE NOTICE '   - Auto Confirm User: YES (check this box)';
    RAISE NOTICE '';
    RAISE NOTICE '4. After user is created, re-run this migration';
    RAISE NOTICE '';
    RAISE NOTICE 'Note: The generated UUID will be different from: %', target_user_id;
    RAISE NOTICE 'You will need to update the migration with the actual UUID.';
    RAISE NOTICE '';
    RAISE NOTICE '========================================';
    
    -- Exit gracefully without error
    RETURN;
  END IF;

  -- User exists! Proceed with admin setup
  RAISE NOTICE '========================================';
  RAISE NOTICE 'Setting up Super Admin privileges...';
  RAISE NOTICE '========================================';

  -- Create or update admin_users entry
  INSERT INTO admin_users (
    user_id,
    role,
    permissions,
    created_at,
    updated_at
  )
  VALUES (
    target_user_id,
    'super_admin',
    '{"access": "all", "features": ["subjects", "quizzes", "questions", "users", "payments", "analytics", "settings"]}'::jsonb,
    now(),
    now()
  )
  ON CONFLICT (user_id) 
  DO UPDATE SET 
    role = 'super_admin',
    permissions = '{"access": "all", "features": ["subjects", "quizzes", "questions", "users", "payments", "analytics", "settings"]}'::jsonb,
    updated_at = now();

  GET DIAGNOSTICS admin_record_count = ROW_COUNT;
  RAISE NOTICE '✓ Admin privileges configured (% record(s) affected)', admin_record_count;

  -- Create or update profile
  INSERT INTO profiles (
    user_id,
    phone_number,
    phone_verified,
    full_name,
    is_premium,
    created_at,
    updated_at
  )
  VALUES (
    target_user_id,
    target_phone,
    true,
    'Super Admin',
    true,
    now(),
    now()
  )
  ON CONFLICT (user_id)
  DO UPDATE SET
    phone_number = target_phone,
    phone_verified = true,
    full_name = COALESCE(profiles.full_name, 'Super Admin'),
    is_premium = true,
    updated_at = now();

  GET DIAGNOSTICS profile_record_count = ROW_COUNT;
  RAISE NOTICE '✓ Profile created/updated (% record(s) affected)', profile_record_count;

  -- Verify setup
  RAISE NOTICE '';
  RAISE NOTICE '========================================';
  RAISE NOTICE 'SUPER ADMIN SETUP COMPLETE';
  RAISE NOTICE '========================================';
  RAISE NOTICE '';
  RAISE NOTICE 'Admin User Details:';
  RAISE NOTICE '  User ID: %', target_user_id;
  RAISE NOTICE '  Email: %', target_email;
  RAISE NOTICE '  Phone: %', target_phone;
  RAISE NOTICE '  Role: super_admin';
  RAISE NOTICE '  Premium Status: Enabled';
  RAISE NOTICE '';
  RAISE NOTICE 'You can now sign in at: /admin/login';
  RAISE NOTICE '';
  RAISE NOTICE 'IMPORTANT SECURITY REMINDERS:';
  RAISE NOTICE '  - Change your password if using a temporary one';
  RAISE NOTICE '  - Enable MFA in Supabase Dashboard for this account';
  RAISE NOTICE '  - Never share these credentials';
  RAISE NOTICE '  - Monitor admin activity logs regularly';
  RAISE NOTICE '';
  RAISE NOTICE '========================================';

EXCEPTION
  WHEN OTHERS THEN
    RAISE NOTICE 'ERROR: %', SQLERRM;
    RAISE NOTICE 'Failed to set up super admin user';
    RAISE NOTICE 'Please check the error message above and try again';
    RAISE;
END $$;

-- Verification queries (these will show in migration output)
-- Check admin_users entry
DO $$
DECLARE
  admin_check record;
BEGIN
  SELECT 
    au.user_id,
    au.role,
    au.permissions,
    u.email
  INTO admin_check
  FROM admin_users au
  JOIN auth.users u ON u.id = au.user_id
  WHERE au.user_id = '342ab1b4-d501-4e5a-af26-9529dcfef043';

  IF FOUND THEN
    RAISE NOTICE 'Verification - Admin Users Entry: ✓ EXISTS';
    RAISE NOTICE '  Email: %', admin_check.email;
    RAISE NOTICE '  Role: %', admin_check.role;
  ELSE
    RAISE NOTICE 'Verification - Admin Users Entry: ✗ NOT FOUND';
  END IF;
END $$;

-- Check profiles entry
DO $$
DECLARE
  profile_check record;
BEGIN
  SELECT 
    p.user_id,
    p.phone_number,
    p.phone_verified,
    p.is_premium,
    p.full_name
  INTO profile_check
  FROM profiles p
  WHERE p.user_id = '342ab1b4-d501-4e5a-af26-9529dcfef043';

  IF FOUND THEN
    RAISE NOTICE 'Verification - Profile Entry: ✓ EXISTS';
    RAISE NOTICE '  Phone: %', profile_check.phone_number;
    RAISE NOTICE '  Verified: %', profile_check.phone_verified;
    RAISE NOTICE '  Premium: %', profile_check.is_premium;
  ELSE
    RAISE NOTICE 'Verification - Profile Entry: ✗ NOT FOUND';
  END IF;
END $$;