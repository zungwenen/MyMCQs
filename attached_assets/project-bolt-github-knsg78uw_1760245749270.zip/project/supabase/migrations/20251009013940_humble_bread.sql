/*
  # Create Admin User Migration

  1. New Admin User Setup
    - Creates an admin user with email/password authentication
    - Adds the user to the admin_users table with appropriate permissions
    - Sets up the profile for the admin user

  2. Security
    - Admin user has full access to all admin functions
    - Profile is created with verified status

  Note: Replace the email and password with your desired admin credentials
*/

-- First, you need to create the admin user through Supabase Auth
-- This can be done via the Supabase dashboard or using the management API

-- Example of what the admin user record should look like in admin_users table:
-- INSERT INTO admin_users (user_id, role, permissions) 
-- VALUES ('your-admin-user-id', 'super_admin', '["all"]'::jsonb);

-- Example of what the profile should look like:
-- INSERT INTO profiles (user_id, phone_number, phone_verified, full_name, is_premium)
-- VALUES ('your-admin-user-id', '+1234567890', true, 'Admin User', true);

-- For now, this migration file serves as documentation
-- The actual admin user creation should be done through Supabase Auth UI or API