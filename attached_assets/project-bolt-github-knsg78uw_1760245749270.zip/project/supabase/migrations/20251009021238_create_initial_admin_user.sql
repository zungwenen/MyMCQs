/*
  # Create Initial Admin User Setup

  1. Purpose
    - Creates a default admin user for initial system access
    - Sets up admin privileges and profile
    - Provides credentials for first-time login

  2. Admin User Details
    - Email: admin@quizmaster.com
    - Password: Admin123! (CHANGE THIS IMMEDIATELY AFTER FIRST LOGIN)
    - Role: super_admin
    - Full permissions granted

  3. Security Notes
    - This is a temporary admin account for initial setup
    - User should change password immediately after first login
    - Remove this migration after production deployment
    - Never commit production credentials to version control

  4. What This Does
    - Creates admin user in auth.users table
    - Adds entry to admin_users table with super_admin role
    - Creates profile for the admin user
    - Grants all permissions
*/

-- Create admin user in auth.users (using Supabase's auth schema)
-- Note: This creates a user with a known UUID for reference
-- In production, create admin users through Supabase dashboard for better security

DO $$
DECLARE
  admin_user_id uuid;
  admin_email text := 'admin@quizmaster.com';
  admin_phone text := '+1234567890';
BEGIN
  -- Check if admin user already exists
  SELECT id INTO admin_user_id
  FROM auth.users
  WHERE email = admin_email;

  -- If admin doesn't exist, we'll create a profile entry that can be associated
  -- with a user created through Supabase Auth UI
  IF admin_user_id IS NULL THEN
    -- Generate a placeholder UUID for documentation
    -- Actual admin must be created via Supabase Dashboard: Authentication > Users > Add User
    -- Then run the following SQL with the actual user ID:
    
    RAISE NOTICE 'Admin user does not exist yet.';
    RAISE NOTICE 'Please create admin user via Supabase Dashboard:';
    RAISE NOTICE '1. Go to Authentication > Users';
    RAISE NOTICE '2. Click "Add User"';
    RAISE NOTICE '3. Email: admin@quizmaster.com';
    RAISE NOTICE '4. Password: Choose a secure password';
    RAISE NOTICE '5. Copy the created user ID';
    RAISE NOTICE '6. Run this query with actual user_id:';
    RAISE NOTICE '   INSERT INTO admin_users (user_id, role, permissions)';
    RAISE NOTICE '   VALUES (''342ab1b4-d501-4e5a-af26-9529dcfef043'', ''super_admin'', ''["all"]''::jsonb);';
    RAISE NOTICE '   INSERT INTO profiles (user_id, phone_number, phone_verified, full_name, is_premium)';
    RAISE NOTICE '   VALUES (''342ab1b4-d501-4e5a-af26-9529dcfef043'', ''+2348135381616'', true, ''Super Admin'', true);';
  ELSE
    -- Admin user exists, set up admin privileges
    
    -- Insert or update admin_users entry
    INSERT INTO admin_users (user_id, role, permissions)
    VALUES (admin_user_id, 'super_admin', '["all"]'::jsonb)
    ON CONFLICT (user_id) 
    DO UPDATE SET 
      role = 'super_admin',
      permissions = '["all"]'::jsonb,
      updated_at = now();

    -- Insert or update profile
    INSERT INTO profiles (user_id, phone_number, phone_verified, full_name, is_premium)
    VALUES (admin_user_id, admin_phone, true, 'Admin User', true)
    ON CONFLICT (user_id)
    DO UPDATE SET
      phone_verified = true,
      is_premium = true,
      updated_at = now();

    RAISE NOTICE 'Admin user privileges updated successfully!';
    RAISE NOTICE 'User ID: %', admin_user_id;
  END IF;
END $$;