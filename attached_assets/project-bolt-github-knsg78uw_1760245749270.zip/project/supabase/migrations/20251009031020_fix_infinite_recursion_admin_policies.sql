/*
  # Fix Infinite Recursion in Admin RLS Policies

  1. Problem
    - The admin_users table has a recursive policy that checks admin_users from within itself
    - This causes "infinite recursion detected in policy" error (42P17)
    - Multiple tables reference this problematic policy for admin checks

  2. Solution
    - Create a security definer function to check admin status without triggering RLS
    - Drop all existing problematic admin policies
    - Recreate policies using the security definer function
    - This breaks the recursion cycle by bypassing RLS in the helper function

  3. Tables Affected
    - admin_users (primary issue)
    - subjects
    - quizzes
    - questions
    - user_quiz_attempts
    - payments
    - quiz_analytics

  4. Security Notes
    - Security definer functions run with elevated privileges
    - The function only checks admin status, doesn't expose sensitive data
    - All policies still properly restrict access based on authentication
    - Non-admin users cannot escalate privileges
*/

-- Drop existing problematic policies
DROP POLICY IF EXISTS "Admin users can read admin data" ON admin_users;
DROP POLICY IF EXISTS "Admin can manage subjects" ON subjects;
DROP POLICY IF EXISTS "Admin can manage quizzes" ON quizzes;
DROP POLICY IF EXISTS "Admin can manage questions" ON questions;
DROP POLICY IF EXISTS "Admin can read all quiz attempts" ON user_quiz_attempts;
DROP POLICY IF EXISTS "Admin can read all payments" ON payments;
DROP POLICY IF EXISTS "Admin can read all analytics" ON quiz_analytics;

-- Create a security definer function to check if user is admin
-- This function bypasses RLS to prevent infinite recursion
CREATE OR REPLACE FUNCTION public.is_admin(user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 
    FROM admin_users 
    WHERE admin_users.user_id = is_admin.user_id
  );
END;
$$;

-- Create a convenience function that uses current user
CREATE OR REPLACE FUNCTION public.is_current_user_admin()
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  RETURN public.is_admin(auth.uid());
END;
$$;

-- Recreate admin_users policies using security definer function
CREATE POLICY "Admin users can read admin data"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (public.is_current_user_admin());

CREATE POLICY "Admin users can manage admin data"
  ON admin_users
  FOR ALL
  TO authenticated
  USING (public.is_current_user_admin())
  WITH CHECK (public.is_current_user_admin());

-- Recreate subjects policies
CREATE POLICY "Admin can manage subjects"
  ON subjects
  FOR ALL
  TO authenticated
  USING (public.is_current_user_admin())
  WITH CHECK (public.is_current_user_admin());

-- Recreate quizzes policies
CREATE POLICY "Admin can manage quizzes"
  ON quizzes
  FOR ALL
  TO authenticated
  USING (public.is_current_user_admin())
  WITH CHECK (public.is_current_user_admin());

-- Recreate questions policies
CREATE POLICY "Admin can manage questions"
  ON questions
  FOR ALL
  TO authenticated
  USING (public.is_current_user_admin())
  WITH CHECK (public.is_current_user_admin());

-- Recreate user_quiz_attempts policies
CREATE POLICY "Admin can read all quiz attempts"
  ON user_quiz_attempts
  FOR SELECT
  TO authenticated
  USING (public.is_current_user_admin());

-- Recreate payments policies
CREATE POLICY "Admin can read all payments"
  ON payments
  FOR SELECT
  TO authenticated
  USING (public.is_current_user_admin());

-- Recreate quiz_analytics policies
CREATE POLICY "Admin can read all analytics"
  ON quiz_analytics
  FOR SELECT
  TO authenticated
  USING (public.is_current_user_admin());

-- Add missing admin management policies for other tables
CREATE POLICY "Admin can manage payments"
  ON payments
  FOR INSERT
  TO authenticated
  WITH CHECK (public.is_current_user_admin());

CREATE POLICY "Admin can update payments"
  ON payments
  FOR UPDATE
  TO authenticated
  USING (public.is_current_user_admin())
  WITH CHECK (public.is_current_user_admin());

CREATE POLICY "Admin can manage analytics"
  ON quiz_analytics
  FOR UPDATE
  TO authenticated
  USING (public.is_current_user_admin())
  WITH CHECK (public.is_current_user_admin());

CREATE POLICY "Admin can delete analytics"
  ON quiz_analytics
  FOR DELETE
  TO authenticated
  USING (public.is_current_user_admin());

-- Grant execute permissions on the helper functions
GRANT EXECUTE ON FUNCTION public.is_admin(uuid) TO authenticated;
GRANT EXECUTE ON FUNCTION public.is_current_user_admin() TO authenticated;