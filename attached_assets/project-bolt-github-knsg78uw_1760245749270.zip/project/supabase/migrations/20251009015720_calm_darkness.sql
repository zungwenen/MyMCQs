/*
  # Add instant feedback setting to quizzes

  1. Changes
    - Add `instant_feedback` column to `quizzes` table
    - Set default value to false for existing quizzes
    - Update RLS policies to include new column

  2. Security
    - Maintain existing RLS policies
    - Admin users can manage all quiz settings
*/

-- Add instant_feedback column to quizzes table
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'quizzes' AND column_name = 'instant_feedback'
  ) THEN
    ALTER TABLE quizzes ADD COLUMN instant_feedback boolean DEFAULT false;
  END IF;
END $$;