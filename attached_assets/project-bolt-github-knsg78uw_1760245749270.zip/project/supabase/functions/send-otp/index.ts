import { corsHeaders } from '../_shared/cors.ts';

interface OTPRequest {
  phoneNumber: string;
  otp: string;
}

const TWILIO_ACCOUNT_SID = Deno.env.get('TWILIO_ACCOUNT_SID');
const TWILIO_AUTH_TOKEN = Deno.env.get('TWILIO_AUTH_TOKEN');
const TWILIO_PHONE_NUMBER = Deno.env.get('TWILIO_PHONE_NUMBER');
const TWILIO_WHATSAPP_NUMBER = 'whatsapp:+14155238886'; // Twilio Sandbox WhatsApp number

Deno.serve(async (req: Request) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    if (req.method !== 'POST') {
      throw new Error('Method not allowed');
    }

    const { phoneNumber, otp }: OTPRequest = await req.json();

    if (!phoneNumber || !otp) {
      throw new Error('Phone number and OTP are required');
    }

    if (!TWILIO_ACCOUNT_SID || !TWILIO_AUTH_TOKEN || !TWILIO_PHONE_NUMBER) {
      throw new Error('Twilio credentials not configured');
    }

    const basicAuth = btoa(`${TWILIO_ACCOUNT_SID}:${TWILIO_AUTH_TOKEN}`);
    const message = `Your QuizMaster verification code is: ${otp}. This code expires in 10 minutes.`;

    let deliveryMethod = 'sms';
    let deliveryStatus = 'failed';

    try {
      // Try WhatsApp first
      const whatsappResponse = await fetch(
        `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Basic ${basicAuth}`,
            'Content-Type': 'application/x-www-form-urlencoded',
          },
          body: new URLSearchParams({
            From: TWILIO_WHATSAPP_NUMBER,
            To: `whatsapp:${phoneNumber}`,
            Body: message,
          }),
        }
      );

      if (whatsappResponse.ok) {
        deliveryMethod = 'whatsapp';
        deliveryStatus = 'sent';
      } else {
        throw new Error('WhatsApp delivery failed');
      }
    } catch (whatsappError) {
      console.log('WhatsApp failed, trying SMS:', whatsappError);
      
      // Fallback to SMS
      try {
        const smsResponse = await fetch(
          `https://api.twilio.com/2010-04-01/Accounts/${TWILIO_ACCOUNT_SID}/Messages.json`,
          {
            method: 'POST',
            headers: {
              'Authorization': `Basic ${basicAuth}`,
              'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: new URLSearchParams({
              From: TWILIO_PHONE_NUMBER,
              To: phoneNumber,
              Body: message,
            }),
          }
        );

        if (smsResponse.ok) {
          deliveryMethod = 'sms';
          deliveryStatus = 'sent';
        } else {
          const errorData = await smsResponse.text();
          throw new Error(`SMS delivery failed: ${errorData}`);
        }
      } catch (smsError) {
        console.error('SMS delivery failed:', smsError);
        throw smsError;
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        deliveryMethod,
        deliveryStatus,
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('OTP sending error:', error);
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});