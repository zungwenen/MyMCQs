import { createClient } from 'npm:@supabase/supabase-js@2';
import { corsHeaders } from '../_shared/cors.ts';

const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
const paystackSecretKey = Deno.env.get('PAYSTACK_SECRET_KEY');

const supabase = createClient(supabaseUrl, supabaseServiceKey);

interface PaymentVerificationRequest {
  reference: string;
  userId: string;
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    if (req.method !== 'POST') {
      throw new Error('Method not allowed');
    }

    const { reference, userId }: PaymentVerificationRequest = await req.json();

    if (!reference || !userId) {
      throw new Error('Reference and userId are required');
    }

    if (!paystackSecretKey) {
      throw new Error('Paystack secret key not configured');
    }

    // Verify payment with Paystack
    const paystackResponse = await fetch(
      `https://api.paystack.co/transaction/verify/${reference}`,
      {
        headers: {
          'Authorization': `Bearer ${paystackSecretKey}`,
          'Content-Type': 'application/json',
        },
      }
    );

    const paystackData = await paystackResponse.json();

    if (!paystackResponse.ok || !paystackData.status) {
      throw new Error('Payment verification failed');
    }

    const { data: paymentData } = paystackData;

    if (paymentData.status !== 'success') {
      throw new Error('Payment was not successful');
    }

    // Update payment record in database
    const { error: updateError } = await supabase
      .from('payments')
      .update({
        payment_status: 'success',
        payment_method: paymentData.channel,
        verified_at: new Date().toISOString(),
        metadata: paymentData,
      })
      .eq('paystack_reference', reference)
      .eq('user_id', userId);

    if (updateError) {
      throw updateError;
    }

    // If this was a premium quiz purchase, grant access
    const { data: payment } = await supabase
      .from('payments')
      .select('quiz_id')
      .eq('paystack_reference', reference)
      .single();

    if (payment?.quiz_id) {
      // You can implement quiz access logic here
      // For now, we'll just update user's premium status if needed
      const { error: profileError } = await supabase
        .from('profiles')
        .update({ is_premium: true })
        .eq('user_id', userId);

      if (profileError) {
        console.error('Error updating premium status:', profileError);
      }
    }

    return new Response(
      JSON.stringify({
        success: true,
        amount: paymentData.amount / 100, // Convert from kobo to naira
        currency: paymentData.currency,
        paidAt: paymentData.paid_at,
      }),
      {
        status: 200,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  } catch (error) {
    console.error('Payment verification error:', error);
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
      }),
      {
        status: 400,
        headers: {
          ...corsHeaders,
          'Content-Type': 'application/json',
        },
      }
    );
  }
});