# QuizMaster Setup Guide

This guide will help you set up the QuizMaster application from scratch.

## Prerequisites

- Node.js 18+ and npm
- A Supabase account (free tier works)
- A Twilio account (for OTP/SMS functionality)
- A Paystack account (for payment processing, Nigeria-based)

## Step 1: Clone and Install Dependencies

```bash
git clone <repository-url>
cd quizmaster-app
npm install
```

## Step 2: Supabase Setup

### 2.1 Create a Supabase Project

1. Go to [https://app.supabase.com](https://app.supabase.com)
2. Click "New Project"
3. Fill in your project details and wait for it to be created

### 2.2 Get Your Credentials

1. Go to Project Settings > API
2. Copy your **Project URL** and **anon public** key
3. Save these for the next step

### 2.3 Run Database Migrations

The migrations are already created in `supabase/migrations/`. They will be automatically applied when you connect to Supabase.

Alternatively, you can manually run them:
1. Go to SQL Editor in your Supabase dashboard
2. Copy the contents of each migration file from `supabase/migrations/`
3. Execute them in order (by timestamp)

### 2.4 Create an Admin User

1. Go to Authentication > Users in your Supabase dashboard
2. Click "Add User"
3. Email: `admin@quizmaster.com` (or your preferred email)
4. Password: Choose a strong password
5. Click "Create User"
6. Copy the User ID that was generated

Now run this SQL in the SQL Editor:

```sql
-- Replace YOUR-USER-ID with the actual user ID from step 6
INSERT INTO admin_users (user_id, role, permissions)
VALUES ('YOUR-USER-ID', 'super_admin', '["all"]'::jsonb);

INSERT INTO profiles (user_id, phone_number, phone_verified, full_name, is_premium)
VALUES ('YOUR-USER-ID', '+1234567890', true, 'Admin User', true);
```

### 2.5 Configure Edge Functions Environment Variables

1. Go to Project Settings > Edge Functions
2. Add these environment variables:

```
TWILIO_ACCOUNT_SID=your_twilio_sid
TWILIO_AUTH_TOKEN=your_twilio_token
TWILIO_PHONE_NUMBER=your_twilio_number
PAYSTACK_SECRET_KEY=your_paystack_secret_key
```

## Step 3: Twilio Setup (OTP/SMS)

### 3.1 Create a Twilio Account

1. Go to [https://www.twilio.com](https://www.twilio.com)
2. Sign up for a free account
3. Verify your email and phone number

### 3.2 Get Your Credentials

1. Go to Console Dashboard
2. Copy your **Account SID** and **Auth Token**
3. Go to Phone Numbers > Manage > Active numbers
4. Copy your Twilio phone number (format: +1234567890)

### 3.3 WhatsApp Setup (Optional but Recommended)

1. Go to Messaging > Try it out > Send a WhatsApp message
2. Follow the instructions to join the Twilio Sandbox
3. The WhatsApp number is: `whatsapp:+14155238886`

## Step 4: Paystack Setup (Payment Processing)

### 4.1 Create a Paystack Account

1. Go to [https://paystack.com](https://paystack.com)
2. Sign up for an account
3. Complete your business verification

### 4.2 Get Your API Keys

1. Go to Settings > API Keys & Webhooks
2. Copy your **Public Key** and **Secret Key**
3. **Important**: Use Test keys for development, Live keys for production

### 4.3 Configure Webhook (Optional for production)

1. In Settings > API Keys & Webhooks
2. Add webhook URL: `https://YOUR-PROJECT.supabase.co/functions/v1/verify-payment`
3. Enable "Charge success" event

## Step 5: Environment Configuration

1. Copy the example environment file:

```bash
cp .env.example .env
```

2. Fill in your credentials in `.env`:

```env
# Supabase
VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key

# Paystack (Public key only needed in frontend)
VITE_PAYSTACK_PUBLIC_KEY=pk_test_your_key
```

**Note**: Twilio and Paystack secret keys are configured in Supabase Edge Functions environment variables (Step 2.5), not in the local .env file.

## Step 6: Run the Application

```bash
npm run dev
```

The application will be available at `http://localhost:5173`

## Step 7: First Login

### Admin Login
1. Navigate to `/admin/login`
2. Use the admin email and password you created in Step 2.4
3. You now have access to the admin panel

### User Login
1. Navigate to `/login`
2. Enter a phone number (with country code, e.g., +2348012345678)
3. You'll receive an OTP via WhatsApp or SMS
4. Enter the OTP to complete login

## Common Issues and Solutions

### Issue: OTP not received
- **Solution**: Check that Twilio credentials are correctly set in Supabase Edge Functions environment variables
- **Solution**: Verify your Twilio account is active and has sufficient balance
- **Solution**: Check Twilio logs in the Twilio Console for delivery status

### Issue: Payment not working
- **Solution**: Ensure you're using the correct Paystack keys (Test vs Live)
- **Solution**: Check that VITE_PAYSTACK_PUBLIC_KEY is set in your .env file
- **Solution**: Verify Paystack Edge Function has PAYSTACK_SECRET_KEY set

### Issue: Admin login not working
- **Solution**: Verify the admin user was created correctly in the database
- **Solution**: Check that the user exists in both `auth.users` and `admin_users` tables
- **Solution**: Try resetting the admin password via Supabase Dashboard

### Issue: Database connection error
- **Solution**: Verify Supabase URL and anon key are correct in .env
- **Solution**: Check that your Supabase project is active
- **Solution**: Ensure migrations were applied successfully

## Testing Payment (Development)

1. Use Paystack test cards:
   - **Success**: 4084084084084081
   - **Decline**: 4084080000000409
   - **Insufficient funds**: 4084080000005408

2. Use any future expiry date and any CVV

## Production Deployment

### Frontend Deployment

Build the application:

```bash
npm run build
```

Deploy the `dist` folder to:
- Vercel
- Netlify
- Cloudflare Pages
- Or any static hosting service

### Environment Variables for Production

Make sure to set these in your hosting platform:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_PAYSTACK_PUBLIC_KEY`

### Edge Functions

Edge functions are automatically deployed with Supabase. Ensure environment variables are set in production:
- Go to Project Settings > Edge Functions
- Set production values for Twilio and Paystack keys

### Important Security Notes

1. **Never commit** your `.env` file to version control
2. Always use **environment variables** for sensitive credentials
3. Use **test keys** for development, **live keys** for production only
4. Rotate your API keys regularly
5. Enable Supabase Row Level Security (RLS) policies (already configured)
6. Monitor Twilio and Paystack usage regularly

## Support

If you encounter issues:
1. Check the browser console for error messages
2. Check Supabase logs in the Dashboard
3. Check Twilio logs in the Twilio Console
4. Check Paystack logs in the Paystack Dashboard
5. Review the migration files to ensure database schema is correct

## Next Steps

After setup, you can:
1. Create subjects in the admin panel
2. Create quizzes for each subject
3. Add questions to quizzes
4. Configure quiz settings (time limits, passing scores, etc.)
5. Set premium pricing for quizzes
6. Monitor user activity and payments in the admin dashboard
